import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { InjectionToken, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GlobalErrorInterceptor } from '@core/components/logging-error-handle/intercepters/global-error.interceptor';
import { LoggingErrorHandleInterceptor } from '@core/components/logging-error-handle/intercepters/logging-error-handle.interceptor';
import { CoreModule } from '@core/core.module';
import { ApiInterceptor } from '@core/interceptors/api.interceptor';
import { CredentialsRequestInterceptor } from '@core/interceptors/credentials.interceptor';
import { XsrfTokenInterceptor } from '@core/interceptors/xsrf-token.interceptor';
import { AuthService } from '@core/services/auth/auth.service';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { VersionService } from '@core/services/version.service';
import { AlertModule } from '@ipreo/ngx-sprinkles';
import { NgIdleModule } from '@ng-idle/core';
import { EffectsModule } from '@ngrx/effects';
import { ActionReducerMap, StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AdminSharedModule } from '@shared/shared.module';
import { ChangePasswordEffect } from '@state/effects/change-password.effect';
import { LoginEffect } from '@state/effects/login.effect';
import { LogoutEffect } from '@state/effects/logout.effect';
import { ProductPortalEffect } from '@state/effects/product-portal.effect';
import { AppState, reducers } from '@state/reducers';
import { environment } from '../environments/environment';
import { APP_INITIALIZER_PROVIDER } from './app-intializer';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminUsersHttpService } from './modules/admin-users/services/admin-users-http.service';
import { windowProvider, windowRefProvider } from './shared/services/window.service';

export const reducerToken = new InjectionToken<ActionReducerMap<AppState>>('Buyside Admin UI Reducers');

export const reducerProvider = [{ provide: reducerToken, useValue: reducers }];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    CoreModule,
    NgIdleModule.forRoot(),
    AlertModule,
    StoreModule.forRoot(reducerToken, {
      runtimeChecks: {
        strictStateImmutability: !environment.production,
        strictActionImmutability: !environment.production
      }
    }),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: environment.production,
      autoPause: true,
      trace: false,
      traceLimit: 25
    }),
    EffectsModule.forRoot([LoginEffect, LogoutEffect, ChangePasswordEffect, ProductPortalEffect]),
    AdminSharedModule
  ],
  providers: [
    reducerProvider,
    APP_INITIALIZER_PROVIDER,
    VersionService,
    AuthService,
    windowRefProvider,
    windowProvider,
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    { provide: HTTP_INTERCEPTORS, useClass: ApiInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoggingErrorHandleInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: GlobalErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: XsrfTokenInterceptor, multi: true },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CredentialsRequestInterceptor,
      multi: true
    },
    AdminUsersHttpService,
    CredentialsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
