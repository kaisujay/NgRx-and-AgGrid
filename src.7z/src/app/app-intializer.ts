import { APP_INITIALIZER } from '@angular/core';
import { Router } from '@angular/router';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { VersionService } from '@core/services/version.service';
import { Store } from '@ngrx/store';
import { RestoreSessionAction } from '@state/actions/auth-api.actions';
import { ConfigurationLoadAction } from '@state/actions/configuration.actions';

const deps = [Store, VersionService, UserContextService, Router];

export const APP_INITIALIZER_PROVIDER = {
  provide: APP_INITIALIZER,
  useFactory: loadConfigurationFactory,
  deps,
  multi: true
};

export function loadConfigurationFactory(
  store: Store,
  versionService: VersionService,
  userContextSvc: UserContextService,
  router: Router
) {
  return async () => {
    try {
      const configuration = await versionService.getVersionConfig();
      (window as any).buySideAdminConfiguration = configuration;
      store.dispatch(new ConfigurationLoadAction(configuration));

      const userContext = await userContextSvc.getContextLoad();
      delete userContext.xsrf_token;
      store.dispatch(new RestoreSessionAction(userContext));
    } catch (error) {
      router.navigate(['/login']);
      console.error(error);
    }
  };
}
