import { Inject, Injectable } from '@angular/core';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, finalize, switchMap, tap } from 'rxjs/operators';

import { Router } from '@angular/router';
import { AuthService } from '@core/services/auth/auth.service';
import { Store } from '@ngrx/store';
import { AuthApiActionTypes } from '@state/actions/auth-api.actions';
import { of } from 'rxjs';
import { WINDOW } from 'src/app/shared/services/window.service';

@Injectable()
export class LogoutEffect {
  public constructor(
    private actions$: Actions,
    private authService: AuthService,
    private router: Router,
    @Inject(WINDOW) private window: Window,
    private store: Store
  ) {}

  public logout$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthApiActionTypes.Logout),
        switchMap(() =>
          this.authService.logout().pipe(
            finalize(() => {
              this.terminateSession();
            })
          )
        ),
        catchError(error => of({ ...error, success: false }))
      ),
    { dispatch: false }
  );

  public terminateSession$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthApiActionTypes.TerminateSession),
        tap(() => {
          this.terminateSession();
        })
      ),
    { dispatch: false }
  );

  private terminateSession(): void {
    this.authService.clearSession();
    this.window.location.reload();
  }
}
