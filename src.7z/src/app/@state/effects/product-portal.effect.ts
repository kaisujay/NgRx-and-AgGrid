import { Injectable } from '@angular/core';
import { ProductPortalService } from '@core/services/product-portal/product-portal.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import {
  LoadProductPortalAction,
  LoadProductPortalFailureAction,
  LoadProductPortalSuccessAction,
  ProductPortalApiTypes
} from '../actions/product-portal.actions';

@Injectable()
export class ProductPortalEffect {
  public constructor(
    private actions$: Actions,
    private productPortalSvc: ProductPortalService
  ) {}
  public loadProducPortalEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductPortalApiTypes.LoadProductPortal),
      switchMap((_action: LoadProductPortalAction) => {
        return this.productPortalSvc.getProductPortalSettings().pipe(
          map(producPortalData => new LoadProductPortalSuccessAction(producPortalData)),
          catchError(_ => of(new LoadProductPortalFailureAction()))
        );
      })
    )
  );
}
