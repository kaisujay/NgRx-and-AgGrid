import { Injectable } from '@angular/core';
import { AuthService } from '@core/services/auth/auth.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import {
  AuthApiActionTypes,
  ChangePasswordAction,
  ChangePasswordFailureAction,
  ChangePasswordSuccessAction
} from '@state/actions/auth-api.actions';
import { catchError, map, of, switchMap } from 'rxjs';

@Injectable()
export class ChangePasswordEffect {
  public constructor(
    private actions$: Actions,
    private _authSvc: AuthService
  ) {}
  public changePassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthApiActionTypes.ChangePassword),
      map((action: ChangePasswordAction) => action.payload),
      switchMap(payload =>
        of(payload).pipe(
          switchMap(payload =>
            this._authSvc.changePassword(payload).pipe(
              map(_ => {
                return { success: true };
              }),
              catchError(err => {
                return of({ success: false, ...err });
              })
            )
          ),
          map((response: any) => {
            return response.success ? new ChangePasswordSuccessAction() : new ChangePasswordFailureAction(response);
          })
        )
      )
    )
  );
}
