import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LogMessages } from '@core/components/logging-error-handle/@states/actions/logging-error-handle.action';
import { getLogsState } from '@core/components/logging-error-handle/@states/reducers/logging-error-handle.reducer';
import { PortalLoggingModel } from '@core/components/logging-error-handle/models/logger-error-handle.model';
import { xsrfTokenStorageKey } from '@core/constants/constants';
import { AuthService } from '@core/services/auth/auth.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import {
  AuthApiActionTypes,
  LoginAction,
  LoginFailedAction,
  LoginSuccessAction
} from '@state/actions/auth-api.actions';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { UserSessionContextResponse } from 'src/app/modules/login/models/login.model';
import { StorageService } from 'src/app/shared/services/storage.service';

@Injectable()
export class LoginEffect {
  private portalLoggingModel: PortalLoggingModel;
  private userEmail: string;

  public constructor(
    private actions$: Actions,
    private authSvc: AuthService,
    private store: Store,
    private storageService: StorageService,
    private userContextSvc: UserContextService,
    private router: Router
  ) {}
  public login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthApiActionTypes.Login),
      map((action: LoginAction) => action.payload),
      switchMap(payload =>
        of(payload).pipe(
          // authenticate
          switchMap(payload =>
            this.authSvc.login(payload).pipe(
              map(loginResponse => {
                return {
                  success: true,
                  ...loginResponse
                };
              }),
              catchError(err => {
                return of({ success: false, ...err });
              })
            )
          ),
          // set xsrf token
          switchMap(loginResponse => {
            if (!loginResponse.success) return of(loginResponse);
            return this.userContextSvc.getContext().pipe(
              map((contextResponse: UserSessionContextResponse) => {
                if (contextResponse.xsrf_token) {
                  this.authSvc.setXsrfToken(contextResponse.xsrf_token);
                } else {
                  this.storageService.removeItem(xsrfTokenStorageKey);
                }
                delete contextResponse['xsrf_token'];
                return {
                  ...loginResponse,
                  ...contextResponse
                };
              }),
              catchError(err => {
                return of({
                  success: false,
                  ...err
                });
              })
            );
          }),
          map(response => {
            return response.success ? new LoginSuccessAction(response) : new LoginFailedAction(response);
          })
        )
      )
    )
  );

  public loginSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthApiActionTypes.LoginSuccess),
        map((action: LoginSuccessAction) => action.payload),
        switchMap(payload =>
          of(payload).pipe(
            tap((contextResponse: any) => {
              if (contextResponse.success) {
                this.userEmail = contextResponse.context.Email;
                this.logging();
                this.router.navigate(['/containers']);
              }
            })
          )
        )
      ),
    { dispatch: false }
  );

  private logging() {
    this.store.pipe(select(getLogsState)).subscribe(data => {
      this.portalLoggingModel = {
        EntryDate: new Date(),
        ElementsClicked: data.elementsClicked,
        HttpRequests: data.httpRequests,
        NgrxActions: data.ngrxActions,
        UserEmail: this.userEmail,
        BrowserVersion: window.navigator.userAgent,
        Message: 'Portal Logging'
      };
    });

    this.store.dispatch(new LogMessages(this.portalLoggingModel));
  }
}
