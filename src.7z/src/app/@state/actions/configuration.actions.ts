import { BspAdminConfiguration } from '@core/components/models/configuration.model';
import { Action } from '@ngrx/store';

export const ConfigurationActionTypes = {
  ConfigurationLoad: '[Configuration] Load'
};

export class ConfigurationLoadAction implements Action {
  public readonly type: string = ConfigurationActionTypes.ConfigurationLoad;
  public constructor(public payload: BspAdminConfiguration) {}
}

export type ConfigurationActionsUnion = ConfigurationLoadAction;
