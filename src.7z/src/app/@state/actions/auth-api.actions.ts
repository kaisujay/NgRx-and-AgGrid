import { HttpErrorResponse } from '@angular/common/http';
import { ChangePassword } from '@core/components/models/change-password.model';
import { Action } from '@ngrx/store';
import { LoginSuccessResponse, UserSessionContext } from 'src/app/modules/login/models/login.model';
import { UserCredentials } from 'src/app/modules/login/models/user-credentials.model';

export enum AuthApiActionTypes {
  Login = '[Auth] Login',
  LoginSuccess = '[Auth] Login Success',
  LoginFailed = '[Auth] Login Failed',

  TerminateSession = '[Auth] Terminate Session',
  RestoreSession = '[Auth] Restore Session',

  ChangePassword = '[Auth] Change Password',
  ChangePasswordSuccess = '[Auth] Change Password Success',
  ChangePasswordFailure = '[Auth] Change Password Failure',

  SettingsUpdated = '[Auth] Settings Updated',

  Logout = '[Auth] Logout Init'
}

export class LoginAction implements Action {
  public readonly type = AuthApiActionTypes.Login;

  public constructor(public payload: UserCredentials) {}
}

export class LoginSuccessAction implements Action {
  public readonly type = AuthApiActionTypes.LoginSuccess;

  public constructor(public payload: LoginSuccessResponse) {}
}

export class LoginFailedAction implements Action {
  public readonly type = AuthApiActionTypes.LoginFailed;

  public constructor(public payload: HttpErrorResponse) {}
}

export class TerminateSessionAction implements Action {
  public readonly type = AuthApiActionTypes.TerminateSession;

  public constructor() {}
}

export class RestoreSessionAction implements Action {
  public readonly type = AuthApiActionTypes.RestoreSession;

  public constructor(public payload: any) {}
}

export class LogoutAction implements Action {
  public readonly type = AuthApiActionTypes.Logout;

  public constructor() {}
}

export class ChangePasswordAction implements Action {
  public readonly type = AuthApiActionTypes.ChangePassword;

  public constructor(public payload: ChangePassword) {}
}

export class ChangePasswordSuccessAction implements Action {
  public readonly type = AuthApiActionTypes.ChangePasswordSuccess;

  public constructor() {}
}

export class SettingsUpdatedAction implements Action {
  public readonly type = AuthApiActionTypes.SettingsUpdated;

  public constructor(public payload: UserSessionContext) {}
}

export class ChangePasswordFailureAction implements Action {
  public readonly type = AuthApiActionTypes.ChangePasswordFailure;

  public constructor(public payload: any) {}
}

export type AuthApiActionsUnion =
  | LoginAction
  | LoginSuccessAction
  | LoginFailedAction
  | TerminateSessionAction
  | RestoreSessionAction
  | ChangePasswordAction
  | ChangePasswordSuccessAction
  | ChangePasswordFailureAction
  | LogoutAction
  | SettingsUpdatedAction;
