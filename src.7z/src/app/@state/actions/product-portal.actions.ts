import { Action } from '@ngrx/store';
import { ProductPortalSettings } from '@state/reducers/product-portal.reducer';

export enum ProductPortalApiTypes {
  LoadProductPortal = '[ProductPortal] Load Product Portal Data',
  LoadProductPortalSuccess = '[ProductPortal] Load Product Portal Data Success',
  LoadProductPortalFailure = '[ProductPortal] Load Product Portal Data Failure'
}

export class LoadProductPortalAction implements Action {
  public readonly type = ProductPortalApiTypes.LoadProductPortal;

  public constructor() {}
}

export class LoadProductPortalSuccessAction implements Action {
  public readonly type = ProductPortalApiTypes.LoadProductPortalSuccess;

  public constructor(public payload: ProductPortalSettings) {}
}

export class LoadProductPortalFailureAction implements Action {
  public readonly type = ProductPortalApiTypes.LoadProductPortalFailure;

  public constructor() {}
}

export type ProductPortalActionsUnion =
  | LoadProductPortalAction
  | LoadProductPortalSuccessAction
  | LoadProductPortalFailureAction;
