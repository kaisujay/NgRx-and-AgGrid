import { WarningType } from '@core/constants/constants';
import { AuthHelperService } from '@core/services/auth/auth-helper.service';
import { UserSessionContext } from 'src/app/modules/login/models/login.model';
import * as fromAuthApiActions from '../actions/auth-api.actions';
import { AuthApiActionTypes } from '../actions/auth-api.actions';

export interface ChangePasswordState {
  isLoading: boolean;
  warning: string;
  success: boolean;
}
export interface AuthState {
  isLoggedIn: boolean;
  isLoading: boolean;
  success: boolean;
  warning: WarningType;
  context: UserSessionContext;
  ChangePassword: ChangePasswordState;
}

export const initialState: AuthState = {
  isLoggedIn: false,
  isLoading: false,
  warning: null,
  success: false,
  context: {
    PasswordChangeRequired: false
  } as UserSessionContext,
  ChangePassword: {
    isLoading: false,
    warning: null,
    success: false
  }
};

export function authReducer(
  state: AuthState = initialState,
  action: fromAuthApiActions.AuthApiActionsUnion
): AuthState {
  switch (action.type) {
    case AuthApiActionTypes.Login:
      return {
        ...state,
        isLoading: true
      };

    case AuthApiActionTypes.LoginSuccess:
      return {
        ...state,
        isLoggedIn: true,
        success: true,
        ...action.payload,
        isLoading: false
      };

    case AuthApiActionTypes.TerminateSession:
      return {
        ...state,
        ...initialState
      };

    case AuthApiActionTypes.LoginFailed:
      return {
        ...state,
        success: false,
        warning: AuthHelperService.getLoginErrorResponse(action.payload),
        isLoading: false
      };

    case AuthApiActionTypes.ChangePassword:
      return {
        ...state,
        ChangePassword: {
          isLoading: true,
          warning: null,
          success: false
        }
      };

    case AuthApiActionTypes.ChangePasswordSuccess:
      return {
        ...state,
        context: {
          ...state.context,
          PasswordChangeRequired: false
        },
        ChangePassword: {
          isLoading: false,
          success: true,
          warning: null
        }
      };

    case AuthApiActionTypes.SettingsUpdated:
      return {
        ...state,
        context: {
          ...state.context,
          ...action.payload
        }
      };

    case AuthApiActionTypes.ChangePasswordFailure:
      return {
        ...state,
        ChangePassword: {
          isLoading: false,
          warning: AuthHelperService.getChangePasswordErrorResponse(action.payload),
          success: false
        }
      };

    case AuthApiActionTypes.RestoreSession:
      return {
        ...state,
        isLoggedIn: true,
        success: true,
        ...action.payload,
        isLoading: false
      };

    default:
      return state;
  }
}
