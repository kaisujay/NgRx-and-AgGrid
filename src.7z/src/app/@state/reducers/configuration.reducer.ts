import { BspAdminConfiguration } from '@core/components/models/configuration.model';
import { createFeatureSelector } from '@ngrx/store';
import { ConfigurationActionTypes, ConfigurationActionsUnion } from '../actions/configuration.actions';

const storeDefaultValue: BspAdminConfiguration = null;

export function configurationReducer(
  state: BspAdminConfiguration = storeDefaultValue,
  action: ConfigurationActionsUnion
): BspAdminConfiguration {
  switch (action.type) {
    case ConfigurationActionTypes.ConfigurationLoad:
      return action.payload;
    default:
      return state;
  }
}

export const getConfigState = createFeatureSelector<BspAdminConfiguration>('configuration');
