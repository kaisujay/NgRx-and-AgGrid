import { createFeatureSelector } from '@ngrx/store';
import { ProductPortalActionsUnion, ProductPortalApiTypes } from '@state/actions/product-portal.actions';

export interface ProductPortalSettingsStore {
  isLoading: boolean;
  isDataLoaded: boolean;
  isError: boolean;
  settings: ProductPortalSettings;
}

export interface ProductPortalSettings {
  AccountXEnabled: boolean;
  AnalyticsQuicksightEnabled: boolean;
  BDAgentEnabled: boolean;
  BuzzTheBankEnabled: boolean;
  ComplianceEnabled: boolean;
  EmailTesting: boolean;
  EquityAllocationsEnabled: boolean;
  EquityAnalyticsEnabled: boolean;
  EquityDealServiceEnabled: boolean;
  EquityOrderServiceEnabled: boolean;
  EquityOrdersEnabled: boolean;
  HundSunOrdersEnabled: boolean;
  InternalCommentsAndAlertingEnabled: boolean;
  InternalExternalTotalEnabled: boolean;
  IpreoAccountEnabled: boolean;
  MuniConnectionsEnabled: boolean;
  NewBspPagesEnabled: boolean;
  OperationalEntitiesEnable: boolean;
  ResetPasswordTokenTTLMinutes: number;
  RowVersion: number;
  SendUpdatesToVendors: boolean;
  SplitDeliveryEnabled: boolean;
  FTREmailNotificationEnabled: boolean;
}

const initProductSettings: ProductPortalSettingsStore = {
  isDataLoaded: false,
  isLoading: true,
  isError: false,
  settings: null
};

export function productPortalReducer(
  state: ProductPortalSettingsStore = initProductSettings,
  action: ProductPortalActionsUnion
): ProductPortalSettingsStore {
  switch (action.type) {
    case ProductPortalApiTypes.LoadProductPortal:
      return {
        ...state,
        isLoading: true,
        isDataLoaded: false,
        isError: false
      };
    case ProductPortalApiTypes.LoadProductPortalSuccess:
      return {
        ...state,
        isLoading: true,
        isDataLoaded: true,
        isError: false,
        settings: action.payload
      };

    case ProductPortalApiTypes.LoadProductPortalFailure:
      return {
        ...state,
        isLoading: false,
        isDataLoaded: false,
        isError: true
      };
    default:
      return state;
  }
}

export const getProductPortalSettings = createFeatureSelector<ProductPortalSettings>('productPortalSettings');
