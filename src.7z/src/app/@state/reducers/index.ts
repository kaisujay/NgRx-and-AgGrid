import { BspAdminConfiguration } from '@core/components/models/configuration.model';
import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromAuth from '../reducers/auth.reducer';
import * as fromConfigReducer from './configuration.reducer';
import * as fromProductReduce from './product-portal.reducer';

export interface AppState {
  auth: fromAuth.AuthState;
  configuration: BspAdminConfiguration;
  productPortalSettings: fromProductReduce.ProductPortalSettingsStore;
}

export const reducers: ActionReducerMap<AppState> = {
  auth: fromAuth.authReducer,
  configuration: fromConfigReducer.configurationReducer,
  productPortalSettings: fromProductReduce.productPortalReducer
};

export const getAuthState = createFeatureSelector<fromAuth.AuthState>('auth');
export const getIsLoggedIn = createSelector(getAuthState, authState => authState.isLoggedIn);

export const userContext = createSelector(getAuthState, authState => authState.context);

export const isPasswordChangeRequired = createSelector(
  getAuthState,
  authState => authState.context.PasswordChangeRequired
);

export const changePasswordStatus = createSelector(getAuthState, authState => authState.ChangePassword);
