import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterEvent } from '@angular/router';
import {
  AddElementClicked,
  LogMessages
} from '@core/components/logging-error-handle/@states/actions/logging-error-handle.action';
import { getLogsState } from '@core/components/logging-error-handle/@states/reducers/logging-error-handle.reducer';
import { PortalLoggingModel } from '@core/components/logging-error-handle/models/logger-error-handle.model';
import { composeElementSelector } from '@core/utils/util';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Store, select } from '@ngrx/store';
import { WINDOW } from '@shared/services/window.service';
import { LogoutAction } from '@state/actions/auth-api.actions';
import { LoadProductPortalAction } from '@state/actions/product-portal.actions';
import { getAuthState, getIsLoggedIn, isPasswordChangeRequired } from '@state/reducers';
import { getConfigState } from '@state/reducers/configuration.reducer';
import { Observable, filter } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public isLoggedIn$: Observable<boolean>;
  public isPasswordChangeRequired$: Observable<boolean>;

  public childModal = false;
  public countdown: number;
  public TIMEOUT_WARNING: number;
  public COUNTDOWN_WARNING: number;

  public activeUrl: string;

  public idleState = 'Not started.';
  public timedOut = false;
  public lastPing?: Date = null;
  public tracking: any;
  public portalLoggingModel: PortalLoggingModel;
  public userEmail: string;

  public constructor(
    private store: Store,
    private idle: Idle,
    @Inject(WINDOW) private window: Window,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.activeUrl = this.route.snapshot['_routerState'].url;

    this.store.pipe(select(getConfigState)).subscribe(data => {
      this.TIMEOUT_WARNING = data.sessionNotifyTimeout;
      this.COUNTDOWN_WARNING = data.sessionLogoutTimeout;
    });

    this.router.events
      .pipe(
        filter(event => {
          return event instanceof NavigationEnd;
        })
      )
      .subscribe((event: RouterEvent) => {
        this.activeUrl = this.route.snapshot['_routerState'].url;

        if (!this.activeUrl.includes('login')) {
          idle.setIdle(this.TIMEOUT_WARNING * 60);
          idle.setTimeout(this.COUNTDOWN_WARNING * 60);
          // idle.setIdle(2); // Keeping for quick test only
          // idle.setTimeout(2); // Keeping for quick test only
        }
      });

    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle';
      this.reset();
    });

    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out';
      this.timedOut = true;
      this.childModal = false;

      this.store.dispatch(new LogoutAction());
    });

    idle.onIdleStart.subscribe(() => {
      this.idleState = 'You have gone idle';
      this.childModal = true;
    });

    idle.onTimeoutWarning.subscribe(countdown => {
      this.idleState = 'You will time out in ' + countdown + ' seconds';
      this.countdown = countdown;
    });

    this.reset();
  }

  private reset() {
    this.idle.watch();
    this.idleState = 'Started';
    this.timedOut = false;
  }

  public ngOnInit(): void {
    this.isLoggedIn$ = this.store.pipe(select(getIsLoggedIn));
    this.isPasswordChangeRequired$ = this.store.pipe(select(isPasswordChangeRequired));
    this.store.dispatch(new LoadProductPortalAction());

    this.isLoggedIn$.subscribe(data => {
      if (data === true) {
        this.startTrackingLoopForPortalLogging();
      }
    });

    this.window.addEventListener('click', (event: MouseEvent) => this.onClientAction(event.target));
    this.window.addEventListener('keypress', (event: KeyboardEvent) => this.onClientAction(event.target));
  }

  public startTrackingLoopForPortalLogging() {
    this.store.pipe(select(getAuthState)).subscribe(data => {
      this.userEmail = data.context.Email;
    });

    this.tracking = setInterval(() => {
      this.store.pipe(select(getLogsState)).subscribe(data => {
        this.portalLoggingModel = {
          EntryDate: new Date(),
          ElementsClicked: data.elementsClicked,
          HttpRequests: data.httpRequests,
          NgrxActions: data.ngrxActions,
          UserEmail: this.userEmail,
          BrowserVersion: window.navigator.userAgent,
          Message: 'Portal Logging'
        };
      });

      this.store.dispatch(new LogMessages(this.portalLoggingModel));
    }, 480000);
  }

  private onClientAction(target: EventTarget): void {
    const el = target as HTMLElement;

    const elementSelector: string = composeElementSelector(el);

    this.store.dispatch(new AddElementClicked({ elementClicked: elementSelector }));
  }
}
