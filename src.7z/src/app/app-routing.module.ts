import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@core/gaurds/auth.gaurd';
import { LoggedInAuthGaurd } from '@core/gaurds/logged-in-auth.gaurd';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'containers',
    pathMatch: 'full'
  },
  {
    path: 'login',
    canActivate: [LoggedInAuthGaurd],
    loadChildren: () => import('./modules/login/login.module').then(m => m.LoginModule)
  },
  {
    path: 'users/admin',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/admin-users/admin-users.module').then(m => m.AdminUsersModule)
  },
  {
    path: 'users/product',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/product-users/product-users.module').then(m => m.ProductUsersModule)
  },
  {
    path: 'containers',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/containers/containers.module').then(m => m.ContainersModule)
  },
  {
    path: 'containers/:containerId',
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./modules/container-wrapper/container-wrapper.module').then(m => m.ContainerWrapperModule)
  },
  {
    path: 'settings',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/settings-wrapper/settings-wrapper.module').then(m => m.SettingsWrapperModule)
  },
  {
    path: 'accountsettings',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/account-settings/account-settings.module').then(m => m.AccountSettingsModule)
  },
  {
    path: 'termsOfUse',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/terms-of-use/terms-of-use.module').then(m => m.TermsOfUseModule)
  },
  {
    path: 'attestation',
    canActivate: [AuthGuard],
    loadChildren: () =>
      import('./modules/attestation-manager/attestation-manager.module').then(m => m.AttestationManagerModule)
  },
  {
    path: 'reporting',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/reporting/reporting.module').then(m => m.ReportingModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      anchorScrolling: 'enabled',
      useHash: true,
      scrollPositionRestoration: 'top'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
