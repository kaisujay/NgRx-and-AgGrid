import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePickerModule, LoaderModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { JurisdictionManagerAttestationEffects } from './@state/effects/jurisdiction-attestation-operations.effect';
import { LoadJurisdictionDataEffect } from './@state/effects/load-jurisdiction-manager.effect';
import { LoadMuaManagerDataEffect } from './@state/effects/load-mua-manager.effect';
import { MuaManagerAttestationEffects } from './@state/effects/mua-attestation-operations.effect';
import { SaveJurisdictionDataEffect } from './@state/effects/save-jurisdiction-manager.effect';
import { SaveMuaManagerDataEffect } from './@state/effects/save-mua-manager.effect';
import { AttestationManagerReducers } from './@state/reducers/attestation-manager.reducer';
import { AttestationManagerRoutingModule } from './attestation-manager-routing.module';
import { JurisdictionManagerComponent } from './components/jurisdiction-manager/jurisdiction-manager.component';
import { MuaManagerComponent } from './components/mua-manager/mua-manager.component';
import { AttestationManagerService } from './services/attestation-manager.service';

@NgModule({
  declarations: [MuaManagerComponent, JurisdictionManagerComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DatePickerModule,
    AdminSharedModule,
    LoaderModule,
    SPRFormsModule,
    AttestationManagerRoutingModule,
    StoreModule.forFeature('attestationManager', AttestationManagerReducers),
    EffectsModule.forFeature([
      LoadMuaManagerDataEffect,
      LoadJurisdictionDataEffect,
      MuaManagerAttestationEffects,
      SaveMuaManagerDataEffect,
      SaveJurisdictionDataEffect,
      JurisdictionManagerAttestationEffects
    ])
  ],
  providers: [AttestationManagerService]
})
export class AttestationManagerModule {}
