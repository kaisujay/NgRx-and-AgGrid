import { Action } from '@ngrx/store';
import { MuaManagerResponse } from '../../models/attestation-manager.model';

export enum MuaManagerActionTypes {
  LoadMuaManager = '[MuaManager] Load MuaManager',
  LoadMuaManagerSuccess = '[MuaManager] Load MuaManager Success',
  LoadMuaManagerFailed = '[MuaManager] Load MuaManager Failed',

  AttestMuaManagerByDate = '[MuaManager] Attest MuaManager By Date',
  AttestMuaManagerByDateSuccess = '[MuaManager] Attest MuaManager By Date Success',
  AttestMuaManagerByDateFailed = '[MuaManager] Attest MuaManager By Date Failed',

  AttestMuaManagerByOrionIds = '[MuaManager] Attest MuaManager By Orion Ids',
  AttestMuaManagerByOrionIdsSuccess = '[MuaManager] Attest MuaManager By Orion Ids Success',
  AttestMuaManagerByOrionIdsFailed = '[MuaManager] Attest MuaManager By Orion Ids Failed',

  SaveMuaManager = '[MuaManager] Save MuaManager',
  SaveMuaManagerSuccess = '[MuaManager] Save MuaManager Success',
  SaveMuaManagerFailed = '[MuaManager] Save MuaManager Failed'
}

export class LoadMuaManagerAction implements Action {
  public readonly type = MuaManagerActionTypes.LoadMuaManager;
  public constructor() {}
}

export class LoadMuaManagerSuccessAction implements Action {
  public readonly type = MuaManagerActionTypes.LoadMuaManagerSuccess;
  public constructor(public payload: MuaManagerResponse) {}
}

export class LoadMuaManagerFailedAction implements Action {
  public readonly type = MuaManagerActionTypes.LoadMuaManagerFailed;
  public constructor() {}
}

export class AttestMuaManagerByDateAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByDate;
  public constructor(public payload: string) {}
}

export class AttestMuaManagerByDateSuccessAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByDateSuccess;
  public constructor() {}
}

export class AttestMuaManagerByDateFailedAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByDateFailed;
  public constructor() {}
}

export class AttestMuaManagerByOrionIdsAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByOrionIds;
  public constructor(public payload: string) {}
}

export class AttestMuaManagerByOrionIdsSuccessAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByOrionIdsSuccess;
  public constructor() {}
}

export class AttestMuaManagerByOrionIdsFailedAction implements Action {
  public readonly type = MuaManagerActionTypes.AttestMuaManagerByOrionIdsFailed;
  public constructor() {}
}

export class SaveMuaManagerAction implements Action {
  public readonly type = MuaManagerActionTypes.SaveMuaManager;
  public constructor(public payload: string) {}
}

export class SaveMuaManagerSuccessAction implements Action {
  public readonly type = MuaManagerActionTypes.SaveMuaManagerSuccess;
  public constructor(public payload: MuaManagerResponse) {}
}

export class SaveMuaManagerFailedAction implements Action {
  public readonly type = MuaManagerActionTypes.SaveMuaManagerFailed;
  public constructor() {}
}

export type MuaManagerActionUnion =
  | LoadMuaManagerAction
  | LoadMuaManagerSuccessAction
  | LoadMuaManagerFailedAction
  | AttestMuaManagerByDateAction
  | AttestMuaManagerByDateSuccessAction
  | AttestMuaManagerByDateFailedAction
  | AttestMuaManagerByOrionIdsAction
  | AttestMuaManagerByOrionIdsSuccessAction
  | AttestMuaManagerByOrionIdsFailedAction
  | SaveMuaManagerAction
  | SaveMuaManagerSuccessAction
  | SaveMuaManagerFailedAction;
