import { Action } from '@ngrx/store';
import { JurisdictionManagerResponse } from '../../models/attestation-manager.model';

export enum JurisdictionActionTypes {
  LoadJurisdiction = '[Jurisdiction] Load Jurisdiction',
  LoadJurisdictionSuccess = '[Jurisdiction] Load Jurisdiction Success',
  LoadJurisdictionFailed = '[Jurisdiction] Load Jurisdiction Failed',

  AttestJurisdictionManagerByDate = '[Jurisdiction] Attest Jurisdiction By Date',
  AttestJurisdictionManagerByDateSuccess = '[Jurisdiction] Attest Jurisdiction By Date Success',
  AttestJurisdictionManagerByDateFailed = '[Jurisdiction] Attest Jurisdiction By Date Failed',

  AttestJurisdictionManagerByOrionIds = '[Jurisdiction] Attest Jurisdiction By Orion Ids',
  AttestJurisdictionManagerByOrionIdsSuccess = '[Jurisdiction] Attest Jurisdiction By Orion Ids Success',
  AttestJurisdictionManagerByOrionIdsFailed = '[Jurisdiction] Attest Jurisdiction By Orion Ids Failed',

  SaveJurisdictionManager = '[Jurisdiction] Save Jurisdiction',
  SaveJurisdictionManagerSuccess = '[Jurisdiction] Save Jurisdiction Success',
  SaveJurisdictionManagerFailed = '[Jurisdiction] Save Jurisdiction Failed'
}

export class LoadJurisdictionAction implements Action {
  public readonly type = JurisdictionActionTypes.LoadJurisdiction;
  public constructor() {}
}

export class LoadJurisdictionSuccessAction implements Action {
  public readonly type = JurisdictionActionTypes.LoadJurisdictionSuccess;
  public constructor(public payload: JurisdictionManagerResponse[]) {}
}

export class LoadJurisdictionFailedAction implements Action {
  public readonly type = JurisdictionActionTypes.LoadJurisdictionFailed;
  public constructor() {}
}

export class AttestJurisdictionManagerByDateAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByDate;
  public constructor(public payload: string) {}
}

export class AttestJurisdictionManagerByDateSuccessAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByDateSuccess;
  public constructor() {}
}

export class AttestJurisdictionManagerByDateFailedAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByDateFailed;
  public constructor() {}
}

export class AttestJurisdictionManagerByOrionIdsAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByOrionIds;
  public constructor(public payload: string) {}
}

export class AttestJurisdictionManagerByOrionIdsSuccessAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByOrionIdsSuccess;
  public constructor() {}
}

export class AttestJurisdictionManagerByOrionIdsFailedAction implements Action {
  public readonly type = JurisdictionActionTypes.AttestJurisdictionManagerByOrionIdsFailed;
  public constructor() {}
}

export class SaveJurisdictionManagerAction implements Action {
  public readonly type = JurisdictionActionTypes.SaveJurisdictionManager;
  public constructor(public payload: Partial<JurisdictionManagerResponse>) {}
}

export class SaveJurisdictionManagerSuccessAction implements Action {
  public readonly type = JurisdictionActionTypes.SaveJurisdictionManagerSuccess;
  public constructor(public payload: JurisdictionManagerResponse) {}
}

export class SaveJurisdictionManagerFailedAction implements Action {
  public readonly type = JurisdictionActionTypes.SaveJurisdictionManagerFailed;
  public constructor() {}
}

export type JurisdictionManagerActionUnion =
  | LoadJurisdictionAction
  | LoadJurisdictionSuccessAction
  | LoadJurisdictionFailedAction
  | AttestJurisdictionManagerByDateAction
  | AttestJurisdictionManagerByDateSuccessAction
  | AttestJurisdictionManagerByDateFailedAction
  | AttestJurisdictionManagerByOrionIdsAction
  | AttestJurisdictionManagerByOrionIdsSuccessAction
  | AttestJurisdictionManagerByOrionIdsFailedAction
  | SaveJurisdictionManagerAction
  | SaveJurisdictionManagerSuccessAction
  | SaveJurisdictionManagerFailedAction;
