import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';
import { JurisdictionManagerReducer, JurisdictionManagerState } from './jurisdiction.reducer';
import { MuaManagerReducer, MuaManagerState } from './mua-manager.reducer';

export interface AttestationManagerState {
  MuaManagerState: MuaManagerState;
  JurisdictionManagerState: JurisdictionManagerState;
}

export const AttestationManagerReducers: ActionReducerMap<AttestationManagerState> = {
  MuaManagerState: MuaManagerReducer,
  JurisdictionManagerState: JurisdictionManagerReducer
};
export const getAttestationManagerState = createFeatureSelector('attestationManager');
export const getAttestationMuaManagerState = createSelector(
  getAttestationManagerState,
  (state: AttestationManagerState) => state.MuaManagerState
);

export const getAttestationMuaManagerStateData = createSelector(
  getAttestationManagerState,
  (state: AttestationManagerState) => state.MuaManagerState.data
);
export const getAttestationJurisdictionManagerState = createSelector(
  getAttestationManagerState,
  (state: AttestationManagerState) => state.JurisdictionManagerState
);

export const getAttestationJurisdictionManagerStateData = createSelector(
  getAttestationManagerState,
  (state: AttestationManagerState) => state.JurisdictionManagerState.data
);
