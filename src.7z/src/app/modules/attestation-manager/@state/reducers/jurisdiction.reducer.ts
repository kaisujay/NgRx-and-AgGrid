import { JurisdictionManagerResponse } from '../../models/attestation-manager.model';
import { JurisdictionActionTypes, JurisdictionManagerActionUnion } from '../actions/jurisdiction-manager.actions';
import { SaveOperation, initialSaveOperation } from './mua-manager.reducer';

export interface JurisdictionManagerState {
  data: JurisdictionManagerResponse[];
  isLoading: boolean;
  jurisditcionTextSave: SaveOperation;
  attestByDate: SaveOperation;
  attestByOrionIds: SaveOperation;
  isLoadSuccess: boolean;
  isLoadError: boolean;
}
const initialMuaState: JurisdictionManagerState = {
  data: null,
  jurisditcionTextSave: initialSaveOperation,
  attestByDate: initialSaveOperation,
  attestByOrionIds: initialSaveOperation,
  isLoading: false,
  isLoadSuccess: false,
  isLoadError: false
};

export function JurisdictionManagerReducer(
  state = initialMuaState,
  action: JurisdictionManagerActionUnion
): JurisdictionManagerState {
  switch (action.type) {
    case JurisdictionActionTypes.LoadJurisdiction: {
      return {
        ...state,
        isLoading: true,
        isLoadSuccess: false,
        isLoadError: false
      };
    }
    case JurisdictionActionTypes.LoadJurisdictionSuccess: {
      return {
        ...state,
        data: action.payload,
        isLoading: false,
        isLoadSuccess: true,
        isLoadError: false
      };
    }
    case JurisdictionActionTypes.LoadJurisdictionFailed: {
      return {
        ...state,
        isLoading: false,
        isLoadSuccess: false,
        isLoadError: true
      };
    }
    case JurisdictionActionTypes.SaveJurisdictionManager: {
      return {
        ...state,
        jurisditcionTextSave: {
          ...state.jurisditcionTextSave,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.SaveJurisdictionManagerSuccess: {
      return {
        ...state,
        jurisditcionTextSave: {
          ...state.jurisditcionTextSave,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.SaveJurisdictionManagerFailed: {
      return {
        ...state,
        jurisditcionTextSave: {
          ...state.jurisditcionTextSave,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByDate: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByDateSuccess: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByDateFailed: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByOrionIds: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByOrionIdsSuccess: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case JurisdictionActionTypes.AttestJurisdictionManagerByOrionIdsFailed: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    default: {
      return {
        ...state
      };
    }
  }
}
