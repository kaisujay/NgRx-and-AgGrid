import { MuaManagerResponse } from '../../models/attestation-manager.model';
import { MuaManagerActionTypes, MuaManagerActionUnion } from '../actions/mua-manager.actions';

export interface SaveOperation {
  isSaving: boolean;
  isSaveSuccess: boolean;
  isSaveError: boolean;
}

export const initialSaveOperation: SaveOperation = {
  isSaving: false,
  isSaveSuccess: false,
  isSaveError: false
};

export interface MuaManagerState {
  data: MuaManagerResponse;
  muaTextSave: SaveOperation;
  attestByDate: SaveOperation;
  attestByOrionIds: SaveOperation;
  isLoading: boolean;
  isLoadSuccess: boolean;
  isLoadError: boolean;
}

const initialMuaState: MuaManagerState = {
  data: null,
  muaTextSave: initialSaveOperation,
  attestByDate: initialSaveOperation,
  attestByOrionIds: initialSaveOperation,
  isLoading: false,
  isLoadSuccess: false,
  isLoadError: false
};

export function MuaManagerReducer(state = initialMuaState, action: MuaManagerActionUnion): MuaManagerState {
  switch (action.type) {
    case MuaManagerActionTypes.LoadMuaManager: {
      return {
        ...state,
        isLoading: true,
        isLoadSuccess: false,
        isLoadError: false
      };
    }
    case MuaManagerActionTypes.LoadMuaManagerSuccess: {
      return {
        ...state,
        data: action.payload,
        isLoading: false,
        isLoadSuccess: true,
        isLoadError: false
      };
    }
    case MuaManagerActionTypes.LoadMuaManagerFailed: {
      return {
        ...state,
        isLoading: false,
        isLoadSuccess: false,
        isLoadError: true
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByDate: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByDateSuccess: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByDateFailed: {
      return {
        ...state,
        attestByDate: {
          ...state.attestByDate,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByOrionIds: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByOrionIdsSuccess: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.AttestMuaManagerByOrionIdsFailed: {
      return {
        ...state,
        attestByOrionIds: {
          ...state.attestByOrionIds,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    case MuaManagerActionTypes.SaveMuaManager: {
      return {
        ...state,
        muaTextSave: {
          ...state.muaTextSave,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.SaveMuaManagerSuccess: {
      return {
        ...state,
        data: action.payload,
        muaTextSave: {
          ...state.muaTextSave,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    }
    case MuaManagerActionTypes.SaveMuaManagerFailed: {
      return {
        ...state,
        muaTextSave: {
          ...state.muaTextSave,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    default: {
      return {
        ...state
      };
    }
  }
}
