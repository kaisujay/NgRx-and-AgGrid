import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { JurisdictionManagerResponse } from '../../models/attestation-manager.model';
import { AttestationManagerService } from '../../services/attestation-manager.service';
import {
  JurisdictionActionTypes,
  LoadJurisdictionAction,
  SaveJurisdictionManagerAction,
  SaveJurisdictionManagerFailedAction,
  SaveJurisdictionManagerSuccessAction
} from '../actions/jurisdiction-manager.actions';

@Injectable()
export class SaveJurisdictionDataEffect {
  public constructor(
    private actions$: Actions,
    private store: Store,
    private attestationManagerSvc: AttestationManagerService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public saveJurisdictionManagerEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(JurisdictionActionTypes.SaveJurisdictionManager),
      switchMap((_action: SaveJurisdictionManagerAction) =>
        this.attestationManagerSvc.saveJurisdictionData(_action.payload).pipe(
          map(_ => this.handleSuccess(_)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: JurisdictionManagerResponse) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Jurisdiction data saved successfully');
    this.store.dispatch(new SaveJurisdictionManagerSuccessAction(res));
    return new LoadJurisdictionAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Jurisdiction data');
    return of(new SaveJurisdictionManagerFailedAction());
  }
}
