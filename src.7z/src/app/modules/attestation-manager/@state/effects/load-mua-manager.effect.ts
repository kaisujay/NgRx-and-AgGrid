import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { MuaManagerResponse } from '../../models/attestation-manager.model';
import { AttestationManagerService } from '../../services/attestation-manager.service';
import {
  LoadMuaManagerAction,
  LoadMuaManagerFailedAction,
  LoadMuaManagerSuccessAction,
  MuaManagerActionTypes
} from '../actions/mua-manager.actions';

@Injectable()
export class LoadMuaManagerDataEffect {
  public constructor(
    private actions$: Actions,
    private attestationManagerSvc: AttestationManagerService
  ) {}
  public loadMuaSettingDataEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(MuaManagerActionTypes.LoadMuaManager),
      switchMap((_action: LoadMuaManagerAction) =>
        this.attestationManagerSvc.getMuaManagerData().pipe(
          map(_ => this.handleSuccess(_)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: MuaManagerResponse) {
    return new LoadMuaManagerSuccessAction(res);
  }

  private handleError() {
    return of(new LoadMuaManagerFailedAction());
  }
}
