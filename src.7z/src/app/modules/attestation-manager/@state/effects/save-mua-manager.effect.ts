import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { MuaManagerResponse } from '../../models/attestation-manager.model';
import { AttestationManagerService } from '../../services/attestation-manager.service';
import {
  MuaManagerActionTypes,
  SaveMuaManagerAction,
  SaveMuaManagerFailedAction,
  SaveMuaManagerSuccessAction
} from '../actions/mua-manager.actions';

@Injectable()
export class SaveMuaManagerDataEffect {
  public constructor(
    private actions$: Actions,
    private attestationManagerSvc: AttestationManagerService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public saveMuaSettingDataEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(MuaManagerActionTypes.SaveMuaManager),
      switchMap((_action: SaveMuaManagerAction) =>
        this.attestationManagerSvc.saveMuaManagerData(_action.payload).pipe(
          map(_ => this.handleSuccess(_)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: MuaManagerResponse) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'MUA Manager saved successfully');
    return new SaveMuaManagerSuccessAction(res);
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving MUA Manager text');
    return of(new SaveMuaManagerFailedAction());
  }
}
