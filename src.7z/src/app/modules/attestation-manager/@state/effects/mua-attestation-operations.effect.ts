import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { AttestationManagerService } from '../../services/attestation-manager.service';
import {
  AttestMuaManagerByDateAction,
  AttestMuaManagerByDateFailedAction,
  AttestMuaManagerByDateSuccessAction,
  AttestMuaManagerByOrionIdsAction,
  AttestMuaManagerByOrionIdsFailedAction,
  AttestMuaManagerByOrionIdsSuccessAction,
  MuaManagerActionTypes
} from '../actions/mua-manager.actions';

@Injectable()
export class MuaManagerAttestationEffects {
  public constructor(
    private actions$: Actions,
    private attestationManagerSvc: AttestationManagerService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public muaAttestByDateEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(MuaManagerActionTypes.AttestMuaManagerByDate),
      switchMap((_action: AttestMuaManagerByDateAction) =>
        this.attestationManagerSvc.saveMuaAttestationByDate(_action.payload).pipe(
          map(_ => {
            this.handleSuccess('Force Re-Attestation request was submitted');
            return new AttestMuaManagerByDateSuccessAction();
          }),
          catchError(_err => {
            this.messageAlertSvc.showMessageAlert(
              CupcakeFlavors.Danger,
              'Error while processing Re-Attestation request'
            );
            return of(new AttestMuaManagerByDateFailedAction());
          })
        )
      )
    )
  );

  public muaAttestByCompanyIds$ = createEffect(() =>
    this.actions$.pipe(
      ofType(MuaManagerActionTypes.AttestMuaManagerByOrionIds),
      switchMap((_action: AttestMuaManagerByOrionIdsAction) =>
        this.attestationManagerSvc.saveMuaAttestationByCompanyIds(_action.payload).pipe(
          map(_ => {
            this.handleSuccess('Force Re-Attestation request was submitted');
            return new AttestMuaManagerByOrionIdsSuccessAction();
          }),
          catchError(_err => {
            this.handleError(_err, 'Error while processing Re-Attestation request');
            return of(new AttestMuaManagerByOrionIdsFailedAction());
          })
        )
      )
    )
  );

  private handleSuccess(alertMessage: string) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, alertMessage);
  }

  private handleError(error: HttpErrorResponse, defualtMsg: string) {
    if (error.status === 400) {
      defualtMsg = 'To Force Re-attestation By Company, A valid Company OrionID is required';
    }
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, defualtMsg);
  }
}
