import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { JurisdictionManagerResponse } from '../../models/attestation-manager.model';
import { AttestationManagerService } from '../../services/attestation-manager.service';
import {
  JurisdictionActionTypes,
  LoadJurisdictionAction,
  LoadJurisdictionFailedAction,
  LoadJurisdictionSuccessAction
} from '../actions/jurisdiction-manager.actions';

@Injectable()
export class LoadJurisdictionDataEffect {
  public constructor(
    private actions$: Actions,
    private attestationManagerSvc: AttestationManagerService
  ) {}
  public loadJurisdictionManagerEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(JurisdictionActionTypes.LoadJurisdiction),
      switchMap((_action: LoadJurisdictionAction) =>
        this.attestationManagerSvc.getJursidictionManagerData().pipe(
          map(_ => this.handleSuccess(_)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: JurisdictionManagerResponse[]) {
    return new LoadJurisdictionSuccessAction(res);
  }

  private handleError() {
    return of(new LoadJurisdictionFailedAction());
  }
}
