import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { deepClone } from '@core/constants/constants';
import { DateTimeFormatDefined, TimeZoneFormat } from '@core/models/date-time-format';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Store } from '@ngrx/store';
import * as moment from 'moment';
import { Observable, Subscription } from 'rxjs';
import {
  AttestMuaManagerByDateAction,
  AttestMuaManagerByOrionIdsAction,
  LoadMuaManagerAction,
  SaveMuaManagerAction
} from '../../@state/actions/mua-manager.actions';
import {
  getAttestationMuaManagerState,
  getAttestationMuaManagerStateData
} from '../../@state/reducers/attestation-manager.reducer';
import { MuaManagerState } from '../../@state/reducers/mua-manager.reducer';
import { MuaManagerResponse } from '../../models/attestation-manager.model';

@Component({
  selector: 'app-mua-manager',
  templateUrl: './mua-manager.component.html',
  styleUrls: ['./mua-manager.component.scss']
})
export class MuaManagerComponent implements OnInit, OnDestroy {
  public muaManagerState$: Observable<MuaManagerState>;
  public muaManagerStateData$: Observable<MuaManagerResponse>;
  public muaManagerStateData: MuaManagerResponse;
  public initialMuaManagerStateData: MuaManagerResponse;
  public attestationDate: string;
  public attestationCompanyIds: string;
  public subscriptions: Subscription[] = [];
  public userFormatSettings: DateTimeFormatDefined;
  public timeZoneFormat = TimeZoneFormat;
  public attestationDateCtrl = new FormControl(null, [Validators.required, isValidDate()]);
  public dateFormat = 'MM/DD/YYYY';

  public constructor(
    private store: Store,
    private userContextSvc: UserContextService
  ) {}

  public ngOnInit(): void {
    this.muaManagerState$ = this.store.select(getAttestationMuaManagerState);
    this.store.dispatch(new LoadMuaManagerAction());
    this.setMuaManagerStateData();
    this.fetchUserFormatSettings();
  }

  public setMuaManagerStateData(): void {
    this.subscriptions.push(
      this.store.select(getAttestationMuaManagerStateData).subscribe(data => {
        if (data) {
          this.muaManagerStateData = deepClone(data);
          this.initialMuaManagerStateData = deepClone(data);
          this.muaManagerStateData.text = this.muaManagerStateData.text.replaceAll('> <', '><');
          this.initialMuaManagerStateData.text = this.initialMuaManagerStateData.text.replaceAll('> <', '><');
        }
      })
    );
  }

  public fetchUserFormatSettings(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe(userSettings => {
        this.userFormatSettings = userSettings;
      })
    );
  }

  public onReAttestByDate(): void {
    const date = moment(this.attestationDateCtrl.getRawValue()).format('MM/DD/YYYY');
    this.store.dispatch(new AttestMuaManagerByDateAction(date));
  }

  public onReAttestByCompanyId(): void {
    this.store.dispatch(new AttestMuaManagerByOrionIdsAction(this.attestationCompanyIds));
  }

  public onSaveMuaText(): void {
    this.store.dispatch(new SaveMuaManagerAction(this.muaManagerStateData.text));
  }

  public onCancelChangesMuaText(): void {
    this.muaManagerStateData.text = this.initialMuaManagerStateData.text;
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }

  public onlyNumberAllowed(val) {
    const regex = new RegExp('^[0-9]*$');
    const str = String.fromCharCode(!val.charCode ? val.which : val.charCode);

    if (regex.test(str)) {
      return true;
    }

    val.preventDefault();
    return false;
  }

  public onlyNumberAndSlashAllowed(val) {
    const regex = new RegExp('^[0-9]*$|/');
    const str = String.fromCharCode(!val.charCode ? val.which : val.charCode);

    if (regex.test(str)) {
      return true;
    }

    val.preventDefault();
    return false;
  }
}

export function isValidDate(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value;

    if (!value) {
      return null;
    }
    if (!moment(value).isValid()) {
      return { isDateInvalid: true };
    }
    return null;
  };
}
