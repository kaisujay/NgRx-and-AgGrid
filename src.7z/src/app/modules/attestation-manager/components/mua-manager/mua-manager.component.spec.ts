import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MuaManagerComponent } from './mua-manager.component';

describe('MuaManagerComponent', () => {
  let component: MuaManagerComponent;
  let fixture: ComponentFixture<MuaManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MuaManagerComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(MuaManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
