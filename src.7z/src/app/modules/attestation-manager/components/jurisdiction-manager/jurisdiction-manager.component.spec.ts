import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JurisdictionManagerComponent } from './jurisdiction-manager.component';

describe('JurisdictionManagerComponent', () => {
  let component: JurisdictionManagerComponent;
  let fixture: ComponentFixture<JurisdictionManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [JurisdictionManagerComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(JurisdictionManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
