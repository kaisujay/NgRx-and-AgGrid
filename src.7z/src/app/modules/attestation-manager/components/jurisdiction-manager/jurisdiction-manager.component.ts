import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { deepClone } from '@core/constants/constants';
import { DateTimeFormatDefined, TimeZoneFormat } from '@core/models/date-time-format';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store } from '@ngrx/store';
import * as moment from 'moment';
import { Observable, Subscription } from 'rxjs';
import {
  AttestJurisdictionManagerByDateAction,
  AttestJurisdictionManagerByOrionIdsAction,
  LoadJurisdictionAction,
  SaveJurisdictionManagerAction
} from '../../@state/actions/jurisdiction-manager.actions';
import {
  getAttestationJurisdictionManagerState,
  getAttestationJurisdictionManagerStateData
} from '../../@state/reducers/attestation-manager.reducer';
import { JurisdictionManagerState } from '../../@state/reducers/jurisdiction.reducer';
import { JurisdictionManagerResponse } from '../../models/attestation-manager.model';
import { isValidDate } from '../mua-manager/mua-manager.component';

@Component({
  selector: 'app-jurisdiction-manager',
  templateUrl: './jurisdiction-manager.component.html',
  styleUrls: ['./jurisdiction-manager.component.scss']
})
export class JurisdictionManagerComponent implements OnInit, OnDestroy {
  public jurisdictionManagerState$: Observable<JurisdictionManagerState>;
  public jurisdictionManagerStateData$: Observable<JurisdictionManagerResponse[]>;
  public jurisdictionManagerStateData: JurisdictionManagerResponse[];
  public jurisdictionDropdown: SelectOptions[];
  public selectedJursidictionOption: string;
  public currentSelectedJurisdiction: JurisdictionManagerResponse;
  public initialSelectedJurisdiction: JurisdictionManagerResponse;
  public userFormatSettings: DateTimeFormatDefined;
  public timeZoneFormat = TimeZoneFormat;
  public subscriptions: Subscription[] = [];
  public attestationDate: string;
  public attestationCompanyIds: string;
  public attestationDateCtrl = new FormControl(null, [Validators.required, isValidDate()]);
  public dateFormat = 'MM/DD/YYYY';

  public constructor(
    private store: Store,
    private userContextSvc: UserContextService
  ) {}

  public ngOnInit(): void {
    this.fetchUserFormatSettings();
    this.jurisdictionManagerState$ = this.store.select(getAttestationJurisdictionManagerState);
    this.store.dispatch(new LoadJurisdictionAction());
    this.setJurisidictionData();
  }

  public setJurisidictionData(): void {
    this.subscriptions.push(
      this.store.select(getAttestationJurisdictionManagerStateData).subscribe(data => {
        if (data) {
          this.jurisdictionManagerStateData = deepClone(data);
          this.setSelectedJurisdiction(this.jurisdictionManagerStateData[0]);
          this.prepareJurisdictionDropdown(this.jurisdictionManagerStateData);
          this.selectedJursidictionOption = this.jurisdictionDropdown[0].value;
        }
      })
    );
  }

  public fetchUserFormatSettings(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe(userSettings => {
        this.userFormatSettings = userSettings;
      })
    );
  }

  public setSelectedJurisdiction(jurisdiction: JurisdictionManagerResponse): void {
    this.currentSelectedJurisdiction = jurisdiction;
    this.initialSelectedJurisdiction = deepClone(jurisdiction);
  }

  public prepareJurisdictionDropdown(jurisdictionData: JurisdictionManagerResponse[]): void {
    this.jurisdictionDropdown = jurisdictionData.map((jurisdiction, index) => {
      return {
        label: jurisdiction.jurisdictionNameReported,
        value: index.toString()
      };
    });
  }

  public onJurisdictionChange(event: string): void {
    this.currentSelectedJurisdiction.text = this.initialSelectedJurisdiction.text;
    this.selectedJursidictionOption = event;
    this.setSelectedJurisdiction(this.jurisdictionManagerStateData[Number(event)]);
  }

  public onReAttestByDate(): void {
    const date = moment(this.attestationDateCtrl.getRawValue()).format('MM/DD/YYYY');
    this.store.dispatch(new AttestJurisdictionManagerByDateAction(date));
  }

  public onReAttestByCompanyId(): void {
    this.store.dispatch(new AttestJurisdictionManagerByOrionIdsAction(this.attestationCompanyIds));
  }

  public onJurisdictionSave(): void {
    this.store.dispatch(
      new SaveJurisdictionManagerAction({
        jurisdiction: this.currentSelectedJurisdiction.jurisdiction,
        text: this.currentSelectedJurisdiction.text
      })
    );
  }

  public onJurisdictionCancelChanges(): void {
    this.currentSelectedJurisdiction.text = this.initialSelectedJurisdiction.text;
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }

  public onlyNumberAllowed(val) {
    const regex = new RegExp('^[0-9]*$');
    const str = String.fromCharCode(!val.charCode ? val.which : val.charCode);

    if (regex.test(str)) {
      return true;
    }

    val.preventDefault();
    return false;
  }

  public onlyNumberAndSlashAllowed(val) {
    const regex = new RegExp('^[0-9]*$|/');
    const str = String.fromCharCode(!val.charCode ? val.which : val.charCode);

    if (regex.test(str)) {
      return true;
    }

    val.preventDefault();
    return false;
  }
}
