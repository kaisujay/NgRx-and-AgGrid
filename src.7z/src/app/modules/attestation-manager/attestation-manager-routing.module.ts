import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JurisdictionManagerComponent } from './components/jurisdiction-manager/jurisdiction-manager.component';
import { MuaManagerComponent } from './components/mua-manager/mua-manager.component';

const routes: Routes = [
  {
    path: 'muaManager',
    component: MuaManagerComponent
  },
  {
    path: 'jurisdictionManager',
    component: JurisdictionManagerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AttestationManagerRoutingModule {}
