import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { JurisdictionManagerResponse, MuaManagerResponse } from '../models/attestation-manager.model';

@Injectable()
export class AttestationManagerService {
  public constructor(private http: HttpClient) {}

  public getMuaManagerData(): Observable<MuaManagerResponse> {
    return this.http.get<MuaManagerResponse>(API.attestationManager.getMua);
  }

  public saveMuaManagerData(text: string): Observable<MuaManagerResponse> {
    return this.http.post<MuaManagerResponse>(API.attestationManager.getMua, { text: text });
  }

  public saveMuaAttestationByDate(date: string): Observable<void> {
    return this.http.delete<void>(API.attestationManager.muaAttestByDate.replace('{date}', date));
  }

  public saveMuaAttestationByCompanyIds(id: string): Observable<void> {
    return this.http.delete<void>(API.attestationManager.muaAttestByOrionIds.replace('{id}', id));
  }

  public getJursidictionManagerData(): Observable<JurisdictionManagerResponse[]> {
    return this.http.get<JurisdictionManagerResponse[]>(API.attestationManager.getJurisdiction);
  }

  public saveJurisdictionData(payload: Partial<JurisdictionManagerResponse>): Observable<JurisdictionManagerResponse> {
    return this.http.post<JurisdictionManagerResponse>(API.attestationManager.getJurisdiction, payload);
  }

  public saveJurisdictionAttestationByDate(date: string): Observable<void> {
    return this.http.delete<void>(API.attestationManager.jurisdictionAttestByDate.replace('{date}', date));
  }

  public saveJurisdictionAttestationByCompanyIds(id: string): Observable<void> {
    return this.http.delete<void>(API.attestationManager.jurisdictionAttestByOrionIds.replace('{id}', id));
  }
}
