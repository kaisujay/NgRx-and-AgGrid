import { TestBed } from '@angular/core/testing';

import { AttestationManagerService } from './attestation-manager.service';

describe('AttestationManagerService', () => {
  let service: AttestationManagerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AttestationManagerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
