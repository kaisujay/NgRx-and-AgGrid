export interface MuaManagerResponse {
  createdBy: string;
  creationDate: string | Date;
  id: string;
  lastModifiedBy: string;
  lastModifiedDate: string | Date;
  rowVersion: number;
  text: string;
  versionNumber: number;
}

export interface JurisdictionManagerResponse {
  jurisdiction: string;
  jurisdictionNameReported: string;
  lastModifiedBy: string;
  lastModifiedDate: string | Date;
  text: string;
  versionNumber: number;
}
