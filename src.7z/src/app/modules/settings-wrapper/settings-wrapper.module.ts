import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { SettingsWrapperComponent } from './components/settings-wrapper.component';
import { SettingsWrapperRoutingModule } from './settings-wrapper-routing.module';

@NgModule({
  declarations: [SettingsWrapperComponent],
  imports: [CommonModule, SettingsWrapperRoutingModule]
})
export class SettingsWrapperModule {}
