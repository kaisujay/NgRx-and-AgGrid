import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { TaskSettingMuniDeleteDeal } from '../models/task-setting.model';

@Injectable()
export class TaskSettingsService {
  public constructor(private http: HttpClient) {}

  public syncIpreoAccount(): Observable<unknown> {
    return this.http.post<unknown>(API.settings.syncIpreoSettings, {});
  }

  public syncCompanyIdentifiers(): Observable<unknown> {
    return this.http.put<unknown>(API.settings.updateCompanyIdentifiers, {});
  }

  public syncCompanyInvestors(): Observable<unknown> {
    return this.http.post<unknown>(API.settings.syncInvestorAccounts, {});
  }

  public muniDeleteDeal(payload: TaskSettingMuniDeleteDeal): Observable<unknown> {
    const url = buildApiString(API.settings.muniDeleteDeal, {
      globalIssueId: payload.globalIssueId,
      orionId: payload.orionId
    });
    return this.http.delete<unknown>(url);
  }
}
