import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { CardsModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { MuniDeleteDealEffect } from './@state/effects/muni-delete-deal.effect';
import { SyncCompanyIdentifierEffect } from './@state/effects/sync-company-identifier.effect';
import { SyncCompanyInvestorEffect } from './@state/effects/sync-company-investors.effect';
import { SyncIpreoAccountEffect } from './@state/effects/sync-ipreo-setting.effect';
import { taskSettingReducer } from './@state/reducers/task-settings.reducer';
import { TasksComponent } from './components/tasks.component';
import { TaskSettingsService } from './services/task-settings.service';
import { TasksRoutingModule } from './tasks-routing.module';

@NgModule({
  declarations: [TasksComponent],
  imports: [
    CommonModule,
    AdminSharedModule,
    CardsModule,
    SPRFormsModule,
    ReactiveFormsModule,
    CoreModule,
    TasksRoutingModule,
    StoreModule.forFeature('tasksSettings', taskSettingReducer),
    EffectsModule.forFeature([
      SyncIpreoAccountEffect,
      SyncCompanyInvestorEffect,
      SyncCompanyIdentifierEffect,
      MuniDeleteDealEffect
    ])
  ],
  providers: [TaskSettingsService]
})
export class TasksModule {}
