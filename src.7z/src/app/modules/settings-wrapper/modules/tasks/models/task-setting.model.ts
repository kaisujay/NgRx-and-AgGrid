export interface TaskSettingState {
  SyncIpreoAccount: TaskSettingSavingState;
  SyncCompanyIdentifier: TaskSettingSavingState;
  SyncCompanyInvestorAccounts: TaskSettingSavingState;
  MuniDeleteDeal: TaskSettingSavingState;
}

export interface TaskSettingSavingState {
  isSaving: boolean;
  isSaveSuccess: boolean;
  isSaveError: boolean;
}

export interface TaskSettingMuniDeleteDeal {
  orionId: string;
  globalIssueId: string;
}
