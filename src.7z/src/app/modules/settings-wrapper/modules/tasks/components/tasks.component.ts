import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import {
  MuniDeleteDealAction,
  SyncCompanyIdentifiersAction,
  SyncCompanyInvestorAccountsAction,
  SyncIpreoAccountAction
} from '../@state/actions/task-settings.actions';
import { getTaskSettingState } from '../@state/reducers/task-settings.reducer';
import { TaskSettingState } from '../models/task-setting.model';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent implements OnInit {
  public taskSettingStore$: Observable<TaskSettingState>;
  public muniDeleteDealForm: FormGroup;

  public constructor(
    private store: Store,
    private _fb: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.taskSettingStore$ = this.store.select(getTaskSettingState).pipe(
      tap(state => {
        if (state.MuniDeleteDeal.isSaveSuccess) {
          this.muniDeleteDealForm.reset();
        }
      })
    );
    this.muniDeleteDealForm = this._fb.group({
      orionId: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      globalIssueId: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)])
    });
  }

  public syncCompanyIdentifier(): void {
    this.store.dispatch(new SyncCompanyIdentifiersAction());
  }

  public syncCompanyInvestorAccount(): void {
    this.store.dispatch(new SyncCompanyInvestorAccountsAction());
  }

  public syncIpreoSettings(): void {
    this.store.dispatch(new SyncIpreoAccountAction());
  }

  public onDeleteDeal(): void {
    this.store.dispatch(new MuniDeleteDealAction(this.muniDeleteDealForm.value));
  }
}
