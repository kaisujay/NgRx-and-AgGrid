import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TaskSettingsService } from '../../services/task-settings.service';
import {
  SyncIpreoAccountAction,
  SyncIpreoAccountFailedAction,
  SyncIpreoAccountSuccessAction,
  TaskSettingsActionTypes
} from '../actions/task-settings.actions';

@Injectable()
export class SyncIpreoAccountEffect {
  public constructor(
    private actions$: Actions,
    private taskSettingSvc: TaskSettingsService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public syncIpreoAccountEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskSettingsActionTypes.SyncIpreoAccount),
      switchMap((_action: SyncIpreoAccountAction) =>
        this.taskSettingSvc.syncIpreoAccount().pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company ipreo account updated successfully');
    return new SyncIpreoAccountSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while updating company ipreo account');
    return of(new SyncIpreoAccountFailedAction());
  }
}
