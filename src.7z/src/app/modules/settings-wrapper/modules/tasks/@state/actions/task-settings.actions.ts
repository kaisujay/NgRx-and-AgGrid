import { Action } from '@ngrx/store';
import { TaskSettingMuniDeleteDeal } from '../../models/task-setting.model';

export enum TaskSettingsActionTypes {
  SyncCompanyIdentifiers = '[TaskSettings] Update Company Identifiers',
  SyncCompanyIdentifiersSuccess = '[TaskSettings] Update Company Identifiers Success',
  SyncCompanyIdentifiersFailed = '[TaskSettings] Update Company Identifiers Failed',

  SyncIpreoAccount = '[TaskSettings] Sync Ipreo Account',
  SyncIpreoAccountSuccess = '[TaskSettings] Sync Ipreo Account Success',
  SyncIpreoAccountFailed = '[TaskSettings] Sync Ipreo Account Failed',

  SyncCompanyInvestorAccounts = '[TaskSettings] Sync Company Investor Accounts',
  SyncCompanyInvestorAccountsSuccess = '[TaskSettings] Sync Company Investor Accounts Success',
  SyncCompanyInvestorAccountsFailed = '[TaskSettings] Sync Company Investor Accounts Failed',

  MuniDeleteDeal = '[TaskSettings] Muni Delete Deal',
  MuniDeleteDealSuccess = '[TaskSettings] Muni Delete Deal Success',
  MuniDeleteDealFailed = '[TaskSettings] Muni Delete Deal Failed'
}

export class SyncCompanyIdentifiersAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyIdentifiers;
  public constructor() {}
}

export class SyncCompanyIdentifiersSuccessAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyIdentifiersSuccess;
  public constructor() {}
}

export class SyncCompanyIdentifiersFailedAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyIdentifiersFailed;
  public constructor() {}
}

export class SyncIpreoAccountAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncIpreoAccount;
  public constructor() {}
}

export class SyncIpreoAccountSuccessAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncIpreoAccountSuccess;
  public constructor() {}
}

export class SyncIpreoAccountFailedAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncIpreoAccountFailed;
  public constructor() {}
}

export class SyncCompanyInvestorAccountsAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyInvestorAccounts;
  public constructor() {}
}

export class SyncCompanyInvestorAccountsSuccessAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyInvestorAccountsSuccess;
  public constructor() {}
}

export class SyncCompanyInvestorAccountsFailedAction implements Action {
  public readonly type = TaskSettingsActionTypes.SyncCompanyInvestorAccountsFailed;
  public constructor() {}
}

export class MuniDeleteDealAction implements Action {
  public readonly type = TaskSettingsActionTypes.MuniDeleteDeal;
  public constructor(public payload: TaskSettingMuniDeleteDeal) {}
}

export class MuniDeleteDealSuccessAction implements Action {
  public readonly type = TaskSettingsActionTypes.MuniDeleteDealSuccess;
  public constructor() {}
}

export class MuniDeleteDealFailedAction implements Action {
  public readonly type = TaskSettingsActionTypes.MuniDeleteDealFailed;
  public constructor() {}
}

export type TaskSettingsActionsUnion =
  | SyncCompanyIdentifiersAction
  | SyncCompanyIdentifiersSuccessAction
  | SyncCompanyIdentifiersFailedAction
  | SyncIpreoAccountAction
  | SyncIpreoAccountSuccessAction
  | SyncIpreoAccountFailedAction
  | SyncCompanyInvestorAccountsAction
  | SyncCompanyInvestorAccountsSuccessAction
  | SyncCompanyInvestorAccountsFailedAction
  | MuniDeleteDealAction
  | MuniDeleteDealSuccessAction
  | MuniDeleteDealFailedAction;
