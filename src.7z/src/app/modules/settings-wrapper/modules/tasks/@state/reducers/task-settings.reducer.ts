import { createFeatureSelector } from '@ngrx/store';
import { TaskSettingState } from '../../models/task-setting.model';
import { TaskSettingsActionTypes, TaskSettingsActionsUnion } from '../actions/task-settings.actions';

const initialSavingState = {
  isSaving: false,
  isSaveError: false,
  isSaveSuccess: false
};

export const taskSettingInitialState: TaskSettingState = {
  SyncCompanyIdentifier: initialSavingState,
  SyncCompanyInvestorAccounts: initialSavingState,
  SyncIpreoAccount: initialSavingState,
  MuniDeleteDeal: initialSavingState
};

export function taskSettingReducer(
  state = taskSettingInitialState,
  actions: TaskSettingsActionsUnion
): TaskSettingState {
  switch (actions.type) {
    case TaskSettingsActionTypes.SyncCompanyIdentifiers:
      return {
        ...state,
        SyncCompanyIdentifier: {
          ...state.SyncCompanyIdentifier,
          isSaving: true
        }
      };
    case TaskSettingsActionTypes.SyncCompanyIdentifiersSuccess:
      return {
        ...state,
        SyncCompanyIdentifier: {
          ...state.SyncCompanyIdentifier,
          isSaving: false,
          isSaveSuccess: true
        }
      };

    case TaskSettingsActionTypes.SyncCompanyIdentifiersFailed:
      return {
        ...state,
        SyncCompanyIdentifier: {
          ...state.SyncCompanyIdentifier,
          isSaving: false,
          isSaveError: true
        }
      };
    case TaskSettingsActionTypes.SyncIpreoAccount:
      return {
        ...state,
        SyncIpreoAccount: {
          ...state.SyncIpreoAccount,
          isSaving: true
        }
      };
    case TaskSettingsActionTypes.SyncIpreoAccountSuccess:
      return {
        ...state,
        SyncIpreoAccount: {
          ...state.SyncIpreoAccount,
          isSaving: false,
          isSaveSuccess: true
        }
      };
    case TaskSettingsActionTypes.SyncIpreoAccountFailed:
      return {
        ...state,
        SyncIpreoAccount: {
          ...state.SyncIpreoAccount,
          isSaving: false,
          isSaveError: true
        }
      };
    case TaskSettingsActionTypes.SyncCompanyInvestorAccounts:
      return {
        ...state,
        SyncCompanyInvestorAccounts: {
          ...state.SyncCompanyInvestorAccounts,
          isSaving: true
        }
      };
    case TaskSettingsActionTypes.SyncCompanyInvestorAccountsSuccess:
      return {
        ...state,
        SyncCompanyInvestorAccounts: {
          ...state.SyncCompanyInvestorAccounts,
          isSaving: false,
          isSaveSuccess: true
        }
      };
    case TaskSettingsActionTypes.SyncCompanyInvestorAccountsFailed:
      return {
        ...state,
        SyncCompanyInvestorAccounts: {
          ...state.SyncCompanyInvestorAccounts,
          isSaving: false,
          isSaveError: true
        }
      };
    case TaskSettingsActionTypes.MuniDeleteDeal:
      return {
        ...state,
        MuniDeleteDeal: {
          ...state.MuniDeleteDeal,
          isSaving: true
        }
      };
    case TaskSettingsActionTypes.MuniDeleteDealSuccess:
      return {
        ...state,
        MuniDeleteDeal: {
          ...state.MuniDeleteDeal,
          isSaving: false,
          isSaveSuccess: true
        }
      };
    case TaskSettingsActionTypes.MuniDeleteDealFailed:
      return {
        ...state,
        MuniDeleteDeal: {
          ...state.MuniDeleteDeal,
          isSaving: false,
          isSaveError: true
        }
      };
    default:
      return { ...state };
  }
}

export const getTaskSettingState = createFeatureSelector<TaskSettingState>('tasksSettings');
