import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TaskSettingsService } from '../../services/task-settings.service';
import {
  MuniDeleteDealAction,
  MuniDeleteDealFailedAction,
  MuniDeleteDealSuccessAction,
  TaskSettingsActionTypes
} from '../actions/task-settings.actions';

@Injectable()
export class MuniDeleteDealEffect {
  public constructor(
    private actions$: Actions,
    private taskSettingSvc: TaskSettingsService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public muniDeleteDealEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskSettingsActionTypes.MuniDeleteDeal),
      switchMap((_action: MuniDeleteDealAction) =>
        this.taskSettingSvc.muniDeleteDeal(_action.payload).pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError(_err))
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'MUNI Deal has been successfully deleted');
    return new MuniDeleteDealSuccessAction();
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 400) {
      const erroMsg = [];
      Object.keys(error.error['errors']).forEach(key => {
        erroMsg.push(error.error['errors'][key]);
      });
      this.messageAlertSvc.showMessageAlert(
        CupcakeFlavors.Danger,
        erroMsg.length ? erroMsg.join(' ') : 'Error deleting MUNI Deal'
      );
    }

    if (error.status === 404) {
      const erroMsg = [];
      Object.keys(error.error['title']).forEach(key => {
        erroMsg.push(error.error['title'][key]);
      });
      this.messageAlertSvc.showMessageAlert(
        CupcakeFlavors.Danger,
        erroMsg.length ? 'Error MUNI Deal ' + erroMsg.join('') : 'Error MUNI Deal Not Found'
      );
    }
    return of(new MuniDeleteDealFailedAction());
  }
}
