import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TaskSettingsService } from '../../services/task-settings.service';
import {
  SyncCompanyIdentifiersAction,
  SyncCompanyIdentifiersFailedAction,
  SyncCompanyIdentifiersSuccessAction,
  TaskSettingsActionTypes
} from '../actions/task-settings.actions';

@Injectable()
export class SyncCompanyIdentifierEffect {
  public constructor(
    private actions$: Actions,
    private taskSettingSvc: TaskSettingsService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public syncCompanyIdentifierEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskSettingsActionTypes.SyncCompanyIdentifiers),
      switchMap((_action: SyncCompanyIdentifiersAction) =>
        this.taskSettingSvc.syncCompanyIdentifiers().pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company PMIDs and LEIs updated successfully');
    return new SyncCompanyIdentifiersSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while updating company PMIDs and LEIs');
    return of(new SyncCompanyIdentifiersFailedAction());
  }
}
