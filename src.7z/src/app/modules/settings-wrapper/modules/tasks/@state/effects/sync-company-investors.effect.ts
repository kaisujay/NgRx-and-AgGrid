import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TaskSettingsService } from '../../services/task-settings.service';
import {
  SyncCompanyInvestorAccountsAction,
  SyncCompanyInvestorAccountsFailedAction,
  SyncCompanyInvestorAccountsSuccessAction,
  TaskSettingsActionTypes
} from '../actions/task-settings.actions';

@Injectable()
export class SyncCompanyInvestorEffect {
  public constructor(
    private actions$: Actions,
    private taskSettingSvc: TaskSettingsService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public syncCompanyInvestorEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TaskSettingsActionTypes.SyncCompanyInvestorAccounts),
      switchMap((_action: SyncCompanyInvestorAccountsAction) =>
        this.taskSettingSvc.syncCompanyInvestors().pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company Investor account updated successfully');
    return new SyncCompanyInvestorAccountsSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while updating company investors');
    return of(new SyncCompanyInvestorAccountsFailedAction());
  }
}
