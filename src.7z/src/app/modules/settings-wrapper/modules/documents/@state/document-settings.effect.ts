import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { DocumentSettingsService } from '../services/document-settings.service';
import {
  DocumentSettingsActionTypes,
  LoadDocumentSettingsAction,
  LoadDocumentSettingsFailedAction,
  LoadDocumentSettingsSuccessAction
} from './document-settings.action';

@Injectable()
export class LoadDocumentSettingEffect {
  public constructor(
    private actions$: Actions,
    private docSettingSvc: DocumentSettingsService
  ) {}
  public loadDocumentSettingsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(DocumentSettingsActionTypes.LoadDocumentSettings),
      switchMap((_action: LoadDocumentSettingsAction) =>
        this.docSettingSvc.getDocumentSettings().pipe(
          map(_data => new LoadDocumentSettingsSuccessAction(_data)),
          catchError(_err => of(new LoadDocumentSettingsFailedAction()))
        )
      )
    )
  );
}
