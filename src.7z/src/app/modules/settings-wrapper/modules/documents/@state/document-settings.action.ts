import { Action } from '@ngrx/store';
import { DocumentSettingResponse } from './document-settings.reducer';

export enum DocumentSettingsActionTypes {
  LoadDocumentSettings = '[DocumentSettings] Load DocumentSettings',
  LoadDocumentSettingsSuccess = '[DocumentSettings] Load DocumentSettings Success',
  LoadDocumentSettingsFailed = '[DocumentSettings] Load DocumentSettings Failed'
}

export class LoadDocumentSettingsAction implements Action {
  public readonly type = DocumentSettingsActionTypes.LoadDocumentSettings;
  public constructor() {}
}

export class LoadDocumentSettingsSuccessAction implements Action {
  public readonly type = DocumentSettingsActionTypes.LoadDocumentSettingsSuccess;
  public constructor(public payload: DocumentSettingResponse) {}
}

export class LoadDocumentSettingsFailedAction implements Action {
  public readonly type = DocumentSettingsActionTypes.LoadDocumentSettingsFailed;
  public constructor() {}
}

export type DocumentSettingsActionsUnion =
  | LoadDocumentSettingsAction
  | LoadDocumentSettingsSuccessAction
  | LoadDocumentSettingsFailedAction;
