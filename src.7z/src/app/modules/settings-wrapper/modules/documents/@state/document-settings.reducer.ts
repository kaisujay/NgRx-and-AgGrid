import { createFeatureSelector } from '@ngrx/store';
import { DocumentSettingsActionTypes, DocumentSettingsActionsUnion } from './document-settings.action';

export interface DocumentSettingsStore {
  data: DocumentSettingResponse;
  isLoading: boolean;
  isLoadError: boolean;
  isLoadSuccess: boolean;
}

export interface DocumentSettingResponse {
  DocumentFileEndpoint: string;
  DocumentListEndpoint: string;
  DocumentMetadataEndpoint: string;
  RowVersion: number;
}

export const initialDocumentSettingsState: DocumentSettingsStore = {
  data: null,
  isLoading: false,
  isLoadError: false,
  isLoadSuccess: false
};

export function DocumentSettingsReducer(
  state: DocumentSettingsStore = initialDocumentSettingsState,
  action: DocumentSettingsActionsUnion
): DocumentSettingsStore {
  switch (action.type) {
    case DocumentSettingsActionTypes.LoadDocumentSettings:
      return {
        ...state,
        isLoading: true,
        isLoadError: false,
        isLoadSuccess: false
      };
    case DocumentSettingsActionTypes.LoadDocumentSettingsSuccess:
      return {
        ...state,
        isLoading: false,
        isLoadError: false,
        isLoadSuccess: true,
        data: action.payload
      };
    case DocumentSettingsActionTypes.LoadDocumentSettingsFailed:
      return {
        ...state,
        isLoading: false,
        isLoadError: true,
        isLoadSuccess: false
      };
    default:
      return state;
  }
}

export const getDocumentSettingsState = createFeatureSelector<DocumentSettingsStore>('documents');
