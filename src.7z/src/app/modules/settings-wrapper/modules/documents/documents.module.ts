import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadDocumentSettingEffect } from './@state/document-settings.effect';
import { DocumentSettingsReducer } from './@state/document-settings.reducer';
import { DocumentsComponent } from './components/documents.component';
import { DocumentsRoutingModule } from './documents-routing.module';
import { DocumentSettingsService } from './services/document-settings.service';

@NgModule({
  declarations: [DocumentsComponent],
  imports: [
    LoaderModule,
    CommonModule,
    AdminSharedModule,
    DocumentsRoutingModule,
    StoreModule.forFeature('documents', DocumentSettingsReducer),
    EffectsModule.forFeature([LoadDocumentSettingEffect])
  ],
  providers: [DocumentSettingsService]
})
export class DocumentsModule {}
