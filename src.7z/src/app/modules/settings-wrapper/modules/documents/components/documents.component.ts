import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { LoadDocumentSettingsAction } from '../@state/document-settings.action';
import { DocumentSettingsStore, getDocumentSettingsState } from '../@state/document-settings.reducer';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  public documentSettingState$: Observable<DocumentSettingsStore>;

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.store.dispatch(new LoadDocumentSettingsAction());
    this.documentSettingState$ = this.store.select(getDocumentSettingsState);
  }
}
