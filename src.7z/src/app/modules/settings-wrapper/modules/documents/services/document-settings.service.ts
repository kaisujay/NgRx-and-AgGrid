import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { DocumentSettingResponse } from '../@state/document-settings.reducer';

@Injectable()
export class DocumentSettingsService {
  public constructor(private http: HttpClient) {}

  public getDocumentSettings(): Observable<DocumentSettingResponse> {
    return this.http.get<DocumentSettingResponse>(API.settings.documents);
  }
}
