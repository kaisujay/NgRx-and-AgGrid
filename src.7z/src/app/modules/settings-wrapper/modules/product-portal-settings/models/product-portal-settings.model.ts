export interface ProductPortalSettingsResponseModel {
  ResetPasswordTokenTTLMinutes: number;
  IpreoAccountEnabled: boolean;
  InternalCommentsAndAlertingEnabled: boolean;
  InternalExternalTotalEnabled: boolean;
  NewBspPagesEnabled: boolean;
  AccountXEnabled: boolean;
  AussieAssetSwap: boolean;
  BDAgentEnabled: boolean;
  SplitDeliveryEnabled: boolean;
  HundSunOrdersEnabled: boolean;
  MuniConnectionsEnabled: boolean;
  EquityOrdersEnabled: boolean;
  OperationalEntitiesEnable: boolean;
  ComplianceEnabled: boolean;
  BuzzTheBankEnabled: boolean;
  EquityAllocationsEnabled: boolean;
  AnalyticsQuicksightEnabled: boolean;
  EquityDealServiceEnabled: boolean;
  EquityOrderServiceEnabled: boolean;
  EquityAnalyticsEnabled: boolean;
  SendUpdatesToVendors: boolean;
  EmailTesting?: EmailTestingModel;
  RowVersion: number;
  FTREmailNotificationEnabled: boolean;
  EquityAllocationsAcknowledgeEnabled: boolean;
}

export interface ProductPortalSettingsPayloadModel {
  ResetPasswordTokenTTLMinutes: number;
  IpreoAccountEnabled: boolean;
  InternalCommentsAndAlertingEnabled: boolean;
  InternalExternalTotalEnabled: boolean;
  NewBspPagesEnabled: boolean;
  AccountXEnabled: boolean;
  AussieAssetSwap: boolean;
  BDAgentEnabled: boolean;
  SplitDeliveryEnabled: boolean;
  HundSunOrdersEnabled: boolean;
  MuniConnectionsEnabled: boolean;
  EquityOrdersEnabled: boolean;
  OperationalEntitiesEnable: boolean;
  ComplianceEnabled: boolean;
  BuzzTheBankEnabled: boolean;
  EquityAllocationsEnabled: boolean;
  AnalyticsQuicksightEnabled: boolean;
  EquityDealServiceEnabled: boolean;
  EquityOrderServiceEnabled: boolean;
  EquityAnalyticsEnabled: boolean;
  SendUpdatesToVendors: boolean;
  EmailTesting?: EmailTestingModel;
  RowVersion: number;
  FTREmailNotificationEnabled: boolean;
  EquityAllocationsAcknowledgeEnabled: boolean;
}

export interface EmailTestingModel {
  IsEnabled?: boolean;
  EmailsWhitelist?: string;
  MaxNumberOfEmailsSent?: number;
}
