import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { isNullOrUndefined } from '@core/utils/util';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import {
  LoadProductPortalSettingsAction,
  SaveProductPortalSettingsAction
} from '../@states/actions/product-portal-settings.action';
import {
  ProductPortalSettingsState,
  getProductPortalSettingsState
} from '../@states/reducers/product-portal-settings.reducer';
import {
  ProductPortalSettingsPayloadModel,
  ProductPortalSettingsResponseModel
} from '../models/product-portal-settings.model';

@Component({
  selector: 'app-product-portal-settings',
  templateUrl: './product-portal-settings.component.html',
  styleUrls: ['./product-portal-settings.component.scss']
})
export class ProductPortalSettingsComponent implements OnInit {
  public productPortalSettingsState$: Observable<ProductPortalSettingsState>;

  public productPortalSettingsFormGroup: FormGroup;
  public cupcakeFlavors = CupcakeFlavors;

  public productPortalSettingsPayload: ProductPortalSettingsPayloadModel;
  public productPortalSettingsResponse: ProductPortalSettingsResponseModel;
  public initialProductPortalSettingsResponse: ProductPortalSettingsResponseModel;
  public shouldShowEmailTesingItems: boolean;
  public dataLoaded = false;

  public constructor(
    private formBuilder: FormBuilder,
    public store$: Store
  ) {}

  public ngOnInit(): void {
    this.subscribeToProductPortalSettingsData();

    this.store$.dispatch(new LoadProductPortalSettingsAction());
  }

  public subscribeToProductPortalSettingsData() {
    this.productPortalSettingsState$ = this.store$.pipe(
      select(getProductPortalSettingsState),
      tap(state => {
        if (state.loadProductPortalSettings.isLoaded) {
          this.dataLoaded = true;
          this.productPortalSettingsResponse = this.deepCopy(state.loadProductPortalSettings.data);
          this.initialProductPortalSettingsResponse = this.deepCopy(state.loadProductPortalSettings.data);
          this.dataLoaded = true;
          this.initForm();
        }
        if (state.saveProductPortalSettings.isSaved) {
          this.store$.dispatch(new LoadProductPortalSettingsAction());
        }
      })
    );
  }

  public initForm() {
    this.productPortalSettingsFormGroup = this.formBuilder.group({
      ResetPasswordTokenTTLMinutes: new FormControl(
        this.initialProductPortalSettingsResponse.ResetPasswordTokenTTLMinutes,
        [Validators.required, Validators.pattern('^(?:[5-9]|[1-8][0-9]|90)$')]
      ),
      IpreoAccountEnabled: new FormControl(this.initialProductPortalSettingsResponse.IpreoAccountEnabled),
      AccountXEnabled: new FormControl(this.initialProductPortalSettingsResponse.AccountXEnabled),
      AussieAssetSwap: new FormControl(this.initialProductPortalSettingsResponse.AussieAssetSwap),
      BDAgentEnabled: new FormControl(this.initialProductPortalSettingsResponse.BDAgentEnabled),
      OperationalEntitiesEnable: new FormControl(this.initialProductPortalSettingsResponse.OperationalEntitiesEnable),
      EquityOrdersEnabled: new FormControl(this.initialProductPortalSettingsResponse.EquityOrdersEnabled),
      BuzzTheBankEnabled: new FormControl(this.initialProductPortalSettingsResponse.BuzzTheBankEnabled),
      EquityDealServiceEnabled: new FormControl(this.initialProductPortalSettingsResponse.EquityDealServiceEnabled),
      EquityAnalyticsEnabled: new FormControl(this.initialProductPortalSettingsResponse.EquityAnalyticsEnabled),
      EmailTesting: new FormControl(this.initialProductPortalSettingsResponse.EmailTesting?.IsEnabled),
      MaxNumberOfEmailsSent: new FormControl(
        this.initialProductPortalSettingsResponse.EmailTesting?.MaxNumberOfEmailsSent,
        [Validators.required, Validators.pattern('^(?:[1-9]|[1-5][0-9]|60)$')]
      ),
      EmailsWhitelist: new FormControl(
        this.initialProductPortalSettingsResponse.EmailTesting?.EmailsWhitelist,
        Validators.required
      ),
      SplitDeliveryEnabled: new FormControl(this.initialProductPortalSettingsResponse.SplitDeliveryEnabled),
      HundSunOrdersEnabled: new FormControl(this.initialProductPortalSettingsResponse.HundSunOrdersEnabled),
      MuniConnectionsEnabled: new FormControl(this.initialProductPortalSettingsResponse.MuniConnectionsEnabled),
      ComplianceEnabled: new FormControl(this.initialProductPortalSettingsResponse.ComplianceEnabled),
      EquityAllocationsEnabled: new FormControl(this.initialProductPortalSettingsResponse.EquityAllocationsEnabled),
      AnalyticsQuicksightEnabled: new FormControl(this.initialProductPortalSettingsResponse.AnalyticsQuicksightEnabled),
      EquityOrderServiceEnabled: new FormControl(this.initialProductPortalSettingsResponse.EquityOrderServiceEnabled),
      SendUpdatesToVendors: new FormControl(this.initialProductPortalSettingsResponse.SendUpdatesToVendors),
      RowVersion: new FormControl(this.initialProductPortalSettingsResponse.RowVersion),
      FTREmailNotificationEnabled: new FormControl(
        this.initialProductPortalSettingsResponse.FTREmailNotificationEnabled
      ),
      EquityAllocationsAcknowledgeEnabled: new FormControl(
        this.initialProductPortalSettingsResponse.EquityAllocationsAcknowledgeEnabled
      )
    });

    this.shouldShowEmailTesingItems = this.initialProductPortalSettingsResponse.EmailTesting?.IsEnabled;
  }

  public onSave() {
    this.saveReady();

    this.store$.dispatch(new SaveProductPortalSettingsAction(this.productPortalSettingsPayload));
  }

  public saveReady() {
    if (this.dataLoaded) {
      this.productPortalSettingsPayload = {
        ResetPasswordTokenTTLMinutes: this.productPortalSettingsFormGroup.get('ResetPasswordTokenTTLMinutes').value,
        IpreoAccountEnabled: this.productPortalSettingsFormGroup.get('IpreoAccountEnabled').value,
        InternalCommentsAndAlertingEnabled: true,
        InternalExternalTotalEnabled: true,
        NewBspPagesEnabled: true,
        AccountXEnabled: this.productPortalSettingsFormGroup.get('AccountXEnabled').value,
        AussieAssetSwap: this.productPortalSettingsFormGroup.get('AussieAssetSwap').value,
        BDAgentEnabled: this.productPortalSettingsFormGroup.get('BDAgentEnabled').value,
        SplitDeliveryEnabled: this.productPortalSettingsFormGroup.get('SplitDeliveryEnabled').value,
        HundSunOrdersEnabled: this.productPortalSettingsFormGroup.get('HundSunOrdersEnabled').value,
        MuniConnectionsEnabled: this.productPortalSettingsFormGroup.get('MuniConnectionsEnabled').value,
        EquityOrdersEnabled: this.productPortalSettingsFormGroup.get('EquityOrdersEnabled').value,
        OperationalEntitiesEnable: this.productPortalSettingsFormGroup.get('OperationalEntitiesEnable').value,
        ComplianceEnabled: this.productPortalSettingsFormGroup.get('ComplianceEnabled').value,
        BuzzTheBankEnabled: this.productPortalSettingsFormGroup.get('BuzzTheBankEnabled').value,
        EquityAllocationsEnabled: this.productPortalSettingsFormGroup.get('EquityAllocationsEnabled').value,
        AnalyticsQuicksightEnabled: this.productPortalSettingsFormGroup.get('AnalyticsQuicksightEnabled').value,
        EquityDealServiceEnabled: this.productPortalSettingsFormGroup.get('EquityDealServiceEnabled').value,
        EquityOrderServiceEnabled: this.productPortalSettingsFormGroup.get('EquityOrderServiceEnabled').value,
        EquityAnalyticsEnabled: this.productPortalSettingsFormGroup.get('EquityAnalyticsEnabled').value,
        SendUpdatesToVendors: this.productPortalSettingsFormGroup.get('SendUpdatesToVendors').value,
        EmailTesting: {
          IsEnabled: this.productPortalSettingsFormGroup.get('EmailTesting').value,
          EmailsWhitelist: this.productPortalSettingsFormGroup.get('EmailsWhitelist').value,
          MaxNumberOfEmailsSent: this.productPortalSettingsFormGroup.get('MaxNumberOfEmailsSent').value
        },
        RowVersion: this.productPortalSettingsFormGroup.get('RowVersion').value,
        FTREmailNotificationEnabled: this.productPortalSettingsFormGroup.get('FTREmailNotificationEnabled').value,
        EquityAllocationsAcknowledgeEnabled: this.productPortalSettingsFormGroup.get(
          'EquityAllocationsAcknowledgeEnabled'
        ).value
      };

      if (
        this.productPortalSettingsPayload.EmailTesting === null ||
        this.productPortalSettingsPayload.EmailTesting.IsEnabled === null
      ) {
        this.productPortalSettingsPayload.EmailTesting = null;
      }

      this.productPortalSettingsResponse = this.deepCopy(this.productPortalSettingsPayload);
    }
  }

  public isUnsavedChanges() {
    if (this.dataLoaded) {
      this.saveReady();
      this.convertToNumber();

      if (this.productPortalSettingsFormGroup.controls['ResetPasswordTokenTTLMinutes'].errors) {
        return true;
      }
      if (this.productPortalSettingsResponse.EmailTesting?.IsEnabled) {
        if (
          this.productPortalSettingsFormGroup.controls['MaxNumberOfEmailsSent'].errors ||
          this.productPortalSettingsFormGroup.controls['EmailsWhitelist'].errors
        ) {
          return true;
        }
      }

      if (this.productPortalSettingsResponse.EmailTesting?.IsEnabled === false) {
        if (
          JSON.stringify(this.productPortalSettingsResponse.EmailTesting?.EmailsWhitelist === null) &&
          JSON.stringify(this.productPortalSettingsResponse.EmailTesting?.MaxNumberOfEmailsSent === null)
        ) {
          this.productPortalSettingsResponse.EmailTesting = null;
        }
        if (
          JSON.stringify(this.productPortalSettingsResponse.EmailTesting?.EmailsWhitelist) === '' &&
          JSON.stringify(this.productPortalSettingsResponse.EmailTesting?.MaxNumberOfEmailsSent) === null
        ) {
          this.productPortalSettingsResponse.EmailTesting = null;
        }
      }

      if (
        JSON.stringify(this.sortObject(this.productPortalSettingsResponse)) !==
        JSON.stringify(this.sortObject(this.initialProductPortalSettingsResponse))
      ) {
        return false;
      } else {
        return true;
      }
    }
    return true;
  }

  private convertToNumber() {
    if (!isNullOrUndefined(this.productPortalSettingsResponse.ResetPasswordTokenTTLMinutes)) {
      this.productPortalSettingsResponse.ResetPasswordTokenTTLMinutes = parseInt(
        this.productPortalSettingsResponse.ResetPasswordTokenTTLMinutes.toString()
      );
    }

    if (!isNullOrUndefined(this.productPortalSettingsResponse.EmailTesting?.MaxNumberOfEmailsSent)) {
      this.productPortalSettingsResponse.EmailTesting.MaxNumberOfEmailsSent = parseInt(
        this.productPortalSettingsResponse.EmailTesting.MaxNumberOfEmailsSent.toString()
      );
    }
  }

  public valueChange(val) {
    this.shouldShowEmailTesingItems = val.target.checked;
  }

  public onlyNumberAllowed(val) {
    const regex = new RegExp('^[0-9]*$');
    const str = String.fromCharCode(!val.charCode ? val.which : val.charCode);
    if (regex.test(str)) {
      return true;
    }

    val.preventDefault();
    return false;
  }

  public onPaste(val) {
    val.preventDefault();
    return false;
  }

  private sortObject(unSorted): {} {
    const res = Object.keys(unSorted)
      .sort()
      .reduce((obj, key) => {
        obj[key] = unSorted[key];
        return obj;
      }, {});

    return res;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public deepCopy(oldObj: any) {
    let newObj = oldObj;
    if (oldObj && typeof oldObj === 'object') {
      if (oldObj instanceof Date) {
        return new Date(oldObj.getTime());
      }
      newObj = Object.prototype.toString.call(oldObj) === '[object Array]' ? [] : {};
      for (const i in oldObj) {
        newObj[i] = this.deepCopy(oldObj[i]);
      }
    }
    return newObj;
  }
}
