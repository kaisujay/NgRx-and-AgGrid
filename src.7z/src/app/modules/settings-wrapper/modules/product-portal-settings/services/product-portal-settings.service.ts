import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import {
  ProductPortalSettingsPayloadModel,
  ProductPortalSettingsResponseModel
} from '../models/product-portal-settings.model';

@Injectable()
export class ProductPortalSettingsService {
  public constructor(private http: HttpClient) {}

  public getProductPortalSettings(): Observable<ProductPortalSettingsResponseModel> {
    const url = buildApiString(API.productPortalSettings);

    return this.http.get<ProductPortalSettingsResponseModel>(url);
  }

  public putProductPortalSettings(
    payload: ProductPortalSettingsPayloadModel
  ): Observable<ProductPortalSettingsResponseModel> {
    const url = buildApiString(API.productPortalSettings);

    return this.http.put<ProductPortalSettingsResponseModel>(url, payload);
  }
}
