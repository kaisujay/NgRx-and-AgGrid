import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IconModule, LoaderModule, PopoverModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadProductPortalSettingsEffect } from './@states/effects/load-product-portal-settings.effect';
import { SaveProductPortalSettingsEffect } from './@states/effects/save-product-portal-settings.effect';
import { ProductPortalSettingsStateReducer } from './@states/reducers/product-portal-settings.reducer';
import { ProductPortalSettingsComponent } from './components/product-portal-settings.component';
import { ProductPortalSettingsGuard } from './guards/product-portal-settings.guard';
import { ProductPortalSettingsRoutingModule } from './product-portal-settings-routing.module';
import { ProductPortalSettingsService } from './services/product-portal-settings.service';

@NgModule({
  declarations: [ProductPortalSettingsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    LoaderModule,
    IconModule,
    PopoverModule,
    SPRFormsModule,
    AdminSharedModule,
    SPRFormsModule,
    StoreModule.forFeature('productPortalSettings', ProductPortalSettingsStateReducer),
    EffectsModule.forFeature([LoadProductPortalSettingsEffect, SaveProductPortalSettingsEffect]),
    ProductPortalSettingsRoutingModule
  ],
  providers: [ProductPortalSettingsService, ProductPortalSettingsGuard, DialogService]
})
export class ProductPortalSettingsModule {}
