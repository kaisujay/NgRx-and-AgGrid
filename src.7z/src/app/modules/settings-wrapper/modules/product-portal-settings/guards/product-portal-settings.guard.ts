import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { UnsavedChangesAlertComponent } from '@shared/components/unsaved-changes-alert/unsaved-changes-alert.component';
import { UnsavedChangesAlertActions } from '@shared/models/unsaved-change.model';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { Observable, map, of } from 'rxjs';
import { ProductPortalSettingsComponent } from '../components/product-portal-settings.component';

@Injectable()
export class ProductPortalSettingsGuard implements CanDeactivate<ProductPortalSettingsComponent> {
  public getValue = '';
  public constructor(private _dialogSvc: DialogService) {}

  public canDeactivate(
    component: ProductPortalSettingsComponent,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _currentRoute: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _currentState: RouterStateSnapshot,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _nextState: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!component.isUnsavedChanges()) {
      const dialogRef = this._dialogSvc.open(UnsavedChangesAlertComponent);
      return this._dialogSvc.responseFromModal().pipe(
        map(action => {
          if (action === UnsavedChangesAlertActions.DISCARD) {
            dialogRef.close();
            return true;
          } else if (action === UnsavedChangesAlertActions.STAY) {
            dialogRef.close();
            return false;
          } else if (action === UnsavedChangesAlertActions.SAVE) {
            component.onSave();
            dialogRef.close();
            return true;
          }
          return false;
        })
      );
    }
    return of(true);
  }
}
