import { createFeatureSelector } from '@ngrx/store';
import { ProductPortalSettingsResponseModel } from '../../models/product-portal-settings.model';
import {
  ProductPortalSettingsActionTypes,
  ProductPortalSettingsActionsUnion
} from '../actions/product-portal-settings.action';

export interface ProductPortalSettingsState {
  loadProductPortalSettings: {
    data: ProductPortalSettingsResponseModel;
    isLoading: boolean;
    isLoaded: boolean;
    error: string;
  };
  saveProductPortalSettings: {
    // data: ProductPortalSettingsResponseModel;
    isSaving: boolean;
    isSaved: boolean;
    error: string;
  };
}

export const initialState: ProductPortalSettingsState = {
  loadProductPortalSettings: {
    data: null,
    isLoading: false,
    isLoaded: false,
    error: null
  },
  saveProductPortalSettings: {
    // data: null,
    isSaving: false,
    isSaved: false,
    error: null
  }
};

export function ProductPortalSettingsStateReducer(
  state: ProductPortalSettingsState = initialState,
  action: ProductPortalSettingsActionsUnion
): ProductPortalSettingsState {
  switch (action.type) {
    case ProductPortalSettingsActionTypes.LoadProductPortalSettings:
      return {
        ...state,
        loadProductPortalSettings: {
          ...state.loadProductPortalSettings,
          isLoading: true,
          isLoaded: false,
          error: null
        },
        saveProductPortalSettings: {
          ...state.saveProductPortalSettings,
          isSaved: false,
          isSaving: false
        }
      };
    case ProductPortalSettingsActionTypes.LoadProductPortalSettingsSuccess:
      return {
        ...state,
        loadProductPortalSettings: {
          // ...action.payload,
          data: action.payload,
          isLoading: false,
          isLoaded: true,
          error: null
        },
        saveProductPortalSettings: {
          ...state.saveProductPortalSettings,
          isSaved: false,
          isSaving: false
        }
      };
    case ProductPortalSettingsActionTypes.LoadProductPortalSettingsFailed:
      return {
        ...state,
        loadProductPortalSettings: {
          ...state.loadProductPortalSettings,
          isLoading: false,
          isLoaded: false,
          error: action.error
        }
      };
    case ProductPortalSettingsActionTypes.SaveProductPortalSettings:
      return {
        ...state,
        loadProductPortalSettings: {
          ...state.loadProductPortalSettings,
          isLoading: false,
          isLoaded: false
        },
        saveProductPortalSettings: {
          ...state.loadProductPortalSettings,
          isSaving: true,
          isSaved: false,
          error: null
        }
      };
    case ProductPortalSettingsActionTypes.SaveProductPortalSettingsSuccess:
      return {
        ...state,
        loadProductPortalSettings: {
          data: action.response,
          isLoading: false,
          isLoaded: false,
          error: null
        },
        saveProductPortalSettings: {
          // data: state.loadProductPortalSettings.data,
          isSaving: false,
          isSaved: true,
          error: null
        }
      };
    case ProductPortalSettingsActionTypes.SaveProductPortalSettingsFailed:
      return {
        ...state,
        saveProductPortalSettings: {
          // data: state.loadProductPortalSettings.data,
          isSaving: false,
          isSaved: false,
          error: action.error
        }
      };

    default:
      return state;
  }
}

export const getProductPortalSettingsState = createFeatureSelector<ProductPortalSettingsState>('productPortalSettings');
