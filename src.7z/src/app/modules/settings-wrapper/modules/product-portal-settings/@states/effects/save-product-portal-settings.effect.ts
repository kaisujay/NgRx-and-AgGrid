import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ProductPortalSettingsService } from '../../services/product-portal-settings.service';
import {
  ProductPortalSettingsActionTypes,
  SaveProductPortalSettingsAction,
  SaveProductPortalSettingsFailedAction,
  SaveProductPortalSettingsSuccessAction
} from '../actions/product-portal-settings.action';

@Injectable()
export class SaveProductPortalSettingsEffect {
  public constructor(
    private actions$: Actions,
    private http: ProductPortalSettingsService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveProductPortalSettingsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductPortalSettingsActionTypes.SaveProductPortalSettings),
      switchMap((action: SaveProductPortalSettingsAction) => {
        return this.http.putProductPortalSettings(action.payload).pipe(
          map(response => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Product Portal Settings Saved Successfully');
            return new SaveProductPortalSettingsSuccessAction(response);
          }),
          catchError(err => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error While Saving Product Portal Settings');
            return of(new SaveProductPortalSettingsFailedAction(err));
          })
        );
      })
    )
  );
}
