import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ProductPortalSettingsService } from '../../services/product-portal-settings.service';
import {
  LoadProductPortalSettingsAction,
  LoadProductPortalSettingsFailedAction,
  LoadProductPortalSettingsSuccessAction,
  ProductPortalSettingsActionTypes
} from '../actions/product-portal-settings.action';

@Injectable()
export class LoadProductPortalSettingsEffect {
  public constructor(
    private actions$: Actions,
    private http: ProductPortalSettingsService
  ) {}

  public loadProductPortalSettingsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductPortalSettingsActionTypes.LoadProductPortalSettings),
      switchMap((action: LoadProductPortalSettingsAction) => {
        return this.http.getProductPortalSettings().pipe(
          map(data => new LoadProductPortalSettingsSuccessAction(data)),
          catchError(err => of(new LoadProductPortalSettingsFailedAction(err)))
        );
      })
    )
  );
}
