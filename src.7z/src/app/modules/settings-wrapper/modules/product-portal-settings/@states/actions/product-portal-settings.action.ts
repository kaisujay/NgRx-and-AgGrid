import { Action } from '@ngrx/store';
import {
  ProductPortalSettingsPayloadModel,
  ProductPortalSettingsResponseModel
} from '../../models/product-portal-settings.model';

export enum ProductPortalSettingsActionTypes {
  LoadProductPortalSettings = '[ProductPortalSettings] Load Product Portal Settings',
  LoadProductPortalSettingsSuccess = '[ProductPortalSettings] Load Product Portal Settings Success',
  LoadProductPortalSettingsFailed = '[ProductPortalSettings] Load ProductPortalSettings Failed',

  SaveProductPortalSettings = '[ProductPortalSettings] Save Product Portal Settings',
  SaveProductPortalSettingsSuccess = '[ProductPortalSettings] Save Product Portal Settings Success',
  SaveProductPortalSettingsFailed = '[ProductPortalSettings] Save Product Portal Settings Failed'
}

export class LoadProductPortalSettingsAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.LoadProductPortalSettings;
  public constructor() {}
}

export class LoadProductPortalSettingsSuccessAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.LoadProductPortalSettingsSuccess;
  public constructor(public payload: ProductPortalSettingsResponseModel) {}
}

export class LoadProductPortalSettingsFailedAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.LoadProductPortalSettingsFailed;
  public constructor(public error: string) {}
}

export class SaveProductPortalSettingsAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.SaveProductPortalSettings;
  public constructor(public payload: ProductPortalSettingsPayloadModel) {}
}

export class SaveProductPortalSettingsSuccessAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.SaveProductPortalSettingsSuccess;
  public constructor(public response: ProductPortalSettingsResponseModel) {}
}

export class SaveProductPortalSettingsFailedAction implements Action {
  public readonly type = ProductPortalSettingsActionTypes.SaveProductPortalSettingsFailed;
  public constructor(public error: string) {}
}
export type ProductPortalSettingsActionsUnion =
  | LoadProductPortalSettingsAction
  | LoadProductPortalSettingsSuccessAction
  | LoadProductPortalSettingsFailedAction
  | SaveProductPortalSettingsAction
  | SaveProductPortalSettingsSuccessAction
  | SaveProductPortalSettingsFailedAction;
