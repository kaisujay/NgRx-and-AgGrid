import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductPortalSettingsComponent } from './components/product-portal-settings.component';
import { ProductPortalSettingsGuard } from './guards/product-portal-settings.guard';

const routes: Routes = [
  {
    path: '',
    component: ProductPortalSettingsComponent,
    canDeactivate: [ProductPortalSettingsGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductPortalSettingsRoutingModule {}
