import { createFeatureSelector } from '@ngrx/store';
import { ConnectionSettingsActionTypes, ConnectionSettingsActionsUnion } from './connection-settings.action';

export interface ConnectionSettingsStore {
  data: ConnectionSettingsResponse;
  isLoading: boolean;
  isLoadError: boolean;
  isLoadSuccess: boolean;
}

export interface ConnectionSettingsResponse {
  ConnectionServerUrl: string;
  Scopes: string[];
}

const initialState: ConnectionSettingsStore = {
  data: null,
  isLoading: false,
  isLoadError: false,
  isLoadSuccess: false
};

export function ConnectionSettingsReducer(
  state: ConnectionSettingsStore = initialState,
  action: ConnectionSettingsActionsUnion
): ConnectionSettingsStore {
  switch (action.type) {
    case ConnectionSettingsActionTypes.ConnectionSettings:
      return {
        ...state,
        isLoading: true,
        isLoadError: false,
        isLoadSuccess: false
      };
    case ConnectionSettingsActionTypes.ConnectionSettingsSuccess:
      return {
        ...state,
        isLoading: false,
        isLoadError: false,
        isLoadSuccess: true,
        data: action.payload
      };
    case ConnectionSettingsActionTypes.ConnectionSettingsFailed:
      return {
        ...state,
        isLoading: false,
        isLoadError: true,
        isLoadSuccess: false
      };
    default:
      return state;
  }
}

export const getConnectionSettings = createFeatureSelector<ConnectionSettingsStore>('connectionSettings');
