import { Action } from '@ngrx/store';
import { ConnectionSettingsResponse } from './connection-settings.reducer';

export enum ConnectionSettingsActionTypes {
  ConnectionSettings = '[ConnectionSettings] Load ConnectionSettings',
  ConnectionSettingsSuccess = '[ConnectionSettings] Load ConnectionSettings Success',
  ConnectionSettingsFailed = '[ConnectionSettings] Load ConnectionSettings Failed'
}

export class ConnectionSettingsAction implements Action {
  public readonly type = ConnectionSettingsActionTypes.ConnectionSettings;
  public constructor() {}
}

export class ConnectionSettingsSuccessAction implements Action {
  public readonly type = ConnectionSettingsActionTypes.ConnectionSettingsSuccess;
  public constructor(public payload: ConnectionSettingsResponse) {}
}

export class ConnectionSettingsFailedAction implements Action {
  public readonly type = ConnectionSettingsActionTypes.ConnectionSettingsFailed;
  public constructor() {}
}

export type ConnectionSettingsActionsUnion =
  | ConnectionSettingsAction
  | ConnectionSettingsSuccessAction
  | ConnectionSettingsFailedAction;
