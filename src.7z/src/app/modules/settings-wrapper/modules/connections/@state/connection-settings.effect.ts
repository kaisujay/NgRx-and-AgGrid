import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ConnectionSettingsService } from '../services/connection-settings.service';
import {
  ConnectionSettingsActionTypes,
  ConnectionSettingsActionsUnion,
  ConnectionSettingsFailedAction,
  ConnectionSettingsSuccessAction
} from './connection-settings.action';

@Injectable()
export class ConnectionsSettingEffect {
  public constructor(
    private actions$: Actions,
    private connectionSettingSvc: ConnectionSettingsService
  ) {}
  public loadConnectionSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ConnectionSettingsActionTypes.ConnectionSettings),
      switchMap((_action: ConnectionSettingsActionsUnion) =>
        this.connectionSettingSvc.getConnectionSettings().pipe(
          map(_data => new ConnectionSettingsSuccessAction(_data)),
          catchError(_err => of(new ConnectionSettingsFailedAction()))
        )
      )
    )
  );
}
