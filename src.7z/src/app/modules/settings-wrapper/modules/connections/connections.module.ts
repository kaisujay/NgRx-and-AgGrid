import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { ConnectionsSettingEffect } from './@state/connection-settings.effect';
import { ConnectionSettingsReducer } from './@state/connection-settings.reducer';
import { ConnectionsComponent } from './components/connections.component';
import { ConnectionsRoutingModule } from './connections-routing.module';
import { ConnectionSettingsService } from './services/connection-settings.service';

@NgModule({
  declarations: [ConnectionsComponent],
  imports: [
    CommonModule,
    LoaderModule,
    ConnectionsRoutingModule,
    AdminSharedModule,
    StoreModule.forFeature('connectionSettings', ConnectionSettingsReducer),
    EffectsModule.forFeature([ConnectionsSettingEffect])
  ],
  providers: [ConnectionSettingsService]
})
export class ConnectionsModule {}
