import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { FixedIncomeDealServerService } from '../services/fixed-income-deal-server.service';
import {
  FixedIncomeDealSettingActionUnion,
  FixedIncomeDealsSettingsActionTypes,
  LoadFixedIncomeDealSettingFailedAction,
  LoadFixedIncomeDealSettingSuccessAction
} from './fixed-income-deal-settings.action';

@Injectable()
export class FixedIncomeDealSettingEffect {
  public constructor(
    private actions$: Actions,
    private fixedIncomeDealSvc: FixedIncomeDealServerService
  ) {}
  public loadConnectionSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSetting),
      switchMap((_action: FixedIncomeDealSettingActionUnion) =>
        this.fixedIncomeDealSvc.getFixedIncomeDealServerSettings().pipe(
          map(_data => new LoadFixedIncomeDealSettingSuccessAction(_data)),
          catchError(_err => of(new LoadFixedIncomeDealSettingFailedAction()))
        )
      )
    )
  );
}
