import { createFeatureSelector } from '@ngrx/store';
import {
  FixedIncomeDealSettingActionUnion,
  FixedIncomeDealsSettingsActionTypes
} from './fixed-income-deal-settings.action';

export interface FixedIncomeDealSettingStore {
  data: FixedIncomeDealSettingResponse;
  isLoading: boolean;
  isLoadError: boolean;
  isLoadSuccess: boolean;
}

export interface FixedIncomeDealSettingResponse {
  ServerUrl: string;
  Scopes: string[];
}

const initialState: FixedIncomeDealSettingStore = {
  data: null,
  isLoading: false,
  isLoadError: false,
  isLoadSuccess: false
};

export function FixedIncomeDealSettingsReducer(
  state: FixedIncomeDealSettingStore = initialState,
  action: FixedIncomeDealSettingActionUnion
): FixedIncomeDealSettingStore {
  switch (action.type) {
    case FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSetting:
      return {
        ...state,
        isLoading: true,
        isLoadError: false,
        isLoadSuccess: false
      };
    case FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSettingSuccess:
      return {
        ...state,
        isLoading: false,
        isLoadError: false,
        isLoadSuccess: true,
        data: action.payload
      };
    case FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSettingFailed:
      return {
        ...state,
        isLoading: false,
        isLoadError: true,
        isLoadSuccess: false
      };
    default:
      return state;
  }
}

export const getFixedIncomeDealSettings = createFeatureSelector<FixedIncomeDealSettingStore>('fixedIncomeDealSettings');
