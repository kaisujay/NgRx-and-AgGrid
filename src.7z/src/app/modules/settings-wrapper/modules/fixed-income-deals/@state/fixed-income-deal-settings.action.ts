import { Action } from '@ngrx/store';
import { FixedIncomeDealSettingResponse } from './fixed-income-deal-settings.reducer';

export enum FixedIncomeDealsSettingsActionTypes {
  LoadFixedIncomeDealSetting = '[FixedIncomeDealSettings] Load FixedIncomeDealSettings',
  LoadFixedIncomeDealSettingSuccess = '[FixedIncomeDealSettings] Load FixedIncomeDealSettings Success',
  LoadFixedIncomeDealSettingFailed = '[FixedIncomeDealSettings] Load FixedIncomeDealSettings Failed'
}

export class LoadFixedIncomeDealSettingAction implements Action {
  public readonly type = FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSetting;
  public constructor() {}
}

export class LoadFixedIncomeDealSettingSuccessAction implements Action {
  public readonly type = FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSettingSuccess;
  public constructor(public payload: FixedIncomeDealSettingResponse) {}
}

export class LoadFixedIncomeDealSettingFailedAction implements Action {
  public readonly type = FixedIncomeDealsSettingsActionTypes.LoadFixedIncomeDealSettingFailed;
  public constructor() {}
}

export type FixedIncomeDealSettingActionUnion =
  | LoadFixedIncomeDealSettingAction
  | LoadFixedIncomeDealSettingSuccessAction
  | LoadFixedIncomeDealSettingFailedAction;
