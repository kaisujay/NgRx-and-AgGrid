import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { FixedIncomeDealSettingResponse } from '../@state/fixed-income-deal-settings.reducer';

@Injectable()
export class FixedIncomeDealServerService {
  public constructor(private http: HttpClient) {}

  public getFixedIncomeDealServerSettings(): Observable<FixedIncomeDealSettingResponse> {
    return this.http.get<FixedIncomeDealSettingResponse>(API.settings.fixedIncomeDeal);
  }
}
