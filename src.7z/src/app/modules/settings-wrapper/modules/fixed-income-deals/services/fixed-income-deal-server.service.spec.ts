import { TestBed } from '@angular/core/testing';

import { FixedIncomeDealServerService } from './fixed-income-deal-server.service';

describe('FixedIncomeDealServerService', () => {
  let service: FixedIncomeDealServerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FixedIncomeDealServerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
