import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { LoadFixedIncomeDealSettingAction } from '../@state/fixed-income-deal-settings.action';
import { FixedIncomeDealSettingStore, getFixedIncomeDealSettings } from '../@state/fixed-income-deal-settings.reducer';

@Component({
  selector: 'app-fixed-income-deals',
  templateUrl: './fixed-income-deals.component.html',
  styleUrls: ['./fixed-income-deals.component.scss']
})
export class FixedIncomeDealsComponent implements OnInit {
  public fixedIncomeDealSettings$: Observable<FixedIncomeDealSettingStore>;

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.store.dispatch(new LoadFixedIncomeDealSettingAction());
    this.fixedIncomeDealSettings$ = this.store.select(getFixedIncomeDealSettings);
  }
}
