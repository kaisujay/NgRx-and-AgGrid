import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FixedIncomeDealsComponent } from './fixed-income-deals.component';

describe('FixedIncomeDealsComponent', () => {
  let component: FixedIncomeDealsComponent;
  let fixture: ComponentFixture<FixedIncomeDealsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FixedIncomeDealsComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(FixedIncomeDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
