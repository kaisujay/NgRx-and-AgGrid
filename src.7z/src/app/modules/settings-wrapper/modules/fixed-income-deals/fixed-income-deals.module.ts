import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { FixedIncomeDealSettingEffect } from './@state/fixed-income-deal-settings.effect';
import { FixedIncomeDealSettingsReducer } from './@state/fixed-income-deal-settings.reducer';
import { FixedIncomeDealsComponent } from './components/fixed-income-deals.component';
import { FixedIncomeDealsRoutingModule } from './fixed-income-deals-routing.module';
import { FixedIncomeDealServerService } from './services/fixed-income-deal-server.service';

@NgModule({
  declarations: [FixedIncomeDealsComponent],
  imports: [
    CommonModule,
    AdminSharedModule,
    LoaderModule,
    FixedIncomeDealsRoutingModule,
    StoreModule.forFeature('fixedIncomeDealSettings', FixedIncomeDealSettingsReducer),
    EffectsModule.forFeature([FixedIncomeDealSettingEffect])
  ],
  providers: [FixedIncomeDealServerService]
})
export class FixedIncomeDealsModule {}
