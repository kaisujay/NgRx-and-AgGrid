import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoaderModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadAnalyticsEffect } from './@states/effects/load-analytics.effect';
import { SaveAnalyticsEffect } from './@states/effects/save-analytics.effect';
import { AnalyticsStateReducer } from './@states/reducers/analytics.reducer';
import { AnalyticsRoutingModule } from './analytics-routing.module';
import { AnalyticsComponent } from './components/analytics.component';
import { AnalyticsGuard } from './guards/analytics.guard';
import { AnalyticsHttpService } from './services/analytics-http.service';

@NgModule({
  declarations: [AnalyticsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    LoaderModule,
    SPRFormsModule,
    AdminSharedModule,
    SPRFormsModule,
    StoreModule.forFeature('analytics', AnalyticsStateReducer),
    EffectsModule.forFeature([LoadAnalyticsEffect, SaveAnalyticsEffect]),
    AnalyticsRoutingModule
  ],
  providers: [AnalyticsHttpService, AnalyticsGuard, DialogService]
})
export class AnalyticsModule {}
