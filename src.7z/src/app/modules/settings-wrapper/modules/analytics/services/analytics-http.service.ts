import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { AnalyticsPayloadModel, AnalyticsResponseModel } from '../models/analytics.model';

@Injectable()
export class AnalyticsHttpService {
  public constructor(private http: HttpClient) {}

  public getAnalytics(): Observable<AnalyticsResponseModel> {
    const url = buildApiString(API.analytics);

    return this.http.get<AnalyticsResponseModel>(url);
  }

  public putAnalytics(payload: AnalyticsPayloadModel): Observable<AnalyticsResponseModel> {
    const url = buildApiString(API.analytics);

    return this.http.put<AnalyticsResponseModel>(url, payload);
  }
}
