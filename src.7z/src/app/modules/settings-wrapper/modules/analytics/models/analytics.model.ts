export interface AnalyticsResponseModel {
  View: boolean;
  SignInAndOut: boolean;
  SessionValidated: boolean;
  DealDetails: boolean;
  Grid: boolean;
  Search: boolean;
  Export: boolean;
  SignalR: boolean;
  Others: boolean;
  DealQuery: boolean;
  DealActivity: boolean;
  RowVersion: number;
  Notifications: boolean;
  Connections: boolean;
}

export interface AnalyticsPayloadModel {
  Connections: boolean;
  DealActivity: boolean;
  DealDetails: boolean;
  DealQuery: boolean;
  Export: boolean;
  Grid: boolean;
  Notifications: boolean;
  Others: boolean;
  RowVersion: number;
  Search: boolean;
  SessionValidated: boolean;
  SignInAndOut: boolean;
  SignalR: boolean;
  View: boolean;
}
