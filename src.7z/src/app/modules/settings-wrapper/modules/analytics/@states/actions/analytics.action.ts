import { Action } from '@ngrx/store';
import { AnalyticsPayloadModel, AnalyticsResponseModel } from '../../models/analytics.model';

export enum AnalyticsActionTypes {
  LoadAnalytics = '[Analytics] Load Analytics',
  LoadAnalyticsSuccess = '[Analytics] Load Analytics Success',
  LoadAnalyticsFailed = '[Analytics] Load Analytics Failed',

  SaveAnalytics = '[Analytics] Save Analytics',
  SaveAnalyticsSuccess = '[Analytics] Save Analytics Success',
  SaveAnalyticsFailed = '[Analytics] Save Analytics Failed'
}

export class LoadAnalyticsAction implements Action {
  public readonly type = AnalyticsActionTypes.LoadAnalytics;
  public constructor() {}
}

export class LoadAnalyticsSuccessAction implements Action {
  public readonly type = AnalyticsActionTypes.LoadAnalyticsSuccess;
  public constructor(public payload: AnalyticsResponseModel) {}
}

export class LoadAnalyticsFailedAction implements Action {
  public readonly type = AnalyticsActionTypes.LoadAnalyticsFailed;
  public constructor(public error: string) {}
}

export class SaveAnalyticsAction implements Action {
  public readonly type = AnalyticsActionTypes.SaveAnalytics;
  public constructor(public payload: AnalyticsPayloadModel) {}
}

export class SaveAnalyticsSuccessAction implements Action {
  public readonly type = AnalyticsActionTypes.SaveAnalyticsSuccess;
  public constructor(public response: AnalyticsResponseModel) {}
}

export class SaveAnalyticsFailedAction implements Action {
  public readonly type = AnalyticsActionTypes.SaveAnalyticsFailed;
  public constructor(public error: string) {}
}
export type AnalyticsActionsUnion =
  | LoadAnalyticsAction
  | LoadAnalyticsSuccessAction
  | LoadAnalyticsFailedAction
  | SaveAnalyticsAction
  | SaveAnalyticsSuccessAction
  | SaveAnalyticsFailedAction;
