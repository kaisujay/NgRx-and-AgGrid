import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { AnalyticsHttpService } from '../../services/analytics-http.service';
import {
  AnalyticsActionTypes,
  SaveAnalyticsAction,
  SaveAnalyticsFailedAction,
  SaveAnalyticsSuccessAction
} from '../actions/analytics.action';

@Injectable()
export class SaveAnalyticsEffect {
  public constructor(
    private actions$: Actions,
    private http: AnalyticsHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveAnalyticsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AnalyticsActionTypes.SaveAnalytics),
      switchMap((action: SaveAnalyticsAction) => {
        return this.http.putAnalytics(action.payload).pipe(
          map(response => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Analytics Saved Successfully');
            return new SaveAnalyticsSuccessAction(response);
          }),
          catchError(err => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error While Saving Analytics');
            return of(new SaveAnalyticsFailedAction(err));
          })
        );
      })
    )
  );
}
