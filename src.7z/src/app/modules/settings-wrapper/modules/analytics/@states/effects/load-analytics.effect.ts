import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { AnalyticsHttpService } from '../../services/analytics-http.service';
import {
  AnalyticsActionTypes,
  LoadAnalyticsAction,
  LoadAnalyticsFailedAction,
  LoadAnalyticsSuccessAction
} from '../actions/analytics.action';

@Injectable()
export class LoadAnalyticsEffect {
  public constructor(
    private actions$: Actions,
    private http: AnalyticsHttpService
  ) {}

  public loadAnalyticsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AnalyticsActionTypes.LoadAnalytics),
      switchMap((action: LoadAnalyticsAction) => {
        return this.http.getAnalytics().pipe(
          map(data => new LoadAnalyticsSuccessAction(data)),
          catchError(err => of(new LoadAnalyticsFailedAction(err)))
        );
      })
    )
  );
}
