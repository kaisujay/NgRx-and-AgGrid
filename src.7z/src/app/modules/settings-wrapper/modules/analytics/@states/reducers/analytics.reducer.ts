import { createFeatureSelector } from '@ngrx/store';
import { AnalyticsResponseModel } from '../../models/analytics.model';
import { AnalyticsActionTypes, AnalyticsActionsUnion } from '../actions/analytics.action';

export interface AnalyticsState {
  loadAnalytics: {
    data: AnalyticsResponseModel;
    isLoading: boolean;
    isLoaded: boolean;
    error: string;
  };
  saveAnalytics: {
    isSaving: boolean;
    isSaved: boolean;
    error: string;
  };
}

export const initialState: AnalyticsState = {
  loadAnalytics: {
    data: null,
    isLoading: false,
    isLoaded: false,
    error: null
  },
  saveAnalytics: {
    isSaving: false,
    isSaved: false,
    error: null
  }
};

export function AnalyticsStateReducer(
  state: AnalyticsState = initialState,
  action: AnalyticsActionsUnion
): AnalyticsState {
  switch (action.type) {
    case AnalyticsActionTypes.LoadAnalytics:
      return {
        ...state,
        loadAnalytics: {
          ...state.loadAnalytics,
          isLoading: true,
          isLoaded: false,
          error: null
        },
        saveAnalytics: {
          ...state.saveAnalytics,
          isSaved: false,
          isSaving: false
        }
      };
    case AnalyticsActionTypes.LoadAnalyticsSuccess:
      return {
        ...state,
        loadAnalytics: {
          data: action.payload,
          isLoading: false,
          isLoaded: true,
          error: null
        },
        saveAnalytics: {
          ...state.saveAnalytics,
          isSaved: false,
          isSaving: false
        }
      };
    case AnalyticsActionTypes.LoadAnalyticsFailed:
      return {
        ...state,
        loadAnalytics: {
          ...state.loadAnalytics,
          isLoading: false,
          isLoaded: false,
          error: action.error
        }
      };
    case AnalyticsActionTypes.SaveAnalytics:
      return {
        ...state,
        loadAnalytics: {
          ...state.loadAnalytics,
          isLoading: false,
          isLoaded: false
        },
        saveAnalytics: {
          ...state.loadAnalytics,
          isSaving: true,
          isSaved: false,
          error: null
        }
      };
    case AnalyticsActionTypes.SaveAnalyticsSuccess:
      return {
        ...state,
        loadAnalytics: {
          data: action.response,
          isLoading: false,
          isLoaded: false,
          error: null
        },
        saveAnalytics: {
          isSaving: false,
          isSaved: true,
          error: null
        }
      };
    case AnalyticsActionTypes.SaveAnalyticsFailed:
      return {
        ...state,
        saveAnalytics: {
          isSaving: false,
          isSaved: false,
          error: action.error
        }
      };

    default:
      return state;
  }
}

export const getAnalyticsState = createFeatureSelector<AnalyticsState>('analytics');
