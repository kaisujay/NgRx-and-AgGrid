import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import { LoadAnalyticsAction, SaveAnalyticsAction } from '../@states/actions/analytics.action';
import { AnalyticsState, getAnalyticsState } from '../@states/reducers/analytics.reducer';
import { AnalyticsPayloadModel, AnalyticsResponseModel } from '../models/analytics.model';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {
  public analyticsState$: Observable<AnalyticsState>;

  public analyticsFormGroup: FormGroup;
  public cupcakeFlavors = CupcakeFlavors;

  public analyticsPayload: AnalyticsPayloadModel;
  public analyticsResponse: AnalyticsResponseModel;
  public initialAnalyticsResponse: AnalyticsResponseModel;
  public dataLoaded = false;

  public constructor(
    private formBuilder: FormBuilder,
    public store$: Store
  ) {}

  public ngOnInit(): void {
    this.subscribeToAnalyticsData();

    this.store$.dispatch(new LoadAnalyticsAction());
  }

  public subscribeToAnalyticsData() {
    this.analyticsState$ = this.store$.pipe(
      select(getAnalyticsState),
      tap(state => {
        if (state.loadAnalytics.isLoaded) {
          this.dataLoaded = true;
          this.analyticsResponse = this.deepCopy(state.loadAnalytics.data);
          this.initialAnalyticsResponse = this.deepCopy(state.loadAnalytics.data);

          this.initForm();
        }
        if (state.saveAnalytics.isSaved) {
          this.store$.dispatch(new LoadAnalyticsAction());
        }
      })
    );
  }

  public initForm() {
    this.analyticsFormGroup = this.formBuilder.group({
      View: new FormControl(this.initialAnalyticsResponse.View),
      SignInAndOut: new FormControl(this.initialAnalyticsResponse.SignInAndOut),
      SessionValidated: new FormControl(this.initialAnalyticsResponse.SessionValidated),
      DealDetails: new FormControl(this.initialAnalyticsResponse.DealDetails),
      Grid: new FormControl(this.initialAnalyticsResponse.Grid),
      Search: new FormControl(this.initialAnalyticsResponse.Search),
      Export: new FormControl(this.initialAnalyticsResponse.Export),
      SignalR: new FormControl(this.initialAnalyticsResponse.SignalR),
      Others: new FormControl(this.initialAnalyticsResponse.Others),
      DealQuery: new FormControl(this.initialAnalyticsResponse.DealQuery),
      DealActivity: new FormControl(this.initialAnalyticsResponse.DealActivity),
      Notifications: new FormControl(this.initialAnalyticsResponse.Notifications),
      Connections: new FormControl(this.initialAnalyticsResponse.Connections),
      RowVersion: new FormControl(this.initialAnalyticsResponse.RowVersion)
    });
  }

  public isUnsavedChanges() {
    if (this.dataLoaded) {
      this.saveReady();

      if (
        JSON.stringify(this.sortObject(this.analyticsResponse)) !==
        JSON.stringify(this.sortObject(this.initialAnalyticsResponse))
      ) {
        return false;
      } else {
        return true;
      }
    }
    return true;
  }

  public onSave() {
    this.saveReady();

    this.store$.dispatch(new SaveAnalyticsAction(this.analyticsPayload));
  }

  public saveReady() {
    if (this.dataLoaded) {
      this.analyticsPayload = this.analyticsFormGroup.value;

      this.analyticsResponse = this.analyticsPayload;
    }
  }

  private sortObject(unSorted): {} {
    const res = Object.keys(unSorted)
      .sort()
      .reduce((obj, key) => {
        obj[key] = unSorted[key];
        return obj;
      }, {});

    return res;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public deepCopy(oldObj: any) {
    let newObj = oldObj;
    if (oldObj && typeof oldObj === 'object') {
      if (oldObj instanceof Date) {
        return new Date(oldObj.getTime());
      }
      newObj = Object.prototype.toString.call(oldObj) === '[object Array]' ? [] : {};
      for (const i in oldObj) {
        newObj[i] = this.deepCopy(oldObj[i]);
      }
    }
    return newObj;
  }
}
