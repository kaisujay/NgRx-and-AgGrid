import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { LoadIdentityServerSettingsAction } from '../@state/identity-server-settings.action';
import { IdentityServerSettingsStore, getIdentityServerSettings } from '../@state/identity-server-settings.reducer';

@Component({
  selector: 'app-identity-server',
  templateUrl: './identity-server.component.html',
  styleUrls: ['./identity-server.component.scss']
})
export class IdentityServerComponent implements OnInit {
  public identityServerSettingState$: Observable<IdentityServerSettingsStore>;

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.store.dispatch(new LoadIdentityServerSettingsAction());
    this.identityServerSettingState$ = this.store.select(getIdentityServerSettings);
  }
}
