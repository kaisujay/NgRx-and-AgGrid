import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IdentityServerComponent } from './components/identity-server.component';

const routes: Routes = [
  {
    path: '',
    component: IdentityServerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IdentityServerRoutingModule {}
