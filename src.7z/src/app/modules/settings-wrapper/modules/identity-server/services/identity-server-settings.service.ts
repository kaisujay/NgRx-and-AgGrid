import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { IdentityServerSettingsResponse } from '../@state/identity-server-settings.reducer';

@Injectable()
export class IdentityServerSettingsService {
  public constructor(private http: HttpClient) {}

  public getIdentityServerSettings(): Observable<IdentityServerSettingsResponse> {
    return this.http.get<IdentityServerSettingsResponse>(API.settings.identityServer);
  }
}
