import { TestBed } from '@angular/core/testing';
import { IdentityServerSettingsService } from './identity-server-settings.service';

describe('IdentiyServerSettingsService', () => {
  let service: IdentityServerSettingsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IdentityServerSettingsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
