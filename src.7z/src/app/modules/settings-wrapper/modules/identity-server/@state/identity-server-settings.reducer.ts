import { createFeatureSelector } from '@ngrx/store';
import {
  IdentityServerSettingsActionTypes,
  IdentityServerSettingsActionsUnion
} from './identity-server-settings.action';

export interface IdentityServerSettingsStore {
  data: IdentityServerSettingsResponse;
  isLoading: boolean;
  isLoadError: boolean;
  isLoadSuccess: boolean;
}

export interface IdentityServerSettingsResponse {
  IdentityClientId: string;
  IdentityClientSecret: string;
  IdentityServerUrl: string;
}

const initialState: IdentityServerSettingsStore = {
  data: null,
  isLoading: false,
  isLoadError: false,
  isLoadSuccess: false
};

export function IdentityServerSettingsReducer(
  state: IdentityServerSettingsStore = initialState,
  action: IdentityServerSettingsActionsUnion
): IdentityServerSettingsStore {
  switch (action.type) {
    case IdentityServerSettingsActionTypes.LoadIdentityServerSettings:
      return {
        ...state,
        isLoading: true,
        isLoadError: false,
        isLoadSuccess: false
      };
    case IdentityServerSettingsActionTypes.LoadIdentityServerSettingsSuccess:
      return {
        ...state,
        isLoading: false,
        isLoadError: false,
        isLoadSuccess: true,
        data: action.payload
      };
    case IdentityServerSettingsActionTypes.LoadIdentityServerSettingsFailed:
      return {
        ...state,
        isLoading: false,
        isLoadError: true,
        isLoadSuccess: false
      };
    default:
      return state;
  }
}

export const getIdentityServerSettings = createFeatureSelector<IdentityServerSettingsStore>('identityServerSettings');
