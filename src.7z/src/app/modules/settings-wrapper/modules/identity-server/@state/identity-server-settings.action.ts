import { Action } from '@ngrx/store';
import { IdentityServerSettingsResponse } from './identity-server-settings.reducer';

export enum IdentityServerSettingsActionTypes {
  LoadIdentityServerSettings = '[IdentityServerSettings] Load IdentityServerSettings',
  LoadIdentityServerSettingsSuccess = '[IdentityServerSettings] Load IdentityServerSettings Success',
  LoadIdentityServerSettingsFailed = '[IdentityServerSettings] Load IdentityServerSettings Failed'
}

export class LoadIdentityServerSettingsAction implements Action {
  public readonly type = IdentityServerSettingsActionTypes.LoadIdentityServerSettings;
  public constructor() {}
}

export class LoadIdentityServerSettingsSuccessAction implements Action {
  public readonly type = IdentityServerSettingsActionTypes.LoadIdentityServerSettingsSuccess;
  public constructor(public payload: IdentityServerSettingsResponse) {}
}

export class LoadIdentityServerSettingsFailedAction implements Action {
  public readonly type = IdentityServerSettingsActionTypes.LoadIdentityServerSettingsFailed;
  public constructor() {}
}

export type IdentityServerSettingsActionsUnion =
  | LoadIdentityServerSettingsAction
  | LoadIdentityServerSettingsSuccessAction
  | LoadIdentityServerSettingsFailedAction;
