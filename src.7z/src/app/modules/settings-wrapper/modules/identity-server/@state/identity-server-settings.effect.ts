import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { IdentityServerSettingsService } from '../services/identity-server-settings.service';
import {
  IdentityServerSettingsActionTypes,
  IdentityServerSettingsActionsUnion,
  LoadIdentityServerSettingsFailedAction,
  LoadIdentityServerSettingsSuccessAction
} from './identity-server-settings.action';

@Injectable()
export class LoadIdentityServerSettingEffect {
  public constructor(
    private actions$: Actions,
    private identityServerSvc: IdentityServerSettingsService
  ) {}
  public loadIdentityServerSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(IdentityServerSettingsActionTypes.LoadIdentityServerSettings),
      switchMap((_action: IdentityServerSettingsActionsUnion) =>
        this.identityServerSvc.getIdentityServerSettings().pipe(
          map(_data => new LoadIdentityServerSettingsSuccessAction(_data)),
          catchError(_err => of(new LoadIdentityServerSettingsFailedAction()))
        )
      )
    )
  );
}
