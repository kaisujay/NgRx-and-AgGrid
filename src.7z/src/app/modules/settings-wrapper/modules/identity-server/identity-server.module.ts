import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadIdentityServerSettingEffect } from './@state/identity-server-settings.effect';
import { IdentityServerSettingsReducer } from './@state/identity-server-settings.reducer';
import { IdentityServerComponent } from './components/identity-server.component';
import { IdentityServerRoutingModule } from './identity-server-routing.module';
import { IdentityServerSettingsService } from './services/identity-server-settings.service';

@NgModule({
  declarations: [IdentityServerComponent],
  imports: [
    CommonModule,
    LoaderModule,
    IdentityServerRoutingModule,
    AdminSharedModule,
    StoreModule.forFeature('identityServerSettings', IdentityServerSettingsReducer),
    EffectsModule.forFeature([LoadIdentityServerSettingEffect])
  ],
  providers: [IdentityServerSettingsService]
})
export class IdentityServerModule {}
