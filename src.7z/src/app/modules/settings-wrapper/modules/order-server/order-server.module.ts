import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { OrderServerSettingEffect } from './@state/order-server-settings.effect';
import { OrderServerSettingsReducer } from './@state/order-server-settings.reducer';
import { OrderServerComponent } from './components/order-server.component';
import { OrderServerRoutingModule } from './order-server-routing.module';
import { OrderServerService } from './services/order-server.service';

@NgModule({
  declarations: [OrderServerComponent],
  imports: [
    CommonModule,
    LoaderModule,
    OrderServerRoutingModule,
    AdminSharedModule,
    StoreModule.forFeature('orderServerSettings', OrderServerSettingsReducer),
    EffectsModule.forFeature([OrderServerSettingEffect])
  ],
  providers: [OrderServerService]
})
export class OrderServerModule {}
