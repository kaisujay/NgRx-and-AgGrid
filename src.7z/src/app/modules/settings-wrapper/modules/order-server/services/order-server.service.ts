import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { OrderServerSettingsResponse } from '../@state/order-server-settings.reducer';

@Injectable()
export class OrderServerService {
  public constructor(private http: HttpClient) {}

  public getOrderServerSettings(): Observable<OrderServerSettingsResponse> {
    return this.http.get<OrderServerSettingsResponse>(API.settings.orderServer);
  }
}
