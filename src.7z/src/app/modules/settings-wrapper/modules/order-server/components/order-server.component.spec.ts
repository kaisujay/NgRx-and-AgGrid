import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderServerComponent } from './order-server.component';

describe('OrderServerComponent', () => {
  let component: OrderServerComponent;
  let fixture: ComponentFixture<OrderServerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OrderServerComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(OrderServerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
