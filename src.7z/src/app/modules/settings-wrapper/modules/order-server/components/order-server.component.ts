import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { LoadOrderServerSettingsAction } from '../@state/order-server-settings.action';
import { OrderServerSettingsStore, getOrderServerSettings } from '../@state/order-server-settings.reducer';

@Component({
  selector: 'app-order-server',
  templateUrl: './order-server.component.html',
  styleUrls: ['./order-server.component.scss']
})
export class OrderServerComponent implements OnInit {
  public orderServerSettingState$: Observable<OrderServerSettingsStore>;

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.store.dispatch(new LoadOrderServerSettingsAction());
    this.orderServerSettingState$ = this.store.select(getOrderServerSettings);
  }
}
