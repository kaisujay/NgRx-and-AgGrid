import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { OrderServerService } from '../services/order-server.service';
import {
  LoadOrderServerSettingsFailedAction,
  LoadOrderServerSettingsSuccessAction,
  OrderServerSettingsActionTypes,
  OrderServerSettingsUnion
} from './order-server-settings.action';

@Injectable()
export class OrderServerSettingEffect {
  public constructor(
    private actions$: Actions,
    private orderSettingSvc: OrderServerService
  ) {}
  public loadConnectionSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(OrderServerSettingsActionTypes.LoadOrderServerSettings),
      switchMap((_action: OrderServerSettingsUnion) =>
        this.orderSettingSvc.getOrderServerSettings().pipe(
          map(_data => new LoadOrderServerSettingsSuccessAction(_data)),
          catchError(_err => of(new LoadOrderServerSettingsFailedAction()))
        )
      )
    )
  );
}
