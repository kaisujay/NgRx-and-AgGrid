import { Action } from '@ngrx/store';
import { OrderServerSettingsResponse } from './order-server-settings.reducer';

export enum OrderServerSettingsActionTypes {
  LoadOrderServerSettings = '[OrderServerSettings] Load OrderServerSettings',
  LoadOrderServerSettingsSuccess = '[OrderServerSettings] Load OrderServerSettings Success',
  LoadOrderServerSettingsFailed = '[OrderServerSettings] Load OrderServerSettings Failed'
}

export class LoadOrderServerSettingsAction implements Action {
  public readonly type = OrderServerSettingsActionTypes.LoadOrderServerSettings;
  public constructor() {}
}

export class LoadOrderServerSettingsSuccessAction implements Action {
  public readonly type = OrderServerSettingsActionTypes.LoadOrderServerSettingsSuccess;
  public constructor(public payload: OrderServerSettingsResponse) {}
}

export class LoadOrderServerSettingsFailedAction implements Action {
  public readonly type = OrderServerSettingsActionTypes.LoadOrderServerSettingsFailed;
  public constructor() {}
}

export type OrderServerSettingsUnion =
  | LoadOrderServerSettingsAction
  | LoadOrderServerSettingsSuccessAction
  | LoadOrderServerSettingsFailedAction;
