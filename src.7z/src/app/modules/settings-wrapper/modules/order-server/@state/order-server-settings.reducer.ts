import { createFeatureSelector } from '@ngrx/store';
import { OrderServerSettingsActionTypes, OrderServerSettingsUnion } from './order-server-settings.action';

export interface OrderServerSettingsStore {
  data: OrderServerSettingsResponse;
  isLoading: boolean;
  isLoadError: boolean;
  isLoadSuccess: boolean;
}

export interface OrderServerSettingsResponse {
  ServerUrl: string;
  Scopes: string[];
}

const initialState: OrderServerSettingsStore = {
  data: null,
  isLoading: false,
  isLoadError: false,
  isLoadSuccess: false
};

export function OrderServerSettingsReducer(
  state: OrderServerSettingsStore = initialState,
  action: OrderServerSettingsUnion
): OrderServerSettingsStore {
  switch (action.type) {
    case OrderServerSettingsActionTypes.LoadOrderServerSettings:
      return {
        ...state,
        isLoading: true,
        isLoadError: false,
        isLoadSuccess: false
      };
    case OrderServerSettingsActionTypes.LoadOrderServerSettingsSuccess:
      return {
        ...state,
        isLoading: false,
        isLoadError: false,
        isLoadSuccess: true,
        data: action.payload
      };
    case OrderServerSettingsActionTypes.LoadOrderServerSettingsFailed:
      return {
        ...state,
        isLoading: false,
        isLoadError: true,
        isLoadSuccess: false
      };
    default:
      return state;
  }
}

export const getOrderServerSettings = createFeatureSelector<OrderServerSettingsStore>('orderServerSettings');
