import { Component } from '@angular/core';

@Component({
  selector: 'app-settings-wrapper',
  templateUrl: './settings-wrapper.component.html',
  styleUrls: ['./settings-wrapper.component.scss']
})
export class SettingsWrapperComponent {}
