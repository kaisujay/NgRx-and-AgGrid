import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SettingsWrapperComponent } from './components/settings-wrapper.component';

const routes: Routes = [
  {
    path: '',
    component: SettingsWrapperComponent,
    children: [
      {
        path: 'analytics',
        loadChildren: () => import('./modules/analytics/analytics.module').then(m => m.AnalyticsModule)
      },
      {
        path: 'productPortalSettings',
        loadChildren: () =>
          import('./modules/product-portal-settings/product-portal-settings.module').then(
            m => m.ProductPortalSettingsModule
          )
      },
      {
        path: 'documents',
        loadChildren: () => import('./modules/documents/documents.module').then(m => m.DocumentsModule)
      },
      {
        path: 'tasks',
        loadChildren: () => import('./modules/tasks/tasks.module').then(m => m.TasksModule)
      },
      {
        path: 'identityServer',
        loadChildren: () => import('./modules/identity-server/identity-server.module').then(m => m.IdentityServerModule)
      },
      {
        path: 'orderServer',
        loadChildren: () => import('./modules/order-server/order-server.module').then(m => m.OrderServerModule)
      },
      {
        path: 'connections',
        loadChildren: () => import('./modules/connections/connections.module').then(m => m.ConnectionsModule)
      },
      {
        path: 'fixedIncomeDeals',
        loadChildren: () =>
          import('./modules/fixed-income-deals/fixed-income-deals.module').then(m => m.FixedIncomeDealsModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsWrapperRoutingModule {}
