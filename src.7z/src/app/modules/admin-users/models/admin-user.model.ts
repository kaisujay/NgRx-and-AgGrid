export interface JobFunction {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}

export interface CreateAdminUserModalContext {
  JobFunctions: JobFunction[];
}

export interface AdminUser {
  FirstName: string;
  LastName: string;
  Email: string;
  Jobfunction: string;
  Status: string;
  success?: boolean;
  Password?: string;
}

export interface CreateAdminUserResponse {
  Password: string;
}

export interface CreateAdminUserError extends CreateAdminErrorResponse, BadRequestErrorResponse {}

export interface CreateAdminErrorResponse {
  Message: string;
  ModelState: {
    [k: string]: string[];
  };
}

export interface BadRequestErrorResponse {
  errors: {
    [k: string]: string[];
  };
  type: string;
  title: string;
  status: number;
  traceId: string;
}
