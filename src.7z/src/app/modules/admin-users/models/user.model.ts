export interface AdminUserModel {
  Email: string;
  FirstName: string;
  Id: string;
  JobFunction: string;
  LastLoginDate: Date;
  LastName: string;
  Lockout: boolean;
  RowVersion: number;
  Status: string;
  UserName: string;
}
