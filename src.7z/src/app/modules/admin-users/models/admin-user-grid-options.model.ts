import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { CustomLoadingCellRendererComponent } from '@shared/components/loading-cell-renderer/loading-cell-renderer.component';
import { GridOptions } from 'ag-grid-community';
import { FirstLastNameComponent } from '../components/admin-users/ag-grid-templates/first-last-name.template/first-last-name.component';

export const ADMIN_USER_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'First Name',
      field: 'FirstName',
      cellRendererFramework: FirstLastNameComponent
    },
    {
      headerName: 'Last Name',
      field: 'LastName',
      minWidth: 190,
      cellRendererFramework: FirstLastNameComponent
    },
    { headerName: 'Email', field: 'Email', suppressColumnsToolPanel: true },
    { headerName: 'Status', field: 'Status' },
    { headerName: 'Job Function', field: 'JobFunction' },
    { headerName: 'Last Login Date', field: 'LastLoginDate' },
    {
      headerName: 'Locked',
      field: 'Lockout',
      cellRenderer: 'checkboxRenderer',
      maxWidth: 100
    }
  ],
  defaultColDef: {
    flex: 1,
    minWidth: 90,
    resizable: true,
    sortable: true
  },
  frameworkComponents: {
    checkboxRenderer: CheckboxRendererComponent
  },
  rowModelType: 'serverSide',
  serverSideStoreType: 'partial',
  pagination: true,
  paginationPageSize: 50,
  cacheBlockSize: 50,
  tooltipShowDelay: 1000,
  animateRows: true,
  loadingCellRendererFramework: CustomLoadingCellRendererComponent,
  suppressRowClickSelection: true,
  overlayNoRowsTemplate: 'No records to dispaly',
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressNoRowsOverlay: false,
  suppressLoadingOverlay: false,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true
};
