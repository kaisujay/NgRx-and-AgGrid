import { Action } from '@ngrx/store';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { AdminUser, JobFunction } from '../../models/admin-user.model';
import { AdminUserModel } from '../../models/user.model';

export enum AdminUsersActionTypes {
  LoadUsers = '[Admin Users] Load Users',
  LoadUsersSuccess = '[Admin Users] Load Users Success',
  LoadUsersFailed = '[Admin Users] Load Users Failed',

  LoadJobFunctions = '[Admin Users] Load Job Functions',
  LoadJobFunctionsSuccess = '[Admin Users] Load Job Functions Success',
  LoadJobFunctionsFailed = '[Admin Users] Load Job Functions Failed',

  EditUser = '[Admin Users] Edit User',

  SaveEditedUser = '[Admin Users] Save Edited User',
  SaveEditedUserSuccess = '[Admin Users] Save Edited User Success',
  SaveEditedUserFailed = '[Admin Users] Save Edited User Failed',

  CreateUser = '[Admin Users] Create User',

  SaveCreatedUser = '[Admin Users] Save Created User',
  SaveCreatedUserSuccess = '[Admin Users] Save Created User Success',
  SaveCreatedUserFailed = '[Admin Users] Save Created User Failed',

  ClearCreateUserHttpErrors = '[Admin Users] Clear Create User Http Errors',

  ResetPassword = '[Admin Users] Reset Password',
  ResetPasswordSuccess = '[Admin Users] Reset Password Success',
  ResetPasswordFailed = '[Admin Users] Reset Password Failed',

  UnlockUser = '[Admin Users] Unlock User',
  UnlockUserSuccess = '[Admin Users] Unlock User Success',
  UnlockUserFailed = '[Admin Users] Unlock User Failed',

  ExportToXLSX = '[Admin Users] Export to XLSX',
  ExportToXLSXSuccess = '[Admin Users] Export to XLSX Success',
  ExportToXLSXFailed = '[Admin Users] Export to XLSX Failed',

  CloseModals = '[Admin Users] Close Modals'
}

export class LoadUsersAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadUsers;
  public constructor(
    public payload: {
      params: IServerSideGetRowsRequest;
      filter: string;
    }
  ) {}
}

export class LoadUsersSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadUsersSuccess;
  public constructor(
    public payload: {
      users: {
        rowData: AdminUserModel[];
        rowCount: number;
      };
    }
  ) {}
}

export class LoadUsersFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadUsersFailed;
  public constructor() {}
}

export class LoadJobFunctionsAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadJobFunctions;
  public constructor() {}
}

export class LoadJobFunctionsSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadJobFunctionsSuccess;
  public constructor(public jobFunctions: JobFunction[]) {}
}

export class LoadJobFunctionsFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.LoadJobFunctionsFailed;
  public constructor() {}
}

export class EditUserAction implements Action {
  public readonly type = AdminUsersActionTypes.EditUser;
  public constructor(public payload: { user: AdminUserModel }) {}
}

export class SaveEditedUserAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveEditedUser;
  public constructor(public payload: { id: string; user: Partial<AdminUserModel> }) {}
}

export class SaveEditedUserSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveEditedUserSuccess;
  public constructor() {}
}

export class SaveEditedUserFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveEditedUserFailed;
  public constructor() {}
}

export class CreateUserAction implements Action {
  public readonly type = AdminUsersActionTypes.CreateUser;
  public constructor() {}
}

export class SaveCreatedUserAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveCreatedUser;
  public constructor(public payload: AdminUser) {}
}

export class SaveCreatedUserSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveCreatedUserSuccess;
  public constructor() {}
}

export class SaveCreatedUserFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.SaveCreatedUserFailed;
  public constructor(public payload: any) {}
}

export class ClearCreateUserHttpErrorsAction implements Action {
  public readonly type = AdminUsersActionTypes.ClearCreateUserHttpErrors;
  public constructor() {}
}

export class ResetPasswordAction implements Action {
  public readonly type = AdminUsersActionTypes.ResetPassword;
  public constructor(public payload: { userId: string; email: string }) {}
}

export class ResetPasswordSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.ResetPasswordSuccess;
  public constructor() {}
}

export class ResetPasswordFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.ResetPasswordFailed;
  public constructor() {}
}

export class UnlockUserAction implements Action {
  public readonly type = AdminUsersActionTypes.UnlockUser;
  public constructor(public payload: { id: string; email: string }) {}
}

export class UnlockUserSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.UnlockUserSuccess;
  public constructor() {}
}

export class UnlockUserFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.UnlockUserFailed;
  public constructor() {}
}

export class CloseModalsAction implements Action {
  public readonly type = AdminUsersActionTypes.CloseModals;
  public constructor() {}
}

export class ExportToXLSXAction implements Action {
  public readonly type = AdminUsersActionTypes.ExportToXLSX;
  public constructor(public payload: string) {}
}

export class ExportToXLSXSuccessAction implements Action {
  public readonly type = AdminUsersActionTypes.ExportToXLSXSuccess;
  public constructor() {}
}

export class ExportToXLSXFailedAction implements Action {
  public readonly type = AdminUsersActionTypes.ExportToXLSXFailed;
  public constructor() {}
}

export type AdminUsersActionsUnion =
  | LoadUsersAction
  | LoadUsersSuccessAction
  | LoadUsersFailedAction
  | LoadJobFunctionsAction
  | LoadJobFunctionsSuccessAction
  | LoadJobFunctionsFailedAction
  | EditUserAction
  | SaveEditedUserAction
  | SaveEditedUserSuccessAction
  | SaveEditedUserFailedAction
  | CreateUserAction
  | SaveCreatedUserAction
  | SaveCreatedUserSuccessAction
  | SaveCreatedUserFailedAction
  | ClearCreateUserHttpErrorsAction
  | ResetPasswordAction
  | ResetPasswordSuccessAction
  | ResetPasswordFailedAction
  | UnlockUserAction
  | UnlockUserSuccessAction
  | UnlockUserFailedAction
  | ExportToXLSXAction
  | ExportToXLSXSuccessAction
  | ExportToXLSXFailedAction
  | CloseModalsAction;
