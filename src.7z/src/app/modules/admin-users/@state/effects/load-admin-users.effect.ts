import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { AdminUserModel } from '../../models/user.model';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import {
  AdminUsersActionTypes,
  LoadJobFunctionsAction,
  LoadJobFunctionsFailedAction,
  LoadJobFunctionsSuccessAction,
  LoadUsersAction,
  LoadUsersFailedAction,
  LoadUsersSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class LoadAdminUsersEffect {
  public constructor(
    private actions$: Actions,
    private adminUserService: AdminUsersHttpService,
    private kendoAdapterService: KendoAdapterService,
    private store$: Store
  ) {}
  // public loadAdminUsersEffect$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(AdminUsersActionTypes.LoadUsers),
  //     withLatestFrom(this.store$.pipe(select(getAdminUsersState))),
  //     switchMap(([action, state]: [LoadUsersAction, AdminUsersState]) => {
  //       const jobFunctions$ = state.data.jobFunctions.length
  //         ? of(state.data.jobFunctions)
  //         : this.adminUserService.getJobFunctions();

  //       return jobFunctions$.pipe(
  //         switchMap(jobFunctions =>
  //           this.kendoAdapterService
  //             .get<AdminUserModel>(API.adminUsers.getAll, action.payload.params, action.payload.filter)
  //             .pipe(
  //               map(users => new LoadUsersSuccessAction({ users, jobFunctions })),
  //               catchError(_err => of(new LoadUsersFailedAction()))
  //             )
  //         )
  //       );
  //     })
  //   )
  // );

  public loadAdminUsersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.LoadUsers),
      switchMap((action: LoadUsersAction) => {
        return this.kendoAdapterService
          .get<AdminUserModel>(API.adminUsers.getAll, action.payload.params, action.payload.filter)
          .pipe(
            map(users => new LoadUsersSuccessAction({ users })),
            catchError(_err => of(new LoadUsersFailedAction()))
          );
      })
    )
  );

  public loadJobFunctionsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.LoadJobFunctions),
      switchMap((action: LoadJobFunctionsAction) => {
        return this.adminUserService.getJobFunctions().pipe(
          map(data => new LoadJobFunctionsSuccessAction(data)),
          catchError(_err => of(new LoadJobFunctionsFailedAction()))
        );
      })
    )
  );
}
