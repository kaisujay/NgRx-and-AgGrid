import { Injectable } from '@angular/core';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import {
  AdminUsersActionTypes,
  ResetPasswordAction,
  ResetPasswordFailedAction,
  ResetPasswordSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class ResetPasswordEffect {
  public constructor(
    private actions$: Actions,
    private adminUserHttpService: AdminUsersHttpService,
    private credentialsService: CredentialsService
  ) {}
  public resetPasswordEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.ResetPassword),
      switchMap((action: ResetPasswordAction) =>
        this.adminUserHttpService.resetPassword(action.payload.userId).pipe(
          map(response => {
            this.credentialsService.set({
              password: response.password,
              email: action.payload.email
            });

            return new ResetPasswordSuccessAction();
          }),
          catchError(_err => of(new ResetPasswordFailedAction()))
        )
      )
    )
  );
}
