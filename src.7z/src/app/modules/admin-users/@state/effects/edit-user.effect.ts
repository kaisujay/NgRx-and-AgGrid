import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap } from 'rxjs';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import {
  AdminUsersActionTypes,
  SaveEditedUserAction,
  SaveEditedUserFailedAction,
  SaveEditedUserSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class EditUserEffect {
  public constructor(
    private actions$: Actions,
    private adminUserService: AdminUsersHttpService,
    private store$: Store
  ) {}
  public editUserEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.SaveEditedUser),
      switchMap((action: SaveEditedUserAction) => {
        return this.adminUserService.editUser(action.payload.id, action.payload.user).pipe(
          map(() => new SaveEditedUserSuccessAction()),
          catchError(() => of(new SaveEditedUserFailedAction()))
        );
      })
    )
  );
}
