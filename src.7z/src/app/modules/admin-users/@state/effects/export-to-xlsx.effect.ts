import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ExportToExcelService } from '../../services/export-to-excel.service';
import {
  AdminUsersActionTypes,
  ExportToXLSXAction,
  ExportToXLSXFailedAction,
  ExportToXLSXSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class ExportToXlsxEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private exportToExcelService: ExportToExcelService
  ) {}
  public exportToXlsxEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.ExportToXLSX),
      switchMap((action: ExportToXLSXAction) =>
        this.exportToExcelService.export(API.adminUsers.getAll, action.payload).pipe(
          map(_res => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Exported successfully');
    return new ExportToXLSXSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while Exporting');
    return of(new ExportToXLSXFailedAction());
  }
}
