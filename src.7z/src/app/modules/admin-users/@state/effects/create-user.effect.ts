import { Injectable } from '@angular/core';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap } from 'rxjs';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import {
  AdminUsersActionTypes,
  SaveCreatedUserAction,
  SaveCreatedUserFailedAction,
  SaveCreatedUserSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class CreateUserEffect {
  public constructor(
    private actions$: Actions,
    private adminUserService: AdminUsersHttpService,
    private store$: Store,
    private credentialsService: CredentialsService
  ) {}
  public createUserEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.SaveCreatedUser),
      switchMap((action: SaveCreatedUserAction) => {
        return this.adminUserService.createUser(action.payload).pipe(
          map(response => {
            this.credentialsService.set({
              password: response.Password,
              email: action.payload.Email
            });

            return new SaveCreatedUserSuccessAction();
          }),
          catchError(error => of(new SaveCreatedUserFailedAction(error)))
        );
      })
    )
  );
}
