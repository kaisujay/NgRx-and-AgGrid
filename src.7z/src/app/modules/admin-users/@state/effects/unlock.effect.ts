import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import {
  AdminUsersActionTypes,
  UnlockUserAction,
  UnlockUserFailedAction,
  UnlockUserSuccessAction
} from '../actions/admin-users.actions';

@Injectable()
export class UnlockEffect {
  public constructor(
    private actions$: Actions,
    private adminUserService: AdminUsersHttpService
  ) {}
  public unlockEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AdminUsersActionTypes.UnlockUser),
      switchMap((action: UnlockUserAction) =>
        this.adminUserService.unlock(action.payload.id).pipe(
          map(() => {
            return new UnlockUserSuccessAction();
          }),
          catchError(err => of(new UnlockUserFailedAction()))
        )
      )
    )
  );
}
