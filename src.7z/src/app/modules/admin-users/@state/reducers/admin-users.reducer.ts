import { createFeatureSelector } from '@ngrx/store';
import { JobFunction } from '../../models/admin-user.model';
import { AdminUserModel } from '../../models/user.model';
import { AdminUsersHttpService } from '../../services/admin-users-http.service';
import { AdminUsersActionsUnion, AdminUsersActionTypes } from '../actions/admin-users.actions';

export interface AdminUsersState {
  data: {
    users: {
      rowData: AdminUserModel[];
      rowCount: number;
    };
    // jobFunctions: JobFunction[];
    isLoadError: boolean;
  };
  jobFunctions: {
    jobFunctions: JobFunction[];
    isLoadError: boolean;
  };
  editUser: {
    isEditMode: boolean;
    editedUser: AdminUserModel;
    isResetPasswordModalVisible: boolean;
    isResettingPassword: boolean;
    isSaving: boolean;
    isUnlocking: boolean;
    isUnlockModalVisible: boolean;
  };
  createUser: {
    isCreateMode: boolean;
    isCreating: boolean;
    isPasswordModalVisible: boolean;
    errorMsg: string;
  };
  exportToXLSX: {
    isExporting: boolean;
  };
}

export const initialState: AdminUsersState = {
  data: {
    users: {
      rowData: [],
      rowCount: 0
    },
    // jobFunctions: [],
    isLoadError: false
  },
  jobFunctions: {
    jobFunctions: [],
    isLoadError: false
  },
  editUser: {
    isEditMode: false,
    isResettingPassword: false,
    editedUser: null,
    isResetPasswordModalVisible: false,
    isSaving: false,
    isUnlocking: false,
    isUnlockModalVisible: false
  },
  createUser: {
    isCreateMode: false,
    isPasswordModalVisible: false,
    isCreating: false,
    errorMsg: null
  },
  exportToXLSX: {
    isExporting: false
  }
};

export function adminUsersReducer(
  state: AdminUsersState = initialState,
  action: AdminUsersActionsUnion
): AdminUsersState {
  switch (action.type) {
    case AdminUsersActionTypes.LoadUsersSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          users: {
            ...action.payload.users
            // rowData: AdminUsersService.mapJobFunctions(action.payload.users.rowData, action.payload.jobFunctions)
          },
          // jobFunctions: action.payload.jobFunctions,
          isLoadError: false
        }
      };

    case AdminUsersActionTypes.LoadUsersFailed:
      return {
        ...state,
        data: {
          ...state.data,
          isLoadError: true
        }
      };

    case AdminUsersActionTypes.LoadJobFunctionsSuccess:
      return {
        ...state,
        jobFunctions: {
          jobFunctions: action.jobFunctions,
          isLoadError: false
        }
      };

    case AdminUsersActionTypes.LoadJobFunctionsFailed:
      return {
        ...state,
        jobFunctions: {
          ...state.jobFunctions,
          isLoadError: true
        }
      };

    case AdminUsersActionTypes.EditUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true,
          editedUser: action.payload.user
        }
      };

    case AdminUsersActionTypes.SaveEditedUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false,
          isSaving: true
        }
      };

    case AdminUsersActionTypes.SaveEditedUserSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isSaving: false
        }
      };

    case AdminUsersActionTypes.SaveEditedUserFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true,
          isSaving: false
        }
      };

    case AdminUsersActionTypes.CreateUser:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreateMode: true
        }
      };

    case AdminUsersActionTypes.SaveCreatedUser:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: true
        }
      };

    case AdminUsersActionTypes.SaveCreatedUserSuccess:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          isCreateMode: false,
          isPasswordModalVisible: true
        }
      };

    case AdminUsersActionTypes.SaveCreatedUserFailed:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          errorMsg: AdminUsersHttpService.parseCreateAdminUserError(action.payload)
        }
      };

    case AdminUsersActionTypes.ClearCreateUserHttpErrors:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          errorMsg: null
        }
      };

    case AdminUsersActionTypes.ResetPassword:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: true
        }
      };

    case AdminUsersActionTypes.ResetPasswordSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false,
          isEditMode: false,
          editedUser: null,
          isResetPasswordModalVisible: true
        }
      };

    case AdminUsersActionTypes.ResetPasswordFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false
        }
      };

    case AdminUsersActionTypes.UnlockUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isUnlocking: true
        }
      };

    case AdminUsersActionTypes.UnlockUserSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isUnlocking: false,
          isUnlockModalVisible: true
        }
      };

    case AdminUsersActionTypes.UnlockUserFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isUnlocking: true
        }
      };

    case AdminUsersActionTypes.ExportToXLSX:
      return {
        ...state,
        exportToXLSX: {
          isExporting: true
        }
      };

    case AdminUsersActionTypes.ExportToXLSXSuccess:
    case AdminUsersActionTypes.ExportToXLSXFailed:
      return {
        ...state,
        exportToXLSX: {
          isExporting: false
        }
      };

    case AdminUsersActionTypes.CloseModals:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          editedUser: null,
          isResetPasswordModalVisible: false,
          isUnlockModalVisible: false
        },
        createUser: {
          ...state.createUser,
          isCreateMode: false,
          isPasswordModalVisible: false
        }
      };

    default:
      return state;
  }
}

export const getAdminUsersState = createFeatureSelector<AdminUsersState>('adminUsers');
