import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AdminUsersHttpService } from './admin-users-http.service';
import { API } from '@core/constants/API';
import { AdminUser, CreateAdminUserResponse, JobFunction } from '../models/admin-user.model';
import { ModalOptions, ModalService } from '@ipreo/ngx-sprinkles';

export class MockModalSvc {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public create(_: ModalOptions): boolean {
    return true;
  }
}

describe('AdminUserService', () => {
  let service: AdminUsersHttpService;
  let httpMock: HttpTestingController;
  let _modalService: ModalService;

  const dummyUser: AdminUser = {
    FirstName: 'test',
    LastName: 'user',
    Email: 'testuser@example.com',
    Status: 'testpassword',
    Jobfunction: 'Admin'
  };

  const dummyResponse: CreateAdminUserResponse = {
    Password: 'dummyPwd'
  };
  const dummyJobFunctions: JobFunction[] = [
    { Code: 'Admin', CodeId: 1, SortOrder: 1, Desc: 'Admin 1' },
    { Code: 'Core', CodeId: 2, SortOrder: 2, Desc: 'Core 1' }
  ];
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AdminUsersHttpService,
        {
          provide: ModalService,
          useClass: MockModalSvc
        }
      ]
    });

    service = TestBed.inject(AdminUsersHttpService);
    _modalService = TestBed.inject(ModalService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should create a new admin user', () => {
    service.createUser(dummyUser).subscribe(response => {
      expect(response).toEqual(dummyResponse);
    });

    const req = httpMock.expectOne(API.adminUsers.post);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(dummyUser);
    req.flush(dummyResponse);
  });

  it('should fetch job functions successfully', () => {
    service.getJobFunctions().subscribe(jobFunctions => {
      expect(jobFunctions).toEqual(dummyJobFunctions);
    });
    const req = httpMock.expectOne(API.jobFunction);
    expect(req.request.method).toBe('GET');
    req.flush(dummyJobFunctions);
  });
});
