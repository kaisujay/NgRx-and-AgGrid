import { JobFunction } from '../models/admin-user.model';
import { AdminUserModel } from '../models/user.model';

export class AdminUsersService {
  public static mapJobFunctions(users: AdminUserModel[], jobFunctions: JobFunction[]): AdminUserModel[] {
    if (!jobFunctions || !jobFunctions.length) {
      return [];
    }

    return users.map(user => {
      return {
        ...user,
        JobFunction: jobFunctions.find(jobFunction => jobFunction.Code === user.JobFunction).Desc
      };
    });
  }

  public static getJobFunctionOptions(jobFunctions: JobFunction[]): { label: string; value: string }[] {
    if (!jobFunctions || !jobFunctions.length) {
      return [];
    }

    return jobFunctions.map(jobFunction => {
      return {
        label: jobFunction.Desc,
        value: jobFunction.Code
      };
    });
  }

  public static mapJobFunctionForUser(user: AdminUserModel, jobFunctions: JobFunction[]): AdminUserModel {
    if (!jobFunctions || !jobFunctions.length) {
      return user;
    }

    return {
      ...user,
      JobFunction: jobFunctions.find(jf => jf.Desc === user.JobFunction).Code
    };
  }
}
