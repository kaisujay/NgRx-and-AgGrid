import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import * as dayjs from 'dayjs';
import { saveAs } from 'file-saver';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as XLSX from 'xlsx';
import { ProductUser } from '../../product-users/models/product-users.model';

@Injectable()
export class ExportToExcelService {
  public constructor(
    private http: HttpClient,
    private kendoAdapterService: KendoAdapterService
  ) {}
  public export(url, filter): Observable<any> {
    return this.kendoAdapterService.getAll(url, filter).pipe(
      map(response => {
        response.rowData = response.rowData.map(user => {
          return {
            'First Name': user.FirstName,
            'Last Name': user.LastName,
            Email: user.Email,
            Status: user.Status,
            'Job Function': user.JobFunction,
            'Last Login Date': user.LastLoginDate ? dayjs(user.LastLoginDate).format() : '-',
            Locked: user.Lockout
          };
        });

        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(response.rowData);
        ws['!cols'] = [{ wch: 20 }, { wch: 20 }, { wch: 30 }, { wch: 10 }, { wch: 20 }, { wch: 25 }, { wch: 10 }];

        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

        const blob = new Blob([excelBuffer], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        saveAs(blob, `BuysideAdminUsers_${dayjs().format('YYYYMMDD_hhmm')}`);
      })
    );
  }

  public exportProudctUsers(url: string, filter: string): void {
    this.kendoAdapterService.getAll(url, filter).subscribe(response => {
      response.rowData = response.rowData.map((user: ProductUser) => {
        return {
          'First Name': user.FirstName,
          'Last Name': user.LastName,
          Email: user.Email,
          Status: user.Status,
          Containers: user.Containers,
          Companies: user.Companies,
          'Last Login': user.LastLoginDate ? dayjs(user.LastLoginDate).format() : '-',
          'Lock?': user.Lockout,
          'Is Container Admin?': user.IsContainerAdmin,
          'Is Orders Permissioned?': user.OrderInd
        };
      });

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(response.rowData);
      ws['!cols'] = [
        { wch: 25 },
        { wch: 25 },
        { wch: 30 },
        { wch: 10 },
        { wch: 25 },
        { wch: 25 },
        { wch: 25 },
        { wch: 10 },
        { wch: 25 },
        { wch: 25 }
      ];

      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

      const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

      const blob = new Blob([excelBuffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      saveAs(blob, `BuysideProductUsers_${dayjs().format('YYYYMMDD_hhmm')}`);
    });
  }
}
