import { HttpClient } from '@angular/common/http';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { saveAs } from 'file-saver';
import { of } from 'rxjs';
import { ExportToExcelService } from './export-to-excel.service';

describe('ExportToExcelService', () => {
  let httpSpy: jasmine.SpyObj<HttpClient>;
  let kendoAdapterService: jasmine.SpyObj<KendoAdapterService>;
  let exportToExcelServiceService: ExportToExcelService;

  beforeEach(() => {
    httpSpy = jasmine.createSpyObj('HttpClient', ['get']);
    kendoAdapterService = jasmine.createSpyObj('KendoAdapterService', ['getAll']);
    exportToExcelServiceService = new ExportToExcelService(httpSpy, kendoAdapterService);
  });

  it('should export data', () => {
    const mockResponse = {
      rowData: [
        {
          Email: 'MOCK-EMAIL',
          FirstName: 'MOCK-FIRST-NAME',
          Id: 'MOCK-ID',
          JobFunction: 'MOCK-JOB-FUNCTION',
          LastLoginDate: new Date(),
          LastName: 'MOCK-LAST-NAME',
          Lockout: null,
          RowVersion: 1,
          Status: 'MOCK-STATUS',
          UserName: 'MOCK-USER-NAME'
        }
      ],
      rowCount: 1
    };
    const mockUrl = 'MOCK-URL';
    const mockFilter = 'MOCK-FILTER';

    kendoAdapterService.getAll.and.returnValue(of(mockResponse));

    const saveAsSpy = spyOn(saveAs, 'saveAs');

    exportToExcelServiceService.export(mockUrl, mockFilter);

    expect(kendoAdapterService.getAll).toHaveBeenCalledWith(mockUrl, mockFilter);
    expect(saveAsSpy).toHaveBeenCalledOnceWith(jasmine.any(Blob), jasmine.stringContaining('BuysideAdminUsers_'));
  });
});
