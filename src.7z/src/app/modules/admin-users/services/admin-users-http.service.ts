import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminUser, CreateAdminUserResponse, JobFunction } from '../models/admin-user.model';
import { Observable } from 'rxjs';
import { API, buildApiString } from '@core/constants/API';
import { AdminUserModel } from '../models/user.model';

@Injectable()
export class AdminUsersHttpService {
  public constructor(private http: HttpClient) {}

  public createUser(userModel: AdminUser): Observable<CreateAdminUserResponse> {
    return this.http.post<CreateAdminUserResponse>(API.adminUsers.post, userModel);
  }

  public getJobFunctions(): Observable<JobFunction[]> {
    return this.http.get<JobFunction[]>(API.jobFunction);
  }

  public resetPassword(userId: string): Observable<{ password: string }> {
    return this.http.put<{ password: string }>(API.adminUsers.resetPassword, {
      UserId: userId
    });
  }

  public unlock(userId: string): Observable<void> {
    return this.http.post<void>(API.adminUsers.unlock, userId);
  }

  public editUser(id: string, user: Partial<AdminUserModel>): Observable<any> {
    const url = buildApiString(API.adminUsers.edit.put, {
      id
    });
    return this.http.put(url, user);
  }

  public static parseCreateAdminUserError(userError: HttpErrorResponse): string {
    if (userError.error.errors || userError.error.ModelState) {
      return AdminUsersHttpService.parseErrorMessages(userError.error.errors || userError.error.ModelState);
    }
    return 'Something went wrong';
  }

  public static parseErrorMessages(errors: { [k: string]: string[] }): string {
    const errorMessages: string[] = [];
    for (const key in errors) {
      errorMessages.push(...errors[key]);
    }
    return errorMessages.length ? errorMessages.join(' ') : 'Something went wrong';
  }
}
