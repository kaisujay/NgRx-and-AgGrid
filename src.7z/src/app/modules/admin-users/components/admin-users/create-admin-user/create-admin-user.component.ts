import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalService, SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import {
  ClearCreateUserHttpErrorsAction,
  CloseModalsAction,
  SaveCreatedUserAction
} from '@state/actions/admin-users.actions';
import { AdminUsersState, getAdminUsersState } from '@state/reducers/admin-users.reducer';
import { Observable } from 'rxjs';
import { JobFunction } from '../../../models/admin-user.model';
import { AdminUsersHttpService } from '../../../services/admin-users-http.service';
import { AdminUsersService } from '../../../services/admin-users.service';

@Component({
  selector: 'app-create-admin-user',
  templateUrl: './create-admin-user.component.html',
  styleUrls: ['./create-admin-user.component.scss']
})
export class CreateAdminUserComponent implements OnInit {
  @Input() public jobFunctions: JobFunction[];

  public adminUserState$: Observable<AdminUsersState>;
  public jobFunctionOptions: SelectOptions[];
  public createUserFormGroup: FormGroup;

  public constructor(
    private formBuilder: FormBuilder,
    private adminUserService: AdminUsersHttpService,
    private modalService: ModalService,
    private store$: Store
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.adminUserState$ = this.store$.pipe(select(getAdminUsersState));
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }

  public initForm() {
    this.createUserFormGroup = this.formBuilder.group({
      FirstName: new FormControl('', [Validators.required]),
      LastName: new FormControl('', [Validators.required]),
      JobFunction: new FormControl('', [Validators.required]),
      Email: new FormControl('', [Validators.required, Validators.email]),
      Status: new FormControl('Active')
    });

    this.jobFunctionOptions = AdminUsersService.getJobFunctionOptions(this.jobFunctions);
  }

  public onErrorModalClose(): void {
    this.store$.dispatch(new ClearCreateUserHttpErrorsAction());
  }

  public saveUser(): void {
    this.store$.dispatch(new SaveCreatedUserAction(this.createUserFormGroup.value));
  }

  public closeModal(): void {
    this.store$.dispatch(new CloseModalsAction());
  }
}
