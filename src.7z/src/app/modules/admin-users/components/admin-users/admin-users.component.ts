import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import {
  AdminUsersActionTypes,
  CreateUserAction,
  ExportToXLSXAction,
  LoadJobFunctionsAction,
  LoadUsersAction
} from '@state/actions/admin-users.actions';
import { AdminUsersState, getAdminUsersState } from '@state/reducers/admin-users.reducer';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { Observable, Subscription, debounceTime, filter, first, fromEvent, switchMap } from 'rxjs';
import { ADMIN_USER_GRID_OPTIONS } from '../../models/admin-user-grid-options.model';

@Component({
  selector: 'app-admin-users',
  templateUrl: './admin-users.component.html',
  styleUrls: ['./admin-users.component.scss']
})
export class AdminUsersComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;
  public gridOptions = ADMIN_USER_GRID_OPTIONS;
  public adminUsersState$: Observable<AdminUsersState>;

  private gridApi: GridApi;
  private subscriptions: Subscription[] = [];
  public defaultSortModel = {
    sort: 'asc',
    colId: 'Email'
  };

  public constructor(
    private store$: Store,
    private actions$: Actions,
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService
  ) {}

  public ngOnInit(): void {
    this.store$.dispatch(new LoadJobFunctionsAction());
    this.bindDateFormatFunction();
    this.adminUsersState$ = this.store$.pipe(select(getAdminUsersState));
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        const getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'LastLoginDate'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['LastLoginDate'], format);
        };
      })
    );
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;

    params.api.setServerSideDatasource({
      getRows: params => {
        if (params.request.sortModel.length === 0) {
          params.request.sortModel.push(this.defaultSortModel);
        }
        this.store$.dispatch(
          new LoadUsersAction({
            params: params.request,
            filter: this.filterTextBox.nativeElement.value
          })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(action => action.type === AdminUsersActionTypes.LoadUsersSuccess),
              switchMap(() => this.store$.select(getAdminUsersState)),
              first()
            )
            .subscribe(state => {
              params.success({
                rowData: state.data.users.rowData,
                rowCount: state.data.users.rowCount
              });
            })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(
                action =>
                  action.type === AdminUsersActionTypes.SaveCreatedUserSuccess ||
                  action.type === AdminUsersActionTypes.SaveEditedUserSuccess ||
                  action.type === AdminUsersActionTypes.ResetPasswordSuccess ||
                  action.type === AdminUsersActionTypes.UnlockUserSuccess
              ),
              first()
            )
            .subscribe(state => {
              this.gridApi.refreshServerSideStore({
                route: null,
                purge: false
              });
            })
        );
      }
    });
  }

  public onCreateAdmin(): void {
    this.store$.dispatch(new CreateUserAction());
  }

  public ngAfterViewInit(): void {
    this.subscriptions.push(
      fromEvent(this.filterTextBox.nativeElement, 'input')
        .pipe(debounceTime(500))
        .subscribe(() => {
          this.gridApi.refreshServerSideStore({ route: null, purge: false });
        })
    );
  }

  public export(): void {
    this.store$.dispatch(new ExportToXLSXAction(this.filterTextBox.nativeElement.value));
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
