import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import {
  CloseModalsAction,
  ResetPasswordAction,
  SaveEditedUserAction,
  UnlockUserAction
} from '@state/actions/admin-users.actions';
import { AdminUsersState, getAdminUsersState } from '@state/reducers/admin-users.reducer';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AdminUser, JobFunction } from '../../../models/admin-user.model';
import { AdminUserModel } from '../../../models/user.model';
import { AdminUsersService } from '../../../services/admin-users.service';

@Component({
  selector: 'app-edit-admin-user',
  templateUrl: './edit-admin-user.component.html',
  styleUrls: ['./edit-admin-user.component.scss']
})
export class EditAdminUserComponent implements OnInit {
  @Input() public user: AdminUserModel;
  @Input() public jobFunctions: JobFunction[];
  public isResetPasswordShown$: Observable<boolean>;
  public isUnlockModalVisible$: Observable<boolean>;
  public adminUserState$: Observable<AdminUsersState>;
  public editUserFormGroup: FormGroup;
  public jobFunctionOptions$: Observable<SelectOptions[]>;

  private editedUserInitialState: AdminUserModel;

  public constructor(
    private formBuilder: FormBuilder,
    private store$: Store
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.adminUserState$ = this.store$.pipe(select(getAdminUsersState));

    this.isResetPasswordShown$ = this.store$.pipe(
      select(getAdminUsersState),
      map(state => state.editUser.isResetPasswordModalVisible)
    );

    this.isUnlockModalVisible$ = this.store$.pipe(
      select(getAdminUsersState),
      map(state => state.editUser.isUnlockModalVisible)
    );

    this.jobFunctionOptions$ = this.store$.pipe(
      select(getAdminUsersState),
      map(state => {
        return AdminUsersService.getJobFunctionOptions(state.jobFunctions.jobFunctions);
      })
    );
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }

  public onResetPassword(userId: string, email: string): void {
    this.store$.dispatch(
      new ResetPasswordAction({
        userId,
        email
      })
    );
  }

  public onSave(): void {
    this.store$.dispatch(
      new SaveEditedUserAction({
        user: <Partial<AdminUser>>{
          ...this.editUserFormGroup.getRawValue(),
          RowVersion: this.editedUserInitialState.RowVersion
        },
        id: this.editedUserInitialState.Id
      })
    );
  }

  public isFormChanged(): boolean {
    const form = this.editUserFormGroup.getRawValue();
    return Object.keys(form).some(key => form[key] !== this.editedUserInitialState[key]);
  }

  public onUnlock(id: string, email: string): void {
    this.store$.dispatch(
      new UnlockUserAction({
        id,
        email
      })
    );
  }

  private initForm(): void {
    this.editUserFormGroup = this.formBuilder.group({
      FirstName: new FormControl(this.user.FirstName, [Validators.required]),
      LastName: new FormControl(this.user.LastName, [Validators.required]),
      JobFunction: new FormControl(this.user.JobFunction, [Validators.required]),
      Email: new FormControl(this.user.Email, [Validators.required, Validators.email]),
      Status: new FormControl(this.user.Status)
    });

    this.editedUserInitialState = { ...this.user };
  }
}
