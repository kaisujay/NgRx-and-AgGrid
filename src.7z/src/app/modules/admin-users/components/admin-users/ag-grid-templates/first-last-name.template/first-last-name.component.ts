import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { EditUserAction } from '@state/actions/admin-users.actions';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  template: '<span (click)="onEditUser()" class="c-text-primary c-cursor-pointer">{{params.value}}</span>'
})
export class FirstLastNameComponent implements ICellRendererAngularComp {
  public params: ICellRendererParams;

  public constructor(private store: Store) {}

  public refresh(params: ICellRendererParams): boolean {
    return false;
  }

  public agInit(params: ICellRendererParams): void {
    this.params = params;
  }

  public onEditUser(): void {
    this.store.dispatch(new EditUserAction({ user: this.params.data }));
  }
}
