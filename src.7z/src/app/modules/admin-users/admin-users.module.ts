import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { IconModule, ModalModule, SprCommonModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { AdminSharedModule } from '@shared/shared.module';
import { CreateUserEffect } from '@state/effects/create-user.effect';
import { EditUserEffect } from '@state/effects/edit-user.effect';
import { ExportToXlsxEffect } from '@state/effects/export-to-xlsx.effect';
import { LoadAdminUsersEffect } from '@state/effects/load-admin-users.effect';
import { LoginEffect } from '@state/effects/login.effect';
import { ResetPasswordEffect } from '@state/effects/reset-password.effect';
import { UnlockEffect } from '@state/effects/unlock.effect';
import { adminUsersReducer } from '@state/reducers/admin-users.reducer';
import { AgGridModule } from 'ag-grid-angular';
import { AdminUsersRoutingModule } from './admin-users-routing.module';
import { AdminUsersComponent } from './components/admin-users/admin-users.component';
import { CreateAdminUserComponent } from './components/admin-users/create-admin-user/create-admin-user.component';
import { EditAdminUserComponent } from './components/admin-users/edit-admin-user/edit-admin-user.component';
import { UserCreatedModalContentComponent } from './components/admin-users/user-created-modal-content/user-created-modal-content.component';
import { AdminUsersHttpService } from './services/admin-users-http.service';
import { ExportToExcelService } from './services/export-to-excel.service';

@NgModule({
  declarations: [
    AdminUsersComponent,
    CreateAdminUserComponent,
    EditAdminUserComponent,
    UserCreatedModalContentComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    AdminUsersRoutingModule,
    AgGridModule.withComponents([CheckboxRendererComponent]),
    SprCommonModule,
    SPRFormsModule,
    ModalModule,
    ReactiveFormsModule,
    IconModule,
    AdminSharedModule,
    StoreModule.forFeature('adminUsers', adminUsersReducer),
    EffectsModule.forFeature([
      LoginEffect,
      LoadAdminUsersEffect,
      ResetPasswordEffect,
      EditUserEffect,
      CreateUserEffect,
      ExportToXlsxEffect,
      UnlockEffect
    ])
  ],
  providers: [AdminUsersHttpService, ExportToExcelService]
})
export class AdminUsersModule {}
