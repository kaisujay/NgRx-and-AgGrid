import { SelectOptions } from '@ipreo/ngx-sprinkles';

export enum ReportingDownloadFileNames {
  IA_COMMUNITY_REPORT = 'community_report.csv',
  USERS_PERMISSIONS_REPORT = 'users-permissions.csv',
  COMPANY_PERMISSIONS_REPORT = 'company-permissions.csv',
  COMPANY_CONN_INIT_DATE_REPORT = 'connection-initial-date-report.csv',
  IA_ENABLED_DEAL_REPORT = 'ia-enabled-deal-report.csv'
}

export const reportOptions: SelectOptions[] = [
  {
    label: 'IA Community Report',
    value: 'IA_COMMUNITY_REPORT'
  },
  {
    label: 'Users Permissions Report',
    value: 'USERS_PERMISSIONS_REPORT'
  },
  {
    label: 'Company Permissions Report',
    value: 'COMPANY_PERMISSIONS_REPORT'
  },
  {
    label: 'Connection Initial Date Report',
    value: 'COMPANY_CONN_INIT_DATE_REPORT'
  },
  {
    label: 'IA Enabled Deals Report',
    value: 'IA_ENABLED_DEAL_REPORT'
  }
];

export interface ReportingResponse {
  buySideCompanies: ReportingBuysideCompany[];
  sellSideCompanies: ReportingSellsideCompany[];
}

export interface ReportingBuysideCompany {
  id: number;
  pmid: null;
  name: string;
  assetClass: string;
  isAttested: boolean;
  attestationModificationDateTime: Date;
  originalAttestationDate: Date;
  orderReadyDate: Date;
  country: string;
  isOrderReady: boolean;
  lei: string;
  orderReadyPercent: number;
  pendingPercent: number;
  connections: BuysideCompanyConnection[];
}

export interface BuysideCompanyConnection {
  sellSideCompanyId: number;
  status: ConnectionStatusType;
}

export interface ReportingSellsideCompany {
  iaReady: boolean;
  id: number;
  name: string;
  shortName: string;
}

export type ConnectionStatusType = 'Pending' | 'Connected' | 'NoRelationship' | 'NoOrder' | 'None';

export enum ConnectionStausMessages {
  'Pending' = 'Pending',
  'Connected' = 'Connected',
  'NoRelationship' = 'NoRelationship',
  'NoOrder' = 'No Order',
  'None' = 'N/A'
}
