import { createFeatureSelector } from '@ngrx/store';
import { ReportingActionTypes, ReportingActionsUnion } from '../actions/reporting.actions';

export interface ReportingState {
  isReportLoading: boolean;
  isReportLoadSuccess: boolean;
  isReportLoadError: boolean;
}

export const initReportState: ReportingState = {
  isReportLoading: false,
  isReportLoadSuccess: false,
  isReportLoadError: false
};

export function ReportingReducer(
  state: ReportingState = initReportState,
  action: ReportingActionsUnion
): ReportingState {
  switch (action.type) {
    case ReportingActionTypes.ReportDownload:
      return {
        ...state,
        isReportLoading: true
      };
    case ReportingActionTypes.ReportDownloadSuccess:
      return {
        ...state,
        isReportLoading: false,
        isReportLoadSuccess: true
      };
    case ReportingActionTypes.ReportDownloadFailure:
      return {
        ...state,
        isReportLoading: false,
        isReportLoadSuccess: false,
        isReportLoadError: true
      };
    default:
      return state;
  }
}

export const getReportingState = createFeatureSelector<ReportingState>('reporting');
