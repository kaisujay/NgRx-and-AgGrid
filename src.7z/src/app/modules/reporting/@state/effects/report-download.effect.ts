import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ReportingService } from '../../services/reporting.service';
import {
  ReportDownloadAction,
  ReportDownloadFailureAction,
  ReportDownloadSuccessAction,
  ReportingActionTypes
} from '../actions/reporting.actions';

@Injectable()
export class ReportDownloadEffect {
  public constructor(
    private actions$: Actions,
    private reportSvc: ReportingService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public reportDownloadEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ReportingActionTypes.ReportDownload),
      switchMap((_action: ReportDownloadAction) => {
        this.messageAlertSvc.showMessageAlert(
          CupcakeFlavors.Primary,
          'Please wait while Report is being downloaded',
          5000,
          false
        );
        return this.reportSvc.downloadReport(_action.downloadType).pipe(
          map(_ => {
            this.messageAlertSvc.dismissAlert();
            this.reportSvc.downloadFileContent(<string>_, _action.downloadType);
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Report downloaded successfully', 5000);
            return new ReportDownloadSuccessAction();
          }),
          catchError(error => {
            this.messageAlertSvc.dismissAlert();
            this.messageAlertSvc.showMessageAlert(
              CupcakeFlavors.Danger,
              'Error while downloading Report, please retry after a few minutes',
              5000
            );
            return of(new ReportDownloadFailureAction());
          })
        );
      })
    )
  );
}
