import { Action } from '@ngrx/store';

export enum ReportingActionTypes {
  ReportDownload = '[Reporting] Report Download ',
  ReportDownloadSuccess = '[Reporting] Report Download Success',
  ReportDownloadFailure = '[Reporting] Report Download Failure'
}

export class ReportDownloadAction implements Action {
  public readonly type = ReportingActionTypes.ReportDownload;
  public constructor(public downloadType: string) {}
}

export class ReportDownloadSuccessAction implements Action {
  public readonly type = ReportingActionTypes.ReportDownloadSuccess;
  public constructor() {}
}

export class ReportDownloadFailureAction implements Action {
  public readonly type = ReportingActionTypes.ReportDownloadFailure;
  public constructor() {}
}

export type ReportingActionsUnion = ReportDownloadAction | ReportDownloadSuccessAction | ReportDownloadFailureAction;
