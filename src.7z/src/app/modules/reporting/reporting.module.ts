import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule, LoaderModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ReportDownloadEffect } from './@state/effects/report-download.effect';
import { ReportingReducer } from './@state/reducers/reporting.reducer';
import { ReportingComponent } from './components/reporting.component';
import { ReportingRoutingModule } from './reporting-routing.module';
import { ReportingService } from './services/reporting.service';

@NgModule({
  declarations: [ReportingComponent],
  imports: [
    CommonModule,
    AdminSharedModule,
    SPRFormsModule,
    ButtonModule,
    FormsModule,
    LoaderModule,
    NgMultiSelectDropDownModule.forRoot(),
    ReportingRoutingModule,
    AgGridModule.withComponents([]),
    StoreModule.forFeature('reporting', ReportingReducer),
    EffectsModule.forFeature([ReportDownloadEffect])
  ],
  providers: [ReportingService]
})
export class ReportingModule {}
