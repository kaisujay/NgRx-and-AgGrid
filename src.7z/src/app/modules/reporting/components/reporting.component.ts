import { Component, OnInit } from '@angular/core';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ReportDownloadAction } from '../@state/actions/reporting.actions';
import { ReportingState, getReportingState } from '../@state/reducers/reporting.reducer';
import { reportOptions } from '../models/reporting-model';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.scss']
})
export class ReportingComponent implements OnInit {
  public reportOptions: SelectOptions[] = reportOptions;
  public reportingState$: Observable<ReportingState>;
  public dropdownFileName: string;
  public isDisableButton = true;

  public constructor(public store$: Store) {}

  public ngOnInit(): void {
    this.reportingState$ = this.store$.pipe(select(getReportingState));
  }

  public exportReport() {
    this.store$.dispatch(new ReportDownloadAction(this.dropdownFileName));
  }

  public onChangeValue(val) {
    if (val.length > 0) {
      this.isDisableButton = false;
    }
  }
}
