import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { saveAs } from 'file-saver';
import { Observable } from 'rxjs';
import {
  ConnectionStatusType,
  ConnectionStausMessages,
  ReportingDownloadFileNames,
  ReportingResponse
} from '../models/reporting-model';

@Injectable()
export class ReportingService {
  public constructor(
    private http: HttpClient,
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService
  ) {}

  public downloadReport(type: string): Observable<unknown> {
    const httpHeaders = new HttpHeaders();
    httpHeaders.set('Content-Type', 'text/csv');
    return this.http.get(API.reporting[type], { headers: httpHeaders, responseType: 'text' });
  }

  public downloadFileContent(content: string, fileType: string): void {
    if (fileType === 'IA_COMMUNITY_REPORT') {
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        saveAs(
          new Blob(['\uFEFF' + this.exportDataForDownload(JSON.parse(content), format)]),
          ReportingDownloadFileNames[fileType]
        );
      });
    } else {
      saveAs(new Blob([content]), ReportingDownloadFileNames[fileType]);
    }
  }

  private exportDataForDownload(content: ReportingResponse, format: DateTimeFormatDefined): string {
    const dataForExport = this.prepareIaCommunityDataForDownload(content, format);
    const headerList = Object.keys(dataForExport[0]);

    const headerRow = headerList.join(',') + '\r\n';
    const dataRows = dataForExport
      .map(data => {
        const line = headerList.map(header => `"${data[header]}"`);
        return line.join(',') + '\r\n';
      })
      .join('');

    return headerRow + dataRows;
  }
  private prepareIaCommunityDataForDownload(
    iaCommunityResponse: ReportingResponse,
    format: DateTimeFormatDefined
  ): any {
    const convertSellSideCompanies = iaCommunityResponse.sellSideCompanies.reduce((acc, sellsideCompany) => {
      acc[sellsideCompany.id] = { name: sellsideCompany.name };
      return acc;
    }, {});

    return iaCommunityResponse.buySideCompanies.map(buySideCompany => {
      let formattedBuysideCompany = {
        ID: buySideCompany.id,
        PMID: buySideCompany.pmid ? buySideCompany.pmid : '',
        LEI: buySideCompany.lei ? buySideCompany.lei : '',
        'Buyside Company Name': buySideCompany.name ? buySideCompany.name : '',
        'Asset Class': buySideCompany.assetClass ? buySideCompany.assetClass : '',
        'isAttested?': !!buySideCompany.isAttested,
        'Attestation Date': this.dateFormatSvc.format(<Date>buySideCompany.attestationModificationDateTime, format),
        'Original Attestation date': this.dateFormatSvc.format(<Date>buySideCompany.originalAttestationDate, format),
        Order: buySideCompany.isOrderReady,
        Country: buySideCompany.country,
        'Order Permissions Date': this.dateFormatSvc.format(<Date>buySideCompany.orderReadyDate, format),
        '% Order Ready': buySideCompany.orderReadyPercent,
        '% Pending': buySideCompany.pendingPercent
      };
      const connectionsMap = buySideCompany.connections.reduce((acc, connection) => {
        acc[`"${convertSellSideCompanies[connection.sellSideCompanyId].name}"`] = this.getStatusName(connection.status);
        return acc;
      }, {});
      formattedBuysideCompany = { ...formattedBuysideCompany, ...connectionsMap };
      return formattedBuysideCompany;
    });
  }

  public getStatusName(status: ConnectionStatusType): string {
    return status in ConnectionStausMessages ? ConnectionStausMessages[status] : '';
  }
}
