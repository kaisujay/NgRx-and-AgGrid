import { Action } from '@ngrx/store';
import { AccountSettingsModel } from 'src/app/modules/account-settings/models/update-account-settings.model';

export enum AccountSettingsActionTypes {
  UpdateAccountSettings = '[Account Settings] Update Account Settings',

  SaveUpdatedAccountSettings = '[Account Settings] Save Update Account Settings',
  SaveUpdatedAccountSettingsSuccess = '[Account Settings] Save Update Account Settings Success',
  SaveUpdatedAccountSettingsFailed = '[Account Settings] Save Update Account Settings Failed'
}

export class UpdateAccountSettingsAction implements Action {
  public readonly type = AccountSettingsActionTypes.UpdateAccountSettings;
  public constructor(public payload: AccountSettingsModel) {}
}

export class SaveUpdatedAccountSettingsActions implements Action {
  public readonly type = AccountSettingsActionTypes.SaveUpdatedAccountSettings;
  public constructor(public payload: AccountSettingsModel) {}
}

export class SaveUpdatedAccountSettingsSuccessActions implements Action {
  public readonly type = AccountSettingsActionTypes.SaveUpdatedAccountSettingsSuccess;
  public constructor() {}
}

export class SaveUpdatedAccountSettingsFailedActions implements Action {
  public readonly type = AccountSettingsActionTypes.SaveUpdatedAccountSettingsFailed;
  public constructor(public payload: AccountSettingsModel) {}
}

export type AccountSettingsActionsUnion =
  | UpdateAccountSettingsAction
  | SaveUpdatedAccountSettingsActions
  | SaveUpdatedAccountSettingsSuccessActions
  | SaveUpdatedAccountSettingsFailedActions;
