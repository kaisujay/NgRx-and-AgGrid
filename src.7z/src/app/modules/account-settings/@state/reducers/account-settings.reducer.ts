import { AccountSettingsActionTypes, AccountSettingsActionsUnion } from '../actions/account-settings.action';

import { createFeatureSelector } from '@ngrx/store';
import { AccountSettingsModel } from '../../models/update-account-settings.model';

export interface AccountSettingsState {
  updateAccountSetting: AccountSettingsModel;
  isLoading: boolean;
  isSaved: boolean;
}

export const initialState: AccountSettingsState = {
  updateAccountSetting: null,
  isLoading: false,
  isSaved: false
};

export function AccountSettingsReducer(
  state: AccountSettingsState = initialState,
  action: AccountSettingsActionsUnion
): AccountSettingsState {
  switch (action.type) {
    case AccountSettingsActionTypes.SaveUpdatedAccountSettings:
      return {
        ...state,
        updateAccountSetting: {
          ...state.updateAccountSetting
        },
        isLoading: true,
        isSaved: false
      };

    case AccountSettingsActionTypes.SaveUpdatedAccountSettingsSuccess:
      return {
        ...state,
        isLoading: false,
        isSaved: true
      };

    case AccountSettingsActionTypes.SaveUpdatedAccountSettingsFailed:
      return {
        ...state,
        isLoading: false,
        isSaved: false
      };

    default:
      return state;
  }
}

export const getAccountSettingState = createFeatureSelector<AccountSettingsState>('account-settings');
