import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { SettingsUpdatedAction } from '@state/actions/auth-api.actions';
import { Observable, catchError, map, of, switchMap } from 'rxjs';
import { AccountSettingsHttpService } from '../../services/account-settings-http.service';
import {
  AccountSettingsActionTypes,
  SaveUpdatedAccountSettingsActions,
  SaveUpdatedAccountSettingsFailedActions,
  SaveUpdatedAccountSettingsSuccessActions
} from '../actions/account-settings.action';

@Injectable()
export class LoadAccountSettingsEffect {
  public constructor(
    private actions$: Actions,
    private store: Store,
    private messageAlertSvc: MessageAlertService,
    private accountSettingsHttpService: AccountSettingsHttpService
  ) {}

  public accountSettingsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AccountSettingsActionTypes.UpdateAccountSettings),
      switchMap((action: SaveUpdatedAccountSettingsActions) => this.updateSetting(action.payload))
    )
  );

  public accountSettingsSaveEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AccountSettingsActionTypes.SaveUpdatedAccountSettings),
      switchMap((action: SaveUpdatedAccountSettingsActions) => this.updateSetting(action.payload))
    )
  );

  public updateSetting(payload): Observable<any> {
    return this.accountSettingsHttpService.updateAccountSettings(payload).pipe(
      map(context => {
        this.store.dispatch(new SettingsUpdatedAction(context));
        this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Account Settings saved successfully');
        return new SaveUpdatedAccountSettingsSuccessActions();
      }),
      catchError(err => {
        this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Account Settings');
        return of(new SaveUpdatedAccountSettingsFailedActions(err));
      })
    );
  }
}
