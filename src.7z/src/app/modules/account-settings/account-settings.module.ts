import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { LoadAccountSettingsEffect } from './@state/effects/account-settings.effect';
import { AccountSettingsReducer } from './@state/reducers/account-settings.reducer';

import { SprCommonModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '../../shared/shared.module';
import { AccountSettingsRoutingModule } from './account-settings-routing.module';
import { AccountSettingsComponent } from './components/account-settings/account-settings.component';
import { AccountSettingsDataService } from './services/account-settings-data.service';
import { AccountSettingsHttpService } from './services/account-settings-http.service';

@NgModule({
  declarations: [AccountSettingsComponent],
  providers: [AccountSettingsHttpService, AccountSettingsDataService, DatePipe],
  exports: [AccountSettingsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    SprCommonModule,
    SPRFormsModule,
    AccountSettingsRoutingModule,
    StoreModule.forFeature('account-settings', AccountSettingsReducer),
    EffectsModule.forFeature([LoadAccountSettingsEffect]),
    AdminSharedModule
  ]
})
export class AccountSettingsModule {}
