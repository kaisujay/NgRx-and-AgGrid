import { DatePipe } from '@angular/common';
import { Component, DoCheck, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { userContext } from '@state/reducers';
import { Subscription } from 'rxjs';
import { UserSessionContext } from '../../../../modules/login/models/login.model';
import { SaveUpdatedAccountSettingsActions } from '../../@state/actions/account-settings.action';
import { AccountSettingsState, getAccountSettingState } from '../../@state/reducers/account-settings.reducer';
import { accountSettingsDatas } from '../../datas/account-settings.data';
import {
  AccountSettingsModel,
  AccountSettingsWithDateModel,
  CheckAccountSettingsModel
} from '../../models/update-account-settings.model';
import { AccountSettingsDataService } from '../../services/account-settings-data.service';
import { AccountSettingsService } from '../../services/account-settings.service';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.component.html',
  styleUrls: ['./account-settings.component.scss']
})
export class AccountSettingsComponent implements OnInit, DoCheck, OnDestroy {
  public languageOption: SelectOptions[];
  public numberFormatOption: SelectOptions[];
  public dateFormatOption: SelectOptions[];
  public timeFormatOption: SelectOptions[];
  public timeZoneOption: SelectOptions[];

  public accountSettingFormGroupValues: FormGroup;
  public currentDate = new Date();
  public dateFormat: string;
  public numberFormat: string;
  public numberExample: string;
  public receivedAccountSettingsValuesFormDB: AccountSettingsModel;
  public updateFormDatas: AccountSettingsModel;
  public checkAccountSettingsModel: CheckAccountSettingsModel;
  public accountSettingsWithDateModel: AccountSettingsWithDateModel;
  public shouldEnabledButtons: boolean;
  public userSessionContext: UserSessionContext;
  public accountSettingState: AccountSettingsState;

  private userContextSubscription: Subscription;
  private accountSettingSubscription: Subscription;

  public constructor(
    private formBuilder: FormBuilder,
    private store$: Store,
    private dataService: AccountSettingsDataService,
    private datePipe: DatePipe
  ) {}

  public ngOnDestroy(): void {
    if (this.userContextSubscription) {
      this.userContextSubscription.unsubscribe();
    }
    if (this.accountSettingSubscription) {
      this.accountSettingSubscription.unsubscribe();
    }
  }

  public ngOnInit(): void {
    this.userContextSubscription = this.store$.pipe(select(userContext)).subscribe(context => {
      this.userSessionContext = context;
    });

    this.receivedAccountSettingsValuesFormDB = {
      Language: this.userSessionContext.Language,
      Currency: this.userSessionContext.Currency,
      NumberFormat: this.userSessionContext.NumberFormat,
      DateFormat: this.userSessionContext.DateFormat,
      TimeFormat: this.userSessionContext.TimeFormat,
      Timezone: this.userSessionContext.Timezone
    };

    this.accountSettingSubscription = this.store$.pipe(select(getAccountSettingState)).subscribe(context => {
      this.accountSettingState = context;
    });

    this.initForm();

    this.setOptionValues();
    this.checkAccountSettingsModel = JSON.parse(JSON.stringify(this.accountSettingFormGroupValues.value));
  }

  public ngDoCheck(): void {
    if (JSON.stringify(this.checkAccountSettingsModel) === JSON.stringify(this.accountSettingFormGroupValues.value)) {
      this.shouldEnabledButtons = false;
    } else {
      this.shouldEnabledButtons = true;
    }
  }

  public initForm() {
    if (this.dataService.accountData != null) {
      this.accountSettingFormGroupValues = this.formBuilder.group({
        Language: new FormControl(this.dataService.accountData.Language, [Validators.required]),
        NumberFormat: new FormControl(this.dataService.accountData.NumberFormat, [Validators.required]),
        DateFormat: new FormControl(this.dataService.accountData.DateFormat, [Validators.required]),
        TimeFormat: new FormControl(this.dataService.accountData.TimeFormat, [Validators.required]),
        Timezone: new FormControl(this.dataService.accountData.Timezone, [Validators.required])
      });

      const dateFormatVal = this.dataService.accountData.Date;
      this.dateFormat = this.datePipe.transform(this.currentDate, dateFormatVal);

      const numberFormatVal = this.dataService.accountData.Number;
      this.setNumberExample(numberFormatVal);
    } else {
      this.accountSettingFormGroupValues = this.formBuilder.group({
        Language: new FormControl(this.receivedAccountSettingsValuesFormDB.Language, [Validators.required]),
        NumberFormat: new FormControl(this.receivedAccountSettingsValuesFormDB.NumberFormat, [Validators.required]),
        DateFormat: new FormControl(this.receivedAccountSettingsValuesFormDB.DateFormat, [Validators.required]),
        TimeFormat: new FormControl(this.receivedAccountSettingsValuesFormDB.TimeFormat, [Validators.required]),
        Timezone: new FormControl(this.receivedAccountSettingsValuesFormDB.Timezone, [Validators.required])
      });

      const dateFormatVal = accountSettingsDatas.DateFormat.filter(
        date => date.DateFormatId === this.receivedAccountSettingsValuesFormDB.DateFormat
      ).find(Id => Id).Format;

      this.dateFormat = this.datePipe.transform(this.currentDate, dateFormatVal);

      const numberFormatVal = accountSettingsDatas.NumberFormat.filter(
        number => number.NumberFormatId === this.receivedAccountSettingsValuesFormDB.NumberFormat
      ).find(Id => Id).NumberFormatId;

      this.setNumberExample(numberFormatVal);
    }
  }

  public setNumberExample(value: string) {
    if (value === 'Format1') {
      this.numberExample = '1 234 567,12';
    } else if (value === 'Format2') {
      this.numberExample = '1234567,12';
    } else {
      this.numberExample = '1,234,567.12';
    }
  }

  public cancelForm() {
    if (this.dataService.accountData == null) {
      this.accountSettingFormGroupValues.setValue({
        Language: [this.receivedAccountSettingsValuesFormDB.Language, Validators.required],
        NumberFormat: [this.receivedAccountSettingsValuesFormDB.NumberFormat, Validators.required],
        DateFormat: [this.receivedAccountSettingsValuesFormDB.DateFormat, Validators.required],
        TimeFormat: [this.receivedAccountSettingsValuesFormDB.TimeFormat, Validators.required],
        Timezone: [this.receivedAccountSettingsValuesFormDB.Timezone, Validators.required]
      });
    } else {
      this.accountSettingFormGroupValues.setValue({
        Language: [this.dataService.accountData.Language, Validators.required],
        NumberFormat: [this.dataService.accountData.NumberFormat, Validators.required],
        DateFormat: [this.dataService.accountData.DateFormat, Validators.required],
        TimeFormat: [this.dataService.accountData.TimeFormat, Validators.required],
        Timezone: [this.dataService.accountData.Timezone, Validators.required]
      });
    }
  }

  public setOptionValues() {
    this.languageOption = AccountSettingsService.getOptions(accountSettingsDatas.Language, 'Name', 'LanguageId');
    this.numberFormatOption = AccountSettingsService.getOptions(
      accountSettingsDatas.NumberFormat,
      'Name',
      'NumberFormatId'
    );
    this.dateFormatOption = AccountSettingsService.getOptions(
      accountSettingsDatas.DateFormat,
      'Example',
      'DateFormatId'
    );
    this.timeFormatOption = AccountSettingsService.getOptions(
      accountSettingsDatas.TimeFormat,
      'Example',
      'TimeFormatId'
    );
    this.timeZoneOption = AccountSettingsService.getOptions(accountSettingsDatas.Timezone, 'label', 'tzCode');
  }

  public saveAccountSettings() {
    this.getAndSetValuesForSaveAccountSettings();
    this.store$.dispatch(new SaveUpdatedAccountSettingsActions(this.updateFormDatas));
    this.dataService.accountData = this.accountSettingsWithDateModel;
  }

  public getAndSetValuesForSaveAccountSettings() {
    const formData = this.accountSettingFormGroupValues.value;

    const Language = accountSettingsDatas.Language.filter(language => language.LanguageId === formData.Language).find(
      Id => Id
    ).LanguageId;

    const Currency = 'EUR';

    const NumberFormat = accountSettingsDatas.NumberFormat.filter(
      numberFormat => numberFormat.NumberFormatId === formData.NumberFormat
    ).find(Id => Id).NumberFormatId;

    const DateFormat = accountSettingsDatas.DateFormat.filter(
      dateFormat => dateFormat.DateFormatId === formData.DateFormat
    ).find(Id => Id).DateFormatId;

    const TimeFormat = accountSettingsDatas.TimeFormat.filter(
      timeFormat => timeFormat.TimeFormatId === formData.TimeFormat
    ).find(Id => Id).TimeFormatId;

    const Timezone = accountSettingsDatas.Timezone.filter(
      timezone => timezone.label === formData.Timezone || timezone.tzCode === formData.Timezone
    ).find(tzCode => tzCode).tzCode;

    const date = accountSettingsDatas.DateFormat.filter(
      dateFormat => dateFormat.DateFormatId === formData.DateFormat
    ).find(Id => Id).Format;

    const number = accountSettingsDatas.NumberFormat.filter(
      numberFormat => numberFormat.NumberFormatId === formData.NumberFormat
    ).find(Id => Id).NumberFormatId;

    this.updateFormDatas = {
      Language: Language,
      Currency: Currency,
      NumberFormat: NumberFormat,
      DateFormat: DateFormat,
      TimeFormat: TimeFormat,
      Timezone: Timezone
    };

    this.checkAccountSettingsModel = {
      Language: Language,
      NumberFormat: NumberFormat,
      DateFormat: DateFormat,
      TimeFormat: TimeFormat,
      Timezone: Timezone
    };

    this.accountSettingsWithDateModel = {
      Language: Language,
      NumberFormat: NumberFormat,
      DateFormat: DateFormat,
      Date: date,
      Number: number,
      TimeFormat: TimeFormat,
      Timezone: Timezone
    };
  }
}
