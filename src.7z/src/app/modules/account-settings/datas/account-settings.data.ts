import timezones from 'timezones-list';
import { AccountSettings } from '../models/account-settings.model';

export let accountSettingsDatas: AccountSettings = {
  Language: [
    {
      LanguageId: 'EnUS',
      Name: 'English (American)'
    }
  ],

  Currency: [
    {
      CurrencyId: 'EUR',
      Name: 'EUR'
    }
  ],

  NumberFormat: [
    {
      NumberFormatId: 'Format0',
      Name: '1,000,000.99'
    },
    {
      NumberFormatId: 'Format1',
      Name: '1\u00a0000\u00a0000,99'
    },
    {
      NumberFormatId: 'Format2',
      Name: '100000000,99'
    }
  ],

  DateFormat: [
    {
      DateFormatId: 'Format0',
      Example: '10 Jan 15',
      Format: 'dd MMM yy'
    },
    {
      DateFormatId: 'Format1',
      Example: '10 Jan 2015',
      Format: 'dd MMM yyyy'
    },
    {
      DateFormatId: 'Format2',
      Example: '10 January 2015',
      Format: 'dd MMMM yyyy'
    },
    {
      DateFormatId: 'Format3',
      Example: '01/10/15',
      Format: 'MM/dd/yy'
    },
    {
      DateFormatId: 'Format4',
      Example: '10/01/15',
      Format: 'dd/MM/yy'
    },
    {
      DateFormatId: 'Format5',
      Example: '10.01.15',
      Format: 'dd.MM.yy'
    },
    {
      DateFormatId: 'Format6',
      Example: '01/10/2015',
      Format: 'MM/dd/yyyy'
    },
    {
      DateFormatId: 'Format7',
      Example: '10/01/2015',
      Format: 'dd/MM/yyyy'
    },
    {
      DateFormatId: 'Format8',
      Example: '10.01.2015',
      Format: 'dd.MM.yyyy'
    }
  ],

  TimeFormat: [
    {
      TimeFormatId: 'Format0',
      Example: '18:00',
      Format: 'HH:mm'
    },
    {
      TimeFormatId: 'Format1',
      Example: '12:00 PM',
      Format: 'hh:mm a'
    },
    {
      TimeFormatId: 'Format2',
      Example: '18:00:00',
      Format: 'HH:mm:ss'
    },
    {
      TimeFormatId: 'Format3',
      Example: '12:00:00 PM',
      Format: 'hh:mm:ss a'
    }
  ],

  Timezone: timezones.sort((a, b) => {
    if (a.tzCode < b.tzCode) {
      return -1;
    } else {
      return 1;
    }
  })
};
