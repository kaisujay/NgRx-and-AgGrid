import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { UserSessionContext } from '../../login/models/login.model';
import { AccountSettingsModel } from '../models/update-account-settings.model';

@Injectable()
export class AccountSettingsHttpService {
  public constructor(private http: HttpClient) {}

  public updateAccountSettings(accountSetting: AccountSettingsModel): Observable<UserSessionContext> {
    return this.http.put<UserSessionContext>(API.accountSettings.put, accountSetting);
  }
}
