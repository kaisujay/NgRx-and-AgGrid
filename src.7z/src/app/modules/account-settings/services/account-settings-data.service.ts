import { Injectable } from '@angular/core';
import { AccountSettingsWithDateModel } from '../models/update-account-settings.model';

@Injectable()
export class AccountSettingsDataService {
  public accountData: AccountSettingsWithDateModel;

  public dataService(data: AccountSettingsWithDateModel) {
    this.accountData = data;
  }
}
