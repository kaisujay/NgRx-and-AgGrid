export interface AccountSettingsWithDateModel extends CheckAccountSettingsModel {
  Date: string;
  Number: string;
}

export interface AccountSettingsModel extends CheckAccountSettingsModel {
  Currency: string;
}

export interface CheckAccountSettingsModel {
  Language: string;
  NumberFormat: string;
  DateFormat: string;
  TimeFormat: string;
  Timezone: string;
}
