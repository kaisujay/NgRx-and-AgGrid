export interface AccountSettings {
  Language: Language[];
  Currency: Currency[];
  NumberFormat: NumberFormat[];
  DateFormat: DateFormat[];
  TimeFormat: TimeFormat[];
  Timezone: Timezone[];
}

export interface Language {
  LanguageId: string;
  Name: string;
}

export interface Currency {
  CurrencyId: string;
  Name: string;
}

export interface NumberFormat {
  NumberFormatId: string;
  Name: string;
}

export interface DateFormat {
  DateFormatId: string;
  Example: string;
  Format: string;
}

export interface TimeFormat {
  TimeFormatId: string;
  Example: string;
  Format: string;
}

export interface Timezone {
  label: string;
  name: string;
  tzCode: string;
  utc: string;
}
