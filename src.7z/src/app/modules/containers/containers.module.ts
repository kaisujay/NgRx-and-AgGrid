import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { SPRFormsModule, SprCommonModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { AddContainerEffect } from './@state/effects/add-container.effect';
import { LoadContainerStatusesEffect } from './@state/effects/load-container-statuses.effect';
import { LoadContainersEffect } from './@state/effects/load-containers.effect';
import { containersReducer } from './@state/reducers/containers.reducer';
import { AddContainerComponent } from './components/add-container/add-container.component';
import { ContainersComponent } from './components/containers.component';
import { ContainersRoutingModule } from './containers-routing.module';
import { ContainersHttpService } from './services/containers-http.service';

@NgModule({
  declarations: [ContainersComponent, AddContainerComponent],
  imports: [
    CommonModule,
    CoreModule,
    ContainersRoutingModule,
    AgGridModule.withComponents([CheckboxRendererComponent]),
    StoreModule.forFeature('containers', containersReducer),
    EffectsModule.forFeature([LoadContainersEffect, LoadContainerStatusesEffect, AddContainerEffect]),
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    SprCommonModule,
    SPRFormsModule
  ],
  providers: [ContainersHttpService]
})
export class ContainersModule {}
