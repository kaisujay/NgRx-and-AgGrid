export interface Container {
  CreatedBy: string;
  CreationDate: Date;
  Id: string;
  IsTestContainer: boolean;
  LastModifiedBy: string;
  LastModifiedDate: Date;
  Name: string;
  RowVersion: number;
  Status: string;
}
