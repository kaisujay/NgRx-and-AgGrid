export interface ContainerStatus {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}
