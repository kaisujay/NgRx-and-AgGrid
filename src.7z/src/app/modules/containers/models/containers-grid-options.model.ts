import { isNullOrUndefined } from '@core/utils/util';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { CustomLoadingCellRendererComponent } from '@shared/components/loading-cell-renderer/loading-cell-renderer.component';
import { GridOptions } from 'ag-grid-community';
import { NameComponent } from '../components/ag-grid-templates/name.template/name.component';

export const CONTAINERS_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'Name',
      field: 'Name',
      minWidth: 310,
      suppressColumnsToolPanel: true,
      cellRendererFramework: NameComponent,
      comparator: (valueA: string, valueB: string) => valueA?.localeCompare(valueB)
    },
    {
      headerName: 'Status',
      field: 'Status',
      comparator: (valueA: string, valueB: string) => valueA?.localeCompare(valueB)
    },
    {
      headerName: 'Test',
      field: 'IsTestContainer',
      cellRenderer: 'checkboxRenderer'
    },
    {
      headerName: 'Last Modified By',
      field: 'LastModifiedBy',
      comparator: (valueA: string, valueB: string) => valueA?.localeCompare(valueB)
    },
    {
      headerName: 'Last Modified Date',
      field: 'LastModifiedDate',
      comparator: (date1, date2) => {
        if (date1.includes('LMT')) {
          date1 = date1.replace('LMT', 'EDT');
        }

        const date1Number = date1 && new Date(date1).getTime();
        const date2Number = date2 && new Date(date2).getTime();

        if (Number.isNaN(date1Number)) {
          return 0;
        }

        if (isNullOrUndefined(date1Number) && isNullOrUndefined(date2Number)) {
          return 0;
        }

        if (isNullOrUndefined(date1Number)) {
          return -1;
        } else if (isNullOrUndefined(date2Number)) {
          return 1;
        }

        return date1Number - date2Number;
      }
    },
    {
      headerName: 'Created By',
      field: 'CreatedBy',
      comparator: (valueA: string, valueB: string) => valueA?.localeCompare(valueB)
    },
    {
      headerName: 'Creation Date',
      field: 'CreationDate',
      comparator: (date1, date2) => {
        if (date1.includes('LMT')) {
          date1 = date1.replace('LMT', 'EDT');
        }

        const date1Number = date1 && new Date(date1).getTime();
        const date2Number = date2 && new Date(date2).getTime();

        if (isNullOrUndefined(date1Number) && isNullOrUndefined(date2Number)) {
          return 0;
        }

        if (isNullOrUndefined(date1Number)) {
          return -1;
        } else if (isNullOrUndefined(date2Number)) {
          return 1;
        }

        return date1Number - date2Number;
      }
    }
  ],
  defaultColDef: {
    flex: 1,
    minWidth: 90,
    resizable: true,
    sortable: true
  },
  frameworkComponents: {
    checkboxRenderer: CheckboxRendererComponent
  },
  pagination: true,
  paginationPageSize: 50,
  cacheBlockSize: 50,
  tooltipShowDelay: 1000,
  animateRows: false,
  loadingCellRendererFramework: CustomLoadingCellRendererComponent,
  suppressRowClickSelection: true,
  overlayNoRowsTemplate: 'No records to dispaly',
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressNoRowsOverlay: false,
  suppressLoadingOverlay: false,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true,
  suppressHorizontalScroll: false
};
