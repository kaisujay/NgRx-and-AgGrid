export interface NewContainer {
  Name: string;
  Status: string;
  IsTestContainer: string;
}
