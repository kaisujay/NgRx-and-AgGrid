import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Container } from '../models/container';
import { ContainerStatus } from '../models/container.status';

export class ContainersService {
  public static getStatusOptions(statuses: ContainerStatus[]): SelectOptions[] {
    return statuses.map(status => ({
      value: status.Code,
      label: status.Desc
    }));
  }

  public static searchContainers(containers: Container[], filter: string): Container[] {
    return filter !== ''
      ? containers.filter(container => {
          const searchInProp = (prop: string) =>
            container[prop] && container[prop].toString().toLowerCase().includes(filter.toLowerCase());

          return (
            searchInProp('Name') ||
            searchInProp('Status') ||
            searchInProp('CreatedBy') ||
            searchInProp('CreationDate') ||
            searchInProp('LastModifiedBy') ||
            searchInProp('LastModifiedDate')
          );
        })
      : containers;
  }
}
