import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import { Container } from '../models/container';
import { ContainerStatus } from '../models/container.status';
import { NewContainer } from '../models/new-container.model';

@Injectable()
export class ContainersHttpService {
  public constructor(private http: HttpClient) {}

  public getContainers(): Observable<Container[]> {
    return this.http.get<Container[]>(API.containers.getAll);
  }

  public addContainer(container: NewContainer): Observable<void> {
    return this.http.post<void>(API.containers.getAll, container);
  }

  public getContainerStatuses(): Observable<ContainerStatus[]> {
    return this.http.get<ContainerStatus[]>(API.containers.statuses);
  }
}
