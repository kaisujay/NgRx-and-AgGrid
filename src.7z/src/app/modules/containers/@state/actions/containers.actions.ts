import { Action } from '@ngrx/store';
import { Container } from '../../models/container';
import { ContainerStatus } from '../../models/container.status';
import { NewContainer } from '../../models/new-container.model';

export enum ContainersActionTypes {
  Load = '[Containers] Load',
  LoadSuccess = '[Containers] Load Success',
  LoadFailed = '[Containers] Load Failed',

  AddContainerModalOpen = '[Containers] Add Container Modal Open',
  AddContainerModalOpenSuccess = '[Containers] Add Container Modal Open Success',
  AddContainerModalOpenFailed = '[Containers] Add Container Modal Open Failed',

  AddContainer = '[Containers] Add Container',
  AddContainerSuccess = '[Containers] Add Container Success',
  AddContainerFailed = '[Containers] Add Container Failed',

  CloseModals = '[Containers] Close Modals'
}

export class LoadAction implements Action {
  public readonly type = ContainersActionTypes.Load;
  public constructor() {}
}

export class LoadSuccessAction implements Action {
  public readonly type = ContainersActionTypes.LoadSuccess;
  public constructor(public payload: { containers: Container[] }) {}
}

export class LoadFailedAction implements Action {
  public readonly type = ContainersActionTypes.LoadFailed;
  public constructor() {}
}

export class AddContainerModalOpenActions implements Action {
  public readonly type = ContainersActionTypes.AddContainerModalOpen;
  public constructor() {}
}

export class AddContainerModalOpenSuccessActions implements Action {
  public readonly type = ContainersActionTypes.AddContainerModalOpenSuccess;
  public constructor(public payload: { statuses: ContainerStatus[] }) {}
}

export class AddContainerModalOpenFailedActions implements Action {
  public readonly type = ContainersActionTypes.AddContainerModalOpenFailed;
  public constructor() {}
}

export class AddContainerActions implements Action {
  public readonly type = ContainersActionTypes.AddContainer;
  public constructor(public payload: NewContainer) {}
}

export class AddContainerSuccessActions implements Action {
  public readonly type = ContainersActionTypes.AddContainerSuccess;
  public constructor() {}
}

export class AddContainerFailedActions implements Action {
  public readonly type = ContainersActionTypes.AddContainerFailed;
  public constructor() {}
}

export class CloseModalsAction implements Action {
  public readonly type = ContainersActionTypes.CloseModals;
  public constructor() {}
}

export type ContainersActionsUnion =
  | LoadAction
  | LoadSuccessAction
  | LoadFailedAction
  | AddContainerActions
  | AddContainerSuccessActions
  | AddContainerFailedActions
  | AddContainerModalOpenActions
  | AddContainerModalOpenSuccessActions
  | AddContainerModalOpenFailedActions
  | CloseModalsAction;
