import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainersHttpService } from '../../services/containers-http.service';
import {
  AddContainerModalOpenFailedActions,
  AddContainerModalOpenSuccessActions,
  ContainersActionTypes,
  LoadAction
} from '../actions/containers.actions';

@Injectable()
export class LoadContainerStatusesEffect {
  public constructor(
    private actions$: Actions,
    private containersHttpService: ContainersHttpService
  ) {}
  public loadContainerStatuses = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainersActionTypes.AddContainerModalOpen),
      switchMap((_action: LoadAction) => {
        return this.containersHttpService.getContainerStatuses().pipe(
          map(response => new AddContainerModalOpenSuccessActions({ statuses: response })),
          catchError(_err => of(new AddContainerModalOpenFailedActions()))
        );
      })
    )
  );
}
