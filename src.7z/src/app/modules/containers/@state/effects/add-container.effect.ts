import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainersHttpService } from '../../services/containers-http.service';
import {
  AddContainerActions,
  AddContainerFailedActions,
  ContainersActionTypes,
  LoadAction
} from '../actions/containers.actions';

@Injectable()
export class AddContainerEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private containersHttpService: ContainersHttpService
  ) {}
  public addContainerEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainersActionTypes.AddContainer),
      switchMap((action: AddContainerActions) => {
        return this.containersHttpService.addContainer(action.payload).pipe(
          map(_res => this.handleSuccess()),
          catchError(_err => this.handleError())
        );
      })
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Container saved successfully');
    return new LoadAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Container');
    return of(new AddContainerFailedActions());
  }
}
