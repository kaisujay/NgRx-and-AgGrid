import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainersHttpService } from '../../services/containers-http.service';
import { ContainersActionTypes, LoadAction, LoadFailedAction, LoadSuccessAction } from '../actions/containers.actions';

@Injectable()
export class LoadContainersEffect {
  public constructor(
    private actions$: Actions,
    private containersHttpService: ContainersHttpService
  ) {}
  public loadContainersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainersActionTypes.Load),
      switchMap((_action: LoadAction) => {
        return this.containersHttpService.getContainers().pipe(
          map(response => new LoadSuccessAction({ containers: response })),
          catchError(_err => of(new LoadFailedAction()))
        );
      })
    )
  );
}
