import { createFeatureSelector } from '@ngrx/store';
import { Container } from '../../models/container';
import { ContainerStatus } from '../../models/container.status';
import { ContainersActionsUnion, ContainersActionTypes } from '../actions/containers.actions';

export interface ContainersState {
  data: {
    containers: Container[];
    statuses: ContainerStatus[];
  };
  isAddContainerMode: boolean;
  isAddingContainer: boolean;
  isLoadingStatuses: boolean;
  isLoadError: boolean;
  isModalOpenError: boolean;
}

export const initialState: ContainersState = {
  data: {
    containers: [],
    statuses: []
  },
  isAddContainerMode: false,
  isAddingContainer: false,
  isLoadingStatuses: false,
  isLoadError: false,
  isModalOpenError: false
};

export function containersReducer(
  state: ContainersState = initialState,
  action: ContainersActionsUnion
): ContainersState {
  switch (action.type) {
    case ContainersActionTypes.Load:
      return {
        ...state,
        isAddContainerMode: false,
        isAddingContainer: false,
        isLoadingStatuses: false,
        isLoadError: false
      };

    case ContainersActionTypes.LoadSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          containers: [...action.payload.containers].sort((a, b) => a.Name.localeCompare(b.Name))
        },
        isModalOpenError: false
      };

    case ContainersActionTypes.LoadFailed:
      return {
        ...state,
        isLoadError: true
      };

    case ContainersActionTypes.AddContainerModalOpen:
      return {
        ...state,
        isLoadingStatuses: true,
        isModalOpenError: false
      };

    case ContainersActionTypes.AddContainerModalOpenSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          statuses: action.payload.statuses
        },
        isAddContainerMode: true,
        isLoadingStatuses: false,
        isModalOpenError: false
      };

    case ContainersActionTypes.AddContainerModalOpenFailed:
      return {
        ...state,
        isLoadingStatuses: false,
        isModalOpenError: true
      };

    case ContainersActionTypes.AddContainer:
      return {
        ...state,
        isAddingContainer: true
      };

    case ContainersActionTypes.AddContainerSuccess:
      return {
        ...state,
        isAddingContainer: false,
        isAddContainerMode: false
      };

    case ContainersActionTypes.AddContainerFailed:
      return {
        ...state,
        isAddingContainer: false
      };

    case ContainersActionTypes.CloseModals:
      return {
        ...state,
        isAddContainerMode: false
      };

    default:
      return state;
  }
}

export const getContainersState = createFeatureSelector<ContainersState>('containers');
