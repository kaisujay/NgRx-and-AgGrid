import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Store, select } from '@ngrx/store';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { Observable, Subscription, fromEvent } from 'rxjs';
import { CompanyDetailsModalService } from '../../container-wrapper/modules/company-details/services/company-details.modal.service';
import { AddContainerModalOpenActions, LoadAction } from '../@state/actions/containers.actions';
import { ContainersState, getContainersState } from '../@state/reducers/containers.reducer';
import { Container } from '../models/container';
import { CONTAINERS_GRID_OPTIONS } from '../models/containers-grid-options.model';
import { ContainersService } from '../services/containers.service';

@Component({
  selector: 'app-containers',
  templateUrl: 'containers.component.html',
  styleUrls: ['containers.component.scss']
})
export class ContainersComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;
  public gridOptions = CONTAINERS_GRID_OPTIONS;
  public containersState$: Observable<ContainersState>;

  private gridApi: GridApi;
  private rowData: Container[];
  private subscriptions: Subscription[] = [];

  public constructor(
    private store$: Store,
    private userConextSvc: UserContextService,
    private modalService: CompanyDetailsModalService,
    private dateFormatSvc: DateFormatService
  ) {}

  public ngOnInit(): void {
    this.bindDateFormatFunction();
    this.store$.dispatch(new LoadAction());
    this.containersState$ = this.store$.pipe(select(getContainersState));
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userConextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        let getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'LastModifiedDate'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['LastModifiedDate'], format);
        };
        getDateIndex = this.gridOptions.columnDefs.findIndex(colDef => (<ColDef>colDef).field === 'CreationDate');
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['CreationDate'], format);
        };
      })
    );
    this.modalService.sendContainerName('');
    this.modalService.sendCompanyName('');
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.subscriptions.push(
      this.store$.pipe(select(getContainersState)).subscribe(state => {
        this.rowData = state.data.containers;
        this.gridApi.setRowData(this.rowData);
      })
    );
  }

  public onAddContainer(): void {
    this.store$.dispatch(new AddContainerModalOpenActions());
  }

  public ngAfterViewInit(): void {
    this.subscriptions.push(
      fromEvent(this.filterTextBox.nativeElement, 'input').subscribe(({ target }: { target: HTMLInputElement }) => {
        this.gridApi.setRowData(ContainersService.searchContainers(this.rowData, target.value));
      })
    );
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
