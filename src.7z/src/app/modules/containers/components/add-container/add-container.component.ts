import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AddContainerActions, CloseModalsAction } from '../../@state/actions/containers.actions';
import { ContainersState, getContainersState } from '../../@state/reducers/containers.reducer';
import { ContainersService } from '../../services/containers.service';

@Component({
  selector: 'app-add-container',
  templateUrl: 'add-container.component.html',
  styleUrls: ['add-container.component.scss']
})
export class AddContainerComponent implements OnInit {
  public addContainerFormGroup: FormGroup;
  public containersState$: Observable<ContainersState>;
  public statusOptions$: Observable<SelectOptions[]>;

  public constructor(
    private store$: Store,
    private formBuilder: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.containersState$ = this.store$.pipe(select(getContainersState));

    this.statusOptions$ = this.store$.pipe(
      select(getContainersState),
      map(state => {
        return ContainersService.getStatusOptions(state.data.statuses);
      })
    );
  }

  private initForm(): void {
    this.addContainerFormGroup = this.formBuilder.group({
      Name: new FormControl('', [Validators.required]),
      Status: new FormControl('', [Validators.required]),
      IsTestContainer: new FormControl(false, [])
    });
  }

  public isFormChanged(): boolean {
    return this.addContainerFormGroup.value !== 1;
  }

  public onAddContainer(): void {
    this.store$.dispatch(new AddContainerActions(this.addContainerFormGroup.getRawValue()));
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }
}
