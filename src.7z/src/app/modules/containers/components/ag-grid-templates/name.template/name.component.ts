import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  template: '<span (click)="onSelectContainer()" class="c-text-primary c-cursor-pointer">{{params.value}}</span>'
})
export class NameComponent implements ICellRendererAngularComp {
  public params: ICellRendererParams;

  public constructor(private router: Router) {}

  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }

  public agInit(params: ICellRendererParams): void {
    this.params = params;
  }

  public onSelectContainer(): void {
    this.router.navigateByUrl('containers/' + this.params.data.Id.toString() + '/tree');
  }
}
