import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { AlertModule, ButtonModule, IconModule, LoaderModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { DeleteTermsofUseEffect } from './@state/effects/delete-terms-of-use.effect';
import { LoadTermsofUseEffect } from './@state/effects/load-terms-of-use.effect';
import { SaveNewTermsofUseEffect } from './@state/effects/save-new-terms-of-use.effect';
import { UpdateTermsofUseEffect } from './@state/effects/update-terms-of-use.effect';
import { TermsOfUseReducer } from './@state/reducers/terms-of-use.reducer';
import { DeleteConfirmationComponent } from './component/delete-confirmation/delete-confirmation.component';
import { ActionsRendererComponent } from './component/grid-template/actions-renderer/actions-renderer.component';
import { TermsOfUseTextRendererComponent } from './component/grid-template/terms-of-use-text-renderer/terms-of-use-text-renderer.component';
import { AddTermsOfUseComponent } from './component/terms-of-use/add-terms-of-use/add-terms-of-use.component';
import { TermsOfUseComponent } from './component/terms-of-use/terms-of-use.component';
import { TermsOfUseService } from './services/terms-of-use.service';
import { TermsOfUseRoutingModule } from './terms-of-use-routing.module';

@NgModule({
  declarations: [TermsOfUseComponent, ActionsRendererComponent, AddTermsOfUseComponent, DeleteConfirmationComponent],
  imports: [
    CommonModule,
    AdminSharedModule,
    LoaderModule,
    FormsModule,
    AlertModule,
    ReactiveFormsModule,
    ButtonModule,
    IconModule,
    CoreModule,
    TermsOfUseRoutingModule,
    AgGridModule.withComponents([ActionsRendererComponent, TermsOfUseTextRendererComponent]),
    StoreModule.forFeature('termsOfUse', TermsOfUseReducer),
    EffectsModule.forFeature([
      LoadTermsofUseEffect,
      SaveNewTermsofUseEffect,
      DeleteTermsofUseEffect,
      UpdateTermsofUseEffect
    ])
  ],
  providers: [TermsOfUseService]
})
export class TermsOfUseModule {}
