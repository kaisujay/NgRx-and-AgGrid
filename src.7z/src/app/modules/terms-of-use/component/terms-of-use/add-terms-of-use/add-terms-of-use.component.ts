import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CloseTermsOfUseModalAction, SaveNewTermsOfUseAction } from '../../../@state/actions/terms-of-use.actions';
import { getTermsofUseState } from '../../../@state/reducers/terms-of-use.reducer';
import { TermsOfUseModalType, TermsOfUseState } from '../../../models/terms-of-use.model';

@Component({
  selector: 'app-add-terms-of-use',
  templateUrl: './add-terms-of-use.component.html',
  styleUrls: ['./add-terms-of-use.component.scss']
})
export class AddTermsOfUseComponent implements OnInit {
  @Input() public modalType: TermsOfUseModalType;
  @Output() public onModalClose: EventEmitter<void> = new EventEmitter<void>();
  public text: string;
  public published: boolean;
  public cupcakeFlavor = CupcakeFlavors;
  public termsOfUseState$: Observable<TermsOfUseState>;

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.termsOfUseState$ = this.store.select(getTermsofUseState);
  }

  public onClose(): void {
    this.onModalClose.emit();
    this.store.dispatch(new CloseTermsOfUseModalAction());
  }

  public saveTermsOfUse(): void {
    this.store.dispatch(new SaveNewTermsOfUseAction({ Text: this.text, Published: this.published }));
  }
}
