import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTermsOfUseComponent } from './add-terms-of-use.component';

describe('AddTermsOfUseComponent', () => {
  let component: AddTermsOfUseComponent;
  let fixture: ComponentFixture<AddTermsOfUseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddTermsOfUseComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddTermsOfUseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
