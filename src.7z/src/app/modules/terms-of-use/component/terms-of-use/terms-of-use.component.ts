import { Component, OnDestroy, OnInit } from '@angular/core';
import { deepClone } from '@core/constants/constants';
import { DateTimeFormatDefined, TimeZoneFormat } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { CupcakeFlavors, SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store } from '@ngrx/store';
import { RowNode, ValueGetterParams } from 'ag-grid-community';
import * as moment from 'moment';
import { Observable, Subscription, tap } from 'rxjs';
import {
  LoadTermsOfUseAction,
  OpenAddTermsOfUseModalAction,
  OpenDeleteTermsOfUseModalAction,
  UpdateTermsOfUseAction
} from '../../@state/actions/terms-of-use.actions';
import { getTermsOfUseData, getTermsofUseState } from '../../@state/reducers/terms-of-use.reducer';
import {
  TermsOfUseModalType,
  TermsOfUseModalTypes,
  TermsOfUseRecord,
  TermsOfUseState
} from '../../models/terms-of-use.model';

@Component({
  selector: 'app-terms-of-use',
  templateUrl: './terms-of-use.component.html',
  styleUrls: ['./terms-of-use.component.scss']
})
export class TermsOfUseComponent implements OnInit, OnDestroy {
  public termsOfUse$: Observable<TermsOfUseState>;
  public rowData: TermsOfUseRecord[] = [];
  public subscriptions: Subscription[] = [];
  public modalType: TermsOfUseModalType;
  public termsOfUseModalTypes = TermsOfUseModalTypes;
  public selectedNodeForAction: RowNode;
  public versionDrodpownOptions: SelectOptions[] = [];
  public selectedVersion: string;
  public currentSelectedTermsOfRecord: TermsOfUseRecord;
  public initialSelectedTermsOfRecord: TermsOfUseRecord;
  public cupcakeFlavors = CupcakeFlavors;
  public userFormatSettings: DateTimeFormatDefined;
  public timeFormat = TimeZoneFormat;
  public showTextEditor = true;

  public constructor(
    private store: Store,
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService
  ) {}

  public ngOnInit(): void {
    this.getUserFormatSettings();
    this.store.dispatch(new LoadTermsOfUseAction());
    this.termsOfUse$ = this.store.select(getTermsofUseState).pipe(
      tap(state => {
        this.modalType = state.modalType;
        if (state.EditModalData.isSaveSuccess || state.Delete.isDeleteSuccess || state.AddModalData.isSaveSuccess) {
          this.store.dispatch(new LoadTermsOfUseAction());
        }
      })
    );
    this.setInitialData();
  }

  public setInitialData(): void {
    this.subscriptions.push(
      this.store.select(getTermsOfUseData).subscribe(state => {
        if (state.isLoadSuccess && state.termsOfServiceRecords.length) {
          this.rowData = this.sortByLastModifiedDate(deepClone(state.termsOfServiceRecords));
          this.prepareVersionDropdownOptions(this.rowData);
          this.setcurrentSelectedTermsOfRecord(this.rowData[0]);
          this.selectedVersion = this.versionDrodpownOptions[0].value;
        }
      })
    );
  }

  public sortByLastModifiedDate(records: TermsOfUseRecord[]): TermsOfUseRecord[] {
    return records.sort((a, b) => {
      return moment.utc(b.LastModifiedDate).diff(moment.utc(a.LastModifiedDate));
    });
  }

  public getUserFormatSettings(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        this.userFormatSettings = format;
      })
    );
  }

  public formatDate(params: ValueGetterParams, format: DateTimeFormatDefined): string {
    return this.dateFormatSvc.format(<Date>params.data['LastModifiedDate'], format, TimeZoneFormat.Ignored, false);
  }

  public setcurrentSelectedTermsOfRecord(record: TermsOfUseRecord) {
    this.initialSelectedTermsOfRecord = deepClone(record);
    this.currentSelectedTermsOfRecord = deepClone(record);
  }

  public onSelectedVersionChange(event: string): void {
    this.showTextEditor = false;
    setTimeout(() => {
      this.selectedVersion = event;
      this.setcurrentSelectedTermsOfRecord(this.rowData[Number(event)]);
      this.showTextEditor = true;
    }, 0);
  }

  public prepareVersionDropdownOptions(termsOfRecords: TermsOfUseRecord[]): void {
    this.versionDrodpownOptions = termsOfRecords.map((record, index) => {
      return {
        label: this.dateFormatSvc.format(
          <Date>record.LastModifiedDate,
          this.userFormatSettings,
          TimeZoneFormat.Localized,
          true
        ),
        value: index.toString()
      };
    });
  }

  public onDeleteClick(): void {
    this.store.dispatch(new OpenDeleteTermsOfUseModalAction(this.currentSelectedTermsOfRecord));
  }

  public onAddClick(): void {
    this.store.dispatch(new OpenAddTermsOfUseModalAction());
  }

  public onSaveClick(): void {
    this.store.dispatch(
      new UpdateTermsOfUseAction({
        Text: this.currentSelectedTermsOfRecord.Text,
        Published: this.currentSelectedTermsOfRecord.Published,
        RowVersion: this.currentSelectedTermsOfRecord.RowVersion,
        Id: this.currentSelectedTermsOfRecord.Id
      })
    );
  }

  public onDiscardChanges(): void {
    this.currentSelectedTermsOfRecord = deepClone(this.initialSelectedTermsOfRecord);
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
