import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import { CloseTermsOfUseModalAction, DeleteTermsOfUseAction } from '../../@state/actions/terms-of-use.actions';
import { getTermsofUseState } from '../../@state/reducers/terms-of-use.reducer';
import { TermsOfUseRecord, TermsOfUseState } from '../../models/terms-of-use.model';

@Component({
  selector: 'app-delete-confirmation',
  templateUrl: './delete-confirmation.component.html',
  styleUrls: ['./delete-confirmation.component.scss']
})
export class DeleteConfirmationComponent implements OnInit {
  public termsOfUseState$: Observable<TermsOfUseState>;
  public record: TermsOfUseRecord;
  @Output() public onModalClose: EventEmitter<void> = new EventEmitter<void>();

  public constructor(private store: Store) {}

  public ngOnInit(): void {
    this.termsOfUseState$ = this.store.select(getTermsofUseState).pipe(tap(state => (this.record = state.Delete.data)));
  }

  public onClose(): void {
    this.onModalClose.emit();
    this.store.dispatch(new CloseTermsOfUseModalAction());
  }

  public onDelete(): void {
    this.store.dispatch(new DeleteTermsOfUseAction(this.record.Id));
  }
}
