import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-terms-of-use-text-renderer',
  templateUrl: './terms-of-use-text-renderer.component.html',
  styleUrls: ['./terms-of-use-text-renderer.component.scss']
})
export class TermsOfUseTextRendererComponent implements ICellRendererAngularComp {
  public text: string;
  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }
  public agInit(params: ICellRendererParams): void {
    this.text = params.value;
  }
}
