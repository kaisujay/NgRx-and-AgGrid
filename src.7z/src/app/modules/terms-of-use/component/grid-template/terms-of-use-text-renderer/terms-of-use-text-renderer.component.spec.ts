import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermsOfUseTextRendererComponent } from './terms-of-use-text-renderer.component';

describe('TermsOfUseTextRendererComponent', () => {
  let component: TermsOfUseTextRendererComponent;
  let fixture: ComponentFixture<TermsOfUseTextRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TermsOfUseTextRendererComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(TermsOfUseTextRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
