import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'app-actions-renderer',
  templateUrl: './actions-renderer.component.html',
  styleUrls: ['./actions-renderer.component.scss']
})
export class ActionsRendererComponent implements ICellRendererAngularComp {
  public params: ICellRendererParams;

  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }
  public agInit(_params: ICellRendererParams): void {
    this.params = _params;
  }

  public onEditClick(): void {
    if (this.params['onEditClick'] instanceof Function) {
      this.params['onEditClick'](this.params.node);
    }
  }

  public onRemoveClick(): void {
    if (this.params['onDeleteClick'] instanceof Function) {
      this.params['onDeleteClick'](this.params.node);
    }
  }
}
