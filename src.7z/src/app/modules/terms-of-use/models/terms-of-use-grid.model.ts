import { GridOptions } from 'ag-grid-community';
import { ActionsRendererComponent } from '../component/grid-template/actions-renderer/actions-renderer.component';
import { TermsOfUseTextRendererComponent } from '../component/grid-template/terms-of-use-text-renderer/terms-of-use-text-renderer.component';

export const TERMS_OF_USE_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'Actions',
      field: 'actions',
      maxWidth: 150,
      cellRendererFramework: ActionsRendererComponent
    },
    {
      headerName: 'Last Modified By',
      field: 'LastModifiedBy',
      maxWidth: 150
    },
    {
      headerName: 'Last Modified Date',
      field: 'LastModifiedDate',
      maxWidth: 180
    },
    {
      headerName: 'Created By',
      field: 'CreatedBy',
      maxWidth: 120
    },
    {
      headerName: 'Creation Date',
      field: 'CreationDate',
      maxWidth: 150
    },
    {
      headerName: 'Text',
      field: 'Text',
      cellRendererFramework: TermsOfUseTextRendererComponent
    },
    {
      headerName: 'Published ?',
      field: 'Published',
      maxWidth: 150
    }
  ],
  defaultColDef: {
    flex: 1,
    minWidth: 90,
    resizable: true
  },
  pagination: true,
  paginationPageSize: 50,
  rowHeight: 100,
  animateRows: true,
  overlayLoadingTemplate: 'Loading...',
  overlayNoRowsTemplate: 'No rows to display.',
  suppressRowClickSelection: true,
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true
};
