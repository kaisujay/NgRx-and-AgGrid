export interface TermsOfUseRecord {
  CreatedBy: string;
  CreationDate: string | Date;
  Id: string;
  LastModifiedBy: string;
  LastModifiedDate: string | Date;
  Published: boolean;
  RowVersion: number;
  Text: string;
}

export interface TermsOfUseState {
  data: {
    termsOfServiceRecords: TermsOfUseRecord[];
    isLoading: boolean;
    isLoadSuccess: boolean;
    isLoadError: boolean;
  };
  save: {
    isSaving: boolean;
    isSaveSuccess: boolean;
    isSaveError: boolean;
  };
  modalType: TermsOfUseModalType;
  AddModalData: {
    data: unknown;
    isSaving: boolean;
    isSaveSuccess: boolean;
    isSaveError: boolean;
  };
  EditModalData: {
    data: TermsOfUseRecord;
    isSaving: boolean;
    isSaveSuccess: boolean;
    isSaveError: boolean;
  };
  Delete: {
    data: TermsOfUseRecord;
    isDeleting: boolean;
    isDeleteSuccess: boolean;
    isDeleteError: boolean;
  };
}

export enum TermsOfUseModalTypes {
  ADD = 'ADD',
  EDIT = 'EDIT',
  DELETE = 'DELETE'
}

export type TermsOfUseModalType = TermsOfUseModalTypes.ADD | TermsOfUseModalTypes.EDIT | TermsOfUseModalTypes.DELETE;
