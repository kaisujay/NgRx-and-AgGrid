import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { TermsOfUseRecord } from '../models/terms-of-use.model';

@Injectable()
export class TermsOfUseService {
  public constructor(private http: HttpClient) {}

  public getTermsOfUse(): Observable<TermsOfUseRecord[]> {
    return this.http.get<TermsOfUseRecord[]>(API.termsOfUse.get);
  }

  public saveTermsOfUse(payload: Partial<TermsOfUseRecord>): Observable<TermsOfUseRecord> {
    return this.http.post<TermsOfUseRecord>(API.termsOfUse.get, payload);
  }

  public updateTermsOfUse(payload: Partial<TermsOfUseRecord>): Observable<TermsOfUseRecord> {
    return this.http.put<TermsOfUseRecord>(buildApiString(API.termsOfUse.delete, { id: payload.Id }), payload);
  }

  public deleteTermsOfUse(id: string): Observable<void> {
    return this.http.delete<void>(buildApiString(API.termsOfUse.delete, { id }));
  }
}
