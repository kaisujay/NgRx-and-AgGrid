import { Action } from '@ngrx/store';
import { TermsOfUseRecord } from '../../models/terms-of-use.model';

export enum TermsOfUseActionTypes {
  LoadTermsOfUse = '[TermsOfUse] Load TermsOfUse',
  LoadTermsOfUseSuccess = '[TermsOfUse] Load TermsOfUse Success',
  LoadTermsOfUseFailed = '[TermsOfUse] Load TermsOfUse Failed',

  OpenAddTermsOfUseModal = '[TermsOfUse] Open Add TermsOfUse Modal',
  OpenEditTermsOfUseModal = '[TermsOfUse] Open Edit TermsOfUse Modal',
  OpenDeleteTermsOfUseModal = '[TermsOfUse] Open Delete TermsOfUse Modal',
  CloseTermsOfUseModal = '[TermsOfUse] Close Add TermsOfUse Modal',

  UpdateTermsOfUse = '[TermsOfUse] Edit TermsOfUse',
  UpdateTermsOfUseSuccess = '[TermsOfUse] Edit TermsOfUse Success',
  UpdateTermsOfUseFailed = '[TermsOfUse] Edit TermsOfUse Failed',

  SaveNewTermsOfUse = '[TermsOfUse] Save New TermsOfUse',
  SaveNewTermsOfUseSuccess = '[TermsOfUse] Save New TermsOfUse Success',
  SaveNewTermsOfUseFailed = '[TermsOfUse] Save New TermsOfUse Failed',

  DeleteTermsOfUse = '[TermsOfUse] Delete New TermsOfUse',
  DeleteTermsOfUseSuccess = '[TermsOfUse] Delete New TermsOfUse Success',
  DeleteTermsOfUseFailed = '[TermsOfUse] Delete New TermsOfUse Failed'
}

export class LoadTermsOfUseAction implements Action {
  public readonly type = TermsOfUseActionTypes.LoadTermsOfUse;
  public constructor() {}
}

export class LoadTermsOfUseSuccessAction implements Action {
  public readonly type = TermsOfUseActionTypes.LoadTermsOfUseSuccess;
  public constructor(public payload: TermsOfUseRecord[]) {}
}

export class LoadTermsOfUseFailedAction implements Action {
  public readonly type = TermsOfUseActionTypes.LoadTermsOfUseFailed;
  public constructor() {}
}

export class OpenAddTermsOfUseModalAction implements Action {
  public readonly type = TermsOfUseActionTypes.OpenAddTermsOfUseModal;
  public constructor() {}
}

export class OpenDeleteTermsOfUseModalAction implements Action {
  public readonly type = TermsOfUseActionTypes.OpenDeleteTermsOfUseModal;
  public constructor(public record: TermsOfUseRecord) {}
}

export class CloseTermsOfUseModalAction implements Action {
  public readonly type = TermsOfUseActionTypes.CloseTermsOfUseModal;
  public constructor() {}
}

export class OpenEditTermsOfUseModalAction implements Action {
  public readonly type = TermsOfUseActionTypes.OpenEditTermsOfUseModal;
  public constructor(public touRecord: TermsOfUseRecord) {}
}

export class SaveNewTermsOfUseAction implements Action {
  public readonly type = TermsOfUseActionTypes.SaveNewTermsOfUse;
  public constructor(public payload: Partial<TermsOfUseRecord>) {}
}

export class SaveNewTermsOfUseSuccessAction implements Action {
  public readonly type = TermsOfUseActionTypes.SaveNewTermsOfUseSuccess;
  public constructor(public payload: TermsOfUseRecord) {}
}

export class SaveNewTermsOfUseFailedAction implements Action {
  public readonly type = TermsOfUseActionTypes.SaveNewTermsOfUseFailed;
  public constructor() {}
}

export class DeleteTermsOfUseAction implements Action {
  public readonly type = TermsOfUseActionTypes.DeleteTermsOfUse;
  public constructor(public id: string) {}
}

export class DeleteTermsOfUseSuccessAction implements Action {
  public readonly type = TermsOfUseActionTypes.DeleteTermsOfUseSuccess;
  public constructor() {}
}

export class DeleteTermsOfUseFailedAction implements Action {
  public readonly type = TermsOfUseActionTypes.DeleteTermsOfUseFailed;
  public constructor() {}
}

export class UpdateTermsOfUseAction implements Action {
  public readonly type = TermsOfUseActionTypes.UpdateTermsOfUse;
  public constructor(public payload: Partial<TermsOfUseRecord>) {}
}

export class UpdateTermsOfUseSuccessAction implements Action {
  public readonly type = TermsOfUseActionTypes.UpdateTermsOfUseSuccess;
  public constructor(public payload: TermsOfUseRecord) {}
}

export class UpdateTermsOfUseFailedAction implements Action {
  public readonly type = TermsOfUseActionTypes.UpdateTermsOfUseFailed;
  public constructor() {}
}

export type TermsOfUseActionUnion =
  | LoadTermsOfUseAction
  | LoadTermsOfUseSuccessAction
  | LoadTermsOfUseFailedAction
  | OpenAddTermsOfUseModalAction
  | CloseTermsOfUseModalAction
  | OpenEditTermsOfUseModalAction
  | OpenDeleteTermsOfUseModalAction
  | SaveNewTermsOfUseAction
  | SaveNewTermsOfUseSuccessAction
  | SaveNewTermsOfUseFailedAction
  | DeleteTermsOfUseAction
  | DeleteTermsOfUseSuccessAction
  | DeleteTermsOfUseFailedAction
  | UpdateTermsOfUseAction
  | UpdateTermsOfUseSuccessAction
  | UpdateTermsOfUseFailedAction;
