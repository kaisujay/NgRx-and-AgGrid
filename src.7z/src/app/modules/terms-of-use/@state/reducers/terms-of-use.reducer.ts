import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TermsOfUseModalTypes, TermsOfUseState } from '../../models/terms-of-use.model';
import { TermsOfUseActionTypes, TermsOfUseActionUnion } from '../actions/terms-of-use.actions';

const intialState: TermsOfUseState = {
  data: {
    termsOfServiceRecords: [],
    isLoading: false,
    isLoadSuccess: false,
    isLoadError: false
  },
  save: {
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  modalType: null,
  AddModalData: {
    data: null,
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  EditModalData: {
    data: null,
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  Delete: {
    data: null,
    isDeleting: false,
    isDeleteSuccess: false,
    isDeleteError: false
  }
};

export function TermsOfUseReducer(
  state: TermsOfUseState = intialState,
  action: TermsOfUseActionUnion
): TermsOfUseState {
  switch (action.type) {
    case TermsOfUseActionTypes.LoadTermsOfUse: {
      return {
        ...intialState,
        data: {
          ...intialState.data,
          isLoading: true
        }
      };
    }

    case TermsOfUseActionTypes.LoadTermsOfUseSuccess: {
      return {
        ...state,
        data: {
          termsOfServiceRecords: action.payload,
          isLoading: false,
          isLoadSuccess: true,
          isLoadError: false
        }
      };
    }
    case TermsOfUseActionTypes.LoadTermsOfUseFailed: {
      return {
        ...state,
        data: {
          ...state.data,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: true
        }
      };
    }
    case TermsOfUseActionTypes.OpenAddTermsOfUseModal: {
      return {
        ...state,
        modalType: TermsOfUseModalTypes.ADD
      };
    }
    case TermsOfUseActionTypes.CloseTermsOfUseModal: {
      return {
        ...state,
        modalType: null
      };
    }
    case TermsOfUseActionTypes.OpenEditTermsOfUseModal: {
      return {
        ...state,
        EditModalData: {
          ...state.EditModalData,
          data: action.touRecord
        },
        modalType: TermsOfUseModalTypes.EDIT
      };
    }
    case TermsOfUseActionTypes.OpenDeleteTermsOfUseModal: {
      return {
        ...state,
        Delete: {
          ...state.Delete,
          data: action.record
        },
        modalType: TermsOfUseModalTypes.DELETE
      };
    }
    case TermsOfUseActionTypes.SaveNewTermsOfUse: {
      return {
        ...state,
        AddModalData: {
          ...state.AddModalData,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case TermsOfUseActionTypes.SaveNewTermsOfUseSuccess: {
      return {
        ...state,
        AddModalData: {
          ...state.AddModalData,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        },
        modalType: null
      };
    }
    case TermsOfUseActionTypes.SaveNewTermsOfUseFailed: {
      return {
        ...state,
        AddModalData: {
          ...state.AddModalData,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    case TermsOfUseActionTypes.DeleteTermsOfUse: {
      return {
        ...state,
        Delete: {
          ...state.Delete,
          isDeleting: true,
          isDeleteSuccess: false,
          isDeleteError: false
        }
      };
    }
    case TermsOfUseActionTypes.DeleteTermsOfUseSuccess: {
      return {
        ...state,
        Delete: {
          ...state.Delete,
          isDeleting: false,
          isDeleteSuccess: true,
          isDeleteError: false
        }
      };
    }
    case TermsOfUseActionTypes.DeleteTermsOfUseFailed: {
      return {
        ...state,
        Delete: {
          ...state.Delete,
          isDeleting: false,
          isDeleteSuccess: false,
          isDeleteError: true
        }
      };
    }
    case TermsOfUseActionTypes.UpdateTermsOfUse: {
      return {
        ...state,
        EditModalData: {
          ...state.EditModalData,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    }
    case TermsOfUseActionTypes.UpdateTermsOfUseSuccess: {
      return {
        ...state,
        EditModalData: {
          ...state.EditModalData,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        },
        modalType: null
      };
    }
    case TermsOfUseActionTypes.UpdateTermsOfUseFailed: {
      return {
        ...state,
        EditModalData: {
          ...state.EditModalData,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };
    }
    default:
      return { ...state };
  }
}

export const getTermsofUseState = createFeatureSelector<TermsOfUseState>('termsOfUse');
export const getTermsOfUseData = createSelector(getTermsofUseState, (state: TermsOfUseState) => state.data);
export const getAddTermsOfUseModalData = createSelector(
  getTermsofUseState,
  (state: TermsOfUseState) => state.AddModalData
);
export const getEditTermsOfUseModalData = createSelector(
  getTermsofUseState,
  (state: TermsOfUseState) => state.EditModalData
);
