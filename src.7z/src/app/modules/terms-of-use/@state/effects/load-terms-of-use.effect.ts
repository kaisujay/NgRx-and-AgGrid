import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { TermsOfUseService } from '../../services/terms-of-use.service';
import {
  LoadTermsOfUseAction,
  LoadTermsOfUseFailedAction,
  LoadTermsOfUseSuccessAction,
  TermsOfUseActionTypes
} from '../actions/terms-of-use.actions';

@Injectable()
export class LoadTermsofUseEffect {
  public constructor(
    private actions$: Actions,
    private termsOfSvc: TermsOfUseService
  ) {}
  public loadConnectionSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TermsOfUseActionTypes.LoadTermsOfUse),
      switchMap((_action: LoadTermsOfUseAction) =>
        this.termsOfSvc.getTermsOfUse().pipe(
          map(_data => new LoadTermsOfUseSuccessAction(_data)),
          catchError(_err => of(new LoadTermsOfUseFailedAction()))
        )
      )
    )
  );
}
