import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TermsOfUseService } from '../../services/terms-of-use.service';
import {
  DeleteTermsOfUseAction,
  DeleteTermsOfUseFailedAction,
  DeleteTermsOfUseSuccessAction,
  TermsOfUseActionTypes
} from '../actions/terms-of-use.actions';

@Injectable()
export class DeleteTermsofUseEffect {
  public constructor(
    private actions$: Actions,
    private termsOfSvc: TermsOfUseService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public deleteTermsOfUseSetting$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TermsOfUseActionTypes.DeleteTermsOfUse),
      switchMap((_action: DeleteTermsOfUseAction) =>
        this.termsOfSvc.deleteTermsOfUse(_action.id).pipe(
          map(_ => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Terms of use deleted successfully');
    return new DeleteTermsOfUseSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while deleting terms of use record');
    return of(new DeleteTermsOfUseFailedAction());
  }
}
