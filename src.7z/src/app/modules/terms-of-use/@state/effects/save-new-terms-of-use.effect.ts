import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { TermsOfUseRecord } from '../../models/terms-of-use.model';
import { TermsOfUseService } from '../../services/terms-of-use.service';
import {
  SaveNewTermsOfUseAction,
  SaveNewTermsOfUseFailedAction,
  SaveNewTermsOfUseSuccessAction,
  TermsOfUseActionTypes
} from '../actions/terms-of-use.actions';

@Injectable()
export class SaveNewTermsofUseEffect {
  public constructor(
    private actions$: Actions,
    private termsOfSvc: TermsOfUseService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public loadConnectionSettings$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TermsOfUseActionTypes.SaveNewTermsOfUse),
      switchMap((_action: SaveNewTermsOfUseAction) =>
        this.termsOfSvc.saveTermsOfUse(_action.payload).pipe(
          map(_data => this.handleSuccess(_data)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(record: TermsOfUseRecord) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Terms of use created successfully');
    return new SaveNewTermsOfUseSuccessAction(record);
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while creating terms of use record');
    return of(new SaveNewTermsOfUseFailedAction());
  }
}
