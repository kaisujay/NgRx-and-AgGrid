import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { CheckboxModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadProductUsersEffect } from '@state/effects/load-product-users.effect';
import { LoadUserDetailsEffect } from '@state/effects/load-user-details.effect';
import { productUsersReducer } from '@state/reducers/product-users.reducer';
import { AgGridModule } from 'ag-grid-angular';
import { EditUserEffect } from './@state/effects/edit-user.effect';
import { ExportToXlsxEffect } from './@state/effects/export-to-xlsx.effect';
import { ResetPasswordEffect } from './@state/effects/reset-password.effect';
import { UnlockEffect } from './@state/effects/unlock.effect';
import { EditProductUserComponent } from './components/edit-product-user/edit-product-user.component';
import { ProductUsersComponent } from './components/product-users.component';
import { UserCreatedModalContentComponent } from './components/user-created-modal-content/user-created-modal-content.component';
import { ProductUsersRoutingModule } from './product-users-routing.module';
import { ExportToExcelService } from './services/export-to-excel.service';
import { ProductUsersHttpService } from './services/product-users-http.service';

@NgModule({
  declarations: [
    ProductUsersComponent,
    CheckboxRendererComponent,
    EditProductUserComponent,
    UserCreatedModalContentComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    ProductUsersRoutingModule,
    AgGridModule.withComponents([CheckboxRendererComponent]),
    StoreModule.forFeature('productUsers', productUsersReducer),
    EffectsModule.forFeature([
      LoadUserDetailsEffect,
      ExportToXlsxEffect,
      LoadProductUsersEffect,
      ResetPasswordEffect,
      UnlockEffect,
      EditUserEffect
    ]),
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    SPRFormsModule,
    CheckboxModule
  ],
  providers: [ExportToExcelService, ProductUsersHttpService]
})
export class ProductUsersModule {}
