import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductUsersComponent } from './components/product-users.component';

const routes: Routes = [
  {
    path: '',
    component: ProductUsersComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductUsersRoutingModule {}
