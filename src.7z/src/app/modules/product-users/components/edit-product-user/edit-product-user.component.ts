import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import {
  CloseModalsAction,
  ResetPasswordAction,
  SaveEditedUserAction,
  UnlockUserAction
} from '@state/actions/product-users.actions';
import { ProductUsersState, getProductUsersState } from '@state/reducers/product-users.reducer';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProductUserDetails } from '../../models/product-user.details';

@Component({
  selector: 'app-edit-product-user',
  templateUrl: './edit-product-user.component.html',
  styleUrls: ['./edit-product-user.component.scss']
})
export class EditProductUserComponent implements OnInit {
  @Input() public user: ProductUserDetails;
  public editUserFormGroup: FormGroup;
  public productUserState$: Observable<ProductUsersState>;
  public countryOptions$: Observable<SelectOptions[]>;

  private initialUserDetails: ProductUserDetails;

  public constructor(
    private store$: Store,
    private formBuilder: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.productUserState$ = this.store$.pipe(select(getProductUsersState));

    this.countryOptions$ = this.store$.pipe(
      select(getProductUsersState),
      map(state => {
        return state.editUser.countries.map(country => ({
          label: country.countryName,
          value: country.countryName
        }));
      })
    );
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }

  public onResetPassword(userId: string, email: string): void {
    this.store$.dispatch(new ResetPasswordAction({ userId, email }));
  }

  public onUnlock(id: string, email: string): void {
    this.store$.dispatch(new UnlockUserAction({ id, email }));
  }

  public onSave(): void {
    this.store$.dispatch(
      new SaveEditedUserAction({
        ...this.initialUserDetails,
        ...this.editUserFormGroup.getRawValue()
      })
    );
  }

  public isFormChanged(): boolean {
    const form = this.editUserFormGroup.getRawValue();
    return Object.keys(form).some(key => form[key] !== this.initialUserDetails[key]);
  }

  private initForm(): void {
    this.editUserFormGroup = this.formBuilder.group({
      Email: new FormControl(this.user.Email, [
        Validators.required,
        Validators.pattern(
          new RegExp(
            // eslint-disable-next-line no-useless-escape
            /^(([^<>()\\.,;:\s@\"]+(\.[^<>()\\.,;:\s@\"]+)*)|\".+\")@[a-zA-Z\-0-9]{2,}\.[a-zA-Z]{2,}(\.[a-zA-Z]{1,3})?$/
          )
        )
      ]),
      FirstName: new FormControl(this.user.FirstName, [Validators.required]),
      LastName: new FormControl(this.user.LastName, [Validators.required]),
      Title: new FormControl(this.user.Title, []),
      PhoneNumber: new FormControl(this.user.PhoneNumber, []),
      City: new FormControl(this.user.City, [Validators.required]),
      Country: new FormControl(this.user.Country, [Validators.required]),
      Status: new FormControl(this.user.Status, [Validators.required]),
      ApiOnly: new FormControl(this.user.ApiOnly, [Validators.required]),
      IsFixServiceAccount: new FormControl(this.user.IsFixServiceAccount, [Validators.required]),
      IpreoAccountIntegrationRequired: new FormControl(this.user.IpreoAccountIntegrationRequired, [
        Validators.required
      ]),
      ThinkFolioUserId: new FormControl(this.user.ThinkFolioUserId, [])
    });

    this.initialUserDetails = { ...this.user };
  }
}
