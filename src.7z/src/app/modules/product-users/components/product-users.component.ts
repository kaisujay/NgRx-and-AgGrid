import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { ExportToXLSXAction, LoadUsersAction, ProductUsersActionTypes } from '@state/actions/product-users.actions';
import { ProductUsersState, getProductUsersState } from '@state/reducers/product-users.reducer';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { Observable, Subscription, debounceTime, filter, first, fromEvent, switchMap } from 'rxjs';
import { PRODUCT_USER_GRID_OPTIONS } from '../models/product-grid-options.model';

@Component({
  selector: 'app-product-users',
  templateUrl: './product-users.component.html',
  styleUrls: ['./product-users.component.scss']
})
export class ProductUsersComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;
  public gridOptions = PRODUCT_USER_GRID_OPTIONS;
  public productUsersState$: Observable<ProductUsersState>;

  private gridApi: GridApi;
  private subscriptions: Subscription[] = [];
  public defaultSortModel = {
    sort: 'asc',
    colId: 'Email'
  };

  public constructor(
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService,
    private store$: Store,
    private actions$: Actions
  ) {}

  public ngOnInit(): void {
    this.bindDateFormatFunction();
    this.productUsersState$ = this.store$.pipe(select(getProductUsersState));
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        const getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'LastLoginDate'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['LastLoginDate'], format);
        };
      })
    );
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;

    params.api.setServerSideDatasource({
      getRows: params => {
        if (params.request.sortModel.length === 0) {
          params.request.sortModel.push(this.defaultSortModel);
        }
        this.store$.dispatch(
          new LoadUsersAction({
            params: params.request,
            filter: this.filterTextBox.nativeElement.value
          })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(action => action.type === ProductUsersActionTypes.LoadUsersSuccess),
              switchMap(() => this.store$.select(getProductUsersState)),
              first()
            )
            .subscribe(state => {
              params.success({
                rowData: state.data.users.rowData,
                rowCount: state.data.users.rowCount
              });
            })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(
                action =>
                  action.type === ProductUsersActionTypes.SaveEditedUserSuccess ||
                  action.type === ProductUsersActionTypes.ResetPasswordSuccess ||
                  action.type === ProductUsersActionTypes.UnlockUserSuccess
              ),
              first()
            )
            .subscribe(_ => {
              this.gridApi.refreshServerSideStore({
                route: null,
                purge: false
              });
            })
        );
      }
    });
  }

  public ngAfterViewInit(): void {
    this.subscriptions.push(
      fromEvent(this.filterTextBox.nativeElement, 'input')
        .pipe(debounceTime(500))
        .subscribe(() => {
          this.gridApi.refreshServerSideStore({ route: null, purge: false });
        })
    );
  }

  public export(): void {
    this.store$.dispatch(new ExportToXLSXAction(this.filterTextBox.nativeElement.value));
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
