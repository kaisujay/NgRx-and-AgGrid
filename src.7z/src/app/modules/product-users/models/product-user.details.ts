import { DateTimeFormat } from '@shared/models/date-time-format';

export interface ProductUserDetails {
  AcceptTermsOfUseRequired: boolean;
  ApiOnly: boolean;
  City: string;
  Companies: [
    {
      Id: string;
      CompanyName: string;
      CompanyId: string;
      RowVersion: number;
    }
  ];
  Containers: [
    {
      Id: string;
      IsAdmin: boolean;
      IsExcludedFromMembershipAudit: boolean;
    }
  ];
  Country: string;
  CreatedBy: string;
  CreationDate: Date;
  Currency: string;
  DateFormat: DateTimeFormat;
  Email: string;
  Emails: [
    {
      CreatedBy: string;
      CreationDate: Date;
      Email: string;
      Id: string;
      IsConfirmed: boolean;
      IsPrimary: boolean;
      LastModifiedBy: string;
      LastModifiedDate: Date;
      RowVersion: number;
      UserId: string;
    }
  ];
  FirstName: string;
  HomePage: string;
  Id: string;
  InvitationStatus: string;
  IpreoAccountId: string;
  IpreoAccountIntegrationRequired: boolean;
  IsFixServiceAccount: boolean;
  Language: string;
  LastLoginDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  LastName: string;
  Lockout: false;
  NumberFormat: DateTimeFormat;
  PasswordChangeRequired: false;
  PhoneNumber: null;
  Phones: [];
  Role: null;
  RowVersion: 1652363887;
  SentToOrionQueue: false;
  Status: string;
  ThinkFolioUserId: null;
  TimeFormat: DateTimeFormat;
  Timezone: string;
  Title: string;
  UserName: string;
}
