export interface ProductUsersResponse {
  Count: number;
  PageCount: number;
  PageNumber: number;
  PageSize: number;
  Items: ProductUser[];
}

export interface ProductUser {
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  FirstName: string;
  LastName: string;
  Email: string;
  Emails: string[];
  Status: string;
  Lockout: boolean;
  LastLoginDate: string;
  ContainersNamesList: string;
  CompaniesNamesList: string;
  CompanyIdsList: string;
  Title: string;
  City: string;
  Country: string;
  Role: string;
  PhoneNumber: string;
  Companies: ProductUserCompany[];
  Containers: ProductUserContainer[];
  IsContainerAdmin: boolean;
  OrderInd: boolean;
  IpreoAccountId: string;
  InvitationStatus: string;
}

export interface ProductUserContainer {
  ContainerId: string;
  IsAdmin: boolean;
  IsExcludedFromMembershipAudit: boolean;
}

export interface ProductUserCompany {
  Id: string;
  CompanyId: string;
  OrionId: number;
  UserId: string;
  CompanyName: string;
  Role: string;
  RowVersion: number;
}
