import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { CustomLoadingCellRendererComponent } from '@shared/components/loading-cell-renderer/loading-cell-renderer.component';
import { GridOptions } from 'ag-grid-community';
import * as dayjs from 'dayjs';
import { FirstLastNameComponent } from '../components/ag-grid-templates/first-last-name.template/first-last-name.component';

export const PRODUCT_USER_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'First Name',
      field: 'FirstName',
      tooltipField: 'FirstName',
      minWidth: 180,
      cellRendererFramework: FirstLastNameComponent
    },
    {
      headerName: 'Last Name',
      field: 'LastName',
      tooltipField: 'LastName',
      minWidth: 180,
      cellRendererFramework: FirstLastNameComponent
    },
    {
      headerName: 'Email',
      tooltipField: 'Email',
      field: 'Email',
      suppressColumnsToolPanel: true,
      sort: 'asc',
      minWidth: 200
    },
    {
      headerName: 'Status',
      tooltipField: 'Status',
      field: 'Status',
      minWidth: 100
    },
    {
      headerName: 'Containers',
      field: 'ContainersNamesList',
      tooltipField: 'ContainersNamesList',
      sortable: false,
      minWidth: 200
    },
    {
      headerName: 'Companies',
      tooltipField: 'CompaniesNamesList',
      field: 'CompaniesNamesList',
      minWidth: 200,
      sortable: false
    },
    {
      headerName: 'Last Login',
      tooltipField: 'LastLoginDate',
      field: 'LastLoginDate',
      valueGetter: params =>
        params && params.data && params.data['LastLoginDate'] ? dayjs(params.data['LastLoginDate']).format() : '-',
      minWidth: 250
    },
    {
      headerName: 'Lock?',
      field: 'Lockout',
      cellRenderer: 'checkboxRenderer',
      minWidth: 80,
      sortable: false
    },
    {
      headerName: 'Is Container Admin?',
      field: 'IsContainerAdmin',
      tooltipField: 'IsContainerAdmin',
      minWidth: 180,
      sortable: false,
      valueGetter: params => (params && params.data && params.data.IsContainerAdmin ? 'True' : '-')
    },
    {
      headerName: 'Is Order Permissioned?',
      field: 'OrderInd',
      tooltipField: 'OrderInd',
      minWidth: 180,
      sortable: false,
      valueGetter: params => (params && params.data && params.data.OrderInd ? 'True' : '-')
    }
  ],
  frameworkComponents: {
    checkboxRenderer: CheckboxRendererComponent
  },
  defaultColDef: {
    flex: 1,
    minWidth: 90,
    resizable: true,
    sortable: true
  },
  rowModelType: 'serverSide',
  serverSideStoreType: 'partial',
  pagination: true,
  paginationPageSize: 50,
  cacheBlockSize: 50,
  tooltipShowDelay: 1000,
  animateRows: true,
  loadingCellRendererFramework: CustomLoadingCellRendererComponent,
  suppressRowClickSelection: true,
  overlayNoRowsTemplate: 'No records to dispaly',
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressNoRowsOverlay: false,
  suppressLoadingOverlay: false,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true,
  suppressHorizontalScroll: false
};
