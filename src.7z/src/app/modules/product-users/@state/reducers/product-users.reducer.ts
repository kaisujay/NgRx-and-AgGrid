import { createFeatureSelector } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { ProductUserDetails } from '../../models/product-user.details';
import { ProductUser } from '../../models/product-users.model';
import { ProductUsersActionsUnion, ProductUsersActionTypes } from '../actions/product-users.actions';

export interface ProductUsersState {
  data: {
    users: {
      rowData: ProductUser[];
      rowCount: number;
    };
    isLoadError: boolean;
  };
  editUser: {
    isEditMode: boolean;
    editedUser: ProductUserDetails;
    countries: Country[];
    isSaving: boolean;
    isResettingPassword: boolean;
    isUnlocking: boolean;
    isResetPasswordModalVisible: boolean;
    isUnlockModalVisible: boolean;
    isLoadError: boolean;
  };
  exportToXLSX: {
    isExporting: boolean;
  };
}

export const initialState: ProductUsersState = {
  data: {
    users: {
      rowData: [],
      rowCount: 0
    },
    isLoadError: false
  },
  editUser: {
    isEditMode: false,
    editedUser: null,
    countries: [],
    isSaving: false,
    isResettingPassword: false,
    isUnlocking: false,
    isResetPasswordModalVisible: false,
    isUnlockModalVisible: false,
    isLoadError: false
  },
  exportToXLSX: {
    isExporting: false
  }
};

export function productUsersReducer(
  state: ProductUsersState = initialState,
  action: ProductUsersActionsUnion
): ProductUsersState {
  switch (action.type) {
    case ProductUsersActionTypes.LoadUsersSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          users: {
            ...action.payload
          },
          isLoadError: false
        }
      };

    case ProductUsersActionTypes.LoadUsersFailed:
      return {
        ...state,
        data: {
          ...state.data,
          isLoadError: true
        }
      };

    case ProductUsersActionTypes.LoadUserDetailsSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true,
          editedUser: action.payload.userDetails,
          countries: action.payload.countries,
          isLoadError: false
        }
      };

    case ProductUsersActionTypes.LoadUserDetailsFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isLoadError: true
        }
      };

    case ProductUsersActionTypes.SaveEditedUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false,
          isSaving: true
        }
      };

    case ProductUsersActionTypes.SaveEditedUserSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isSaving: false
        }
      };

    case ProductUsersActionTypes.SaveEditedUserFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true,
          isSaving: false
        }
      };

    case ProductUsersActionTypes.ResetPassword:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: true
        }
      };

    case ProductUsersActionTypes.ResetPasswordSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isResettingPassword: false,
          editedUser: null,
          isResetPasswordModalVisible: true
        }
      };

    case ProductUsersActionTypes.ResetPasswordFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false
        }
      };

    case ProductUsersActionTypes.UnlockUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isUnlocking: true
        }
      };

    case ProductUsersActionTypes.UnlockUserSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isUnlocking: false,
          isUnlockModalVisible: true
        }
      };

    case ProductUsersActionTypes.UnlockUserFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isUnlocking: true
        }
      };

    case ProductUsersActionTypes.ExportToXLSX:
      return {
        ...state,
        exportToXLSX: {
          isExporting: true
        }
      };

    case ProductUsersActionTypes.ExportToXLSXSuccess:
    case ProductUsersActionTypes.ExportToXLSXFailed:
      return {
        ...state,
        exportToXLSX: {
          isExporting: false
        }
      };

    case ProductUsersActionTypes.CloseModals:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isResetPasswordModalVisible: false,
          isUnlockModalVisible: false
        }
      };

    default:
      return state;
  }
}

export const getProductUsersState = createFeatureSelector<ProductUsersState>('productUsers');
