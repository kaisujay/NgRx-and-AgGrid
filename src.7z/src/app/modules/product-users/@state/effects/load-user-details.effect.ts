import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { ProductUsersHttpService } from '../../services/product-users-http.service';
import {
  LoadUserDetailsAction,
  LoadUserDetailsFailedAction,
  LoadUserDetailsSuccessAction,
  ProductUsersActionTypes
} from '../actions/product-users.actions';

@Injectable()
export class LoadUserDetailsEffect {
  public constructor(
    private actions$: Actions,
    private kendoAdapterService: KendoAdapterService,
    private productUsersHttpService: ProductUsersHttpService
  ) {}
  public loadUserDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.LoadUserDetails),
      switchMap((action: LoadUserDetailsAction) =>
        forkJoin(
          this.productUsersHttpService.getCountries(),
          this.productUsersHttpService.getUserDetails(action.payload.id)
        ).pipe(
          map(([{ countries }, userDetails]) => {
            return new LoadUserDetailsSuccessAction({ countries, userDetails });
          }),
          catchError(_err => of(new LoadUserDetailsFailedAction()))
        )
      )
    )
  );
}
