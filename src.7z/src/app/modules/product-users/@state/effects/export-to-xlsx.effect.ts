import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import {
  ExportToXLSXAction,
  ExportToXLSXFailedAction,
  ExportToXLSXSuccessAction,
  ProductUsersActionTypes
} from '@state/actions/product-users.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ExportToExcelService } from '../../services/export-to-excel.service';

@Injectable()
export class ExportToXlsxEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private exportToExcelService: ExportToExcelService
  ) {}
  public exportToXlsxEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.ExportToXLSX),
      switchMap((action: ExportToXLSXAction) =>
        this.exportToExcelService.export(API.productUsers.getAll, action.filter).pipe(
          map(_res => this.handleSuccess()),
          catchError(_err => this.handleError())
        )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Exported successfully');
    return new ExportToXLSXSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while Exporting');
    return of(new ExportToXLSXFailedAction());
  }
}
