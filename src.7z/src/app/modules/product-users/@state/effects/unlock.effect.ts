import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import {
  ProductUsersActionTypes,
  UnlockUserAction,
  UnlockUserFailedAction,
  UnlockUserSuccessAction
} from '@state/actions/product-users.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ProductUsersHttpService } from '../../services/product-users-http.service';

@Injectable()
export class UnlockEffect {
  public constructor(
    private actions$: Actions,
    private productUsersHttpService: ProductUsersHttpService
  ) {}
  public unlockEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.UnlockUser),
      switchMap((action: UnlockUserAction) =>
        this.productUsersHttpService.unlock(action.payload.id).pipe(
          map(() => {
            return new UnlockUserSuccessAction();
          }),
          catchError(_err => of(new UnlockUserFailedAction()))
        )
      )
    )
  );
}
