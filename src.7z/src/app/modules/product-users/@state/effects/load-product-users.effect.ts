import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { LoadUsersAction, LoadUsersFailedAction, LoadUsersSuccessAction } from '@state/actions/product-users.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ProductUser } from '../../models/product-users.model';
import { ProductUsersActionTypes } from '../actions/product-users.actions';

@Injectable()
export class LoadProductUsersEffect {
  public constructor(
    private actions$: Actions,
    private kendoAdapterService: KendoAdapterService
  ) {}
  public loadProductUsersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.LoadUsers),
      switchMap((action: LoadUsersAction) => {
        return this.kendoAdapterService
          .get<ProductUser>(API.productUsers.getAll, action.payload.params, action.payload.filter)
          .pipe(
            map(response => {
              return new LoadUsersSuccessAction(response);
            }),
            catchError(_err => of(new LoadUsersFailedAction()))
          );
      })
    )
  );
}
