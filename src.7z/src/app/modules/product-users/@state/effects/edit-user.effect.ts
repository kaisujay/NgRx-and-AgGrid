import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { Store } from '@ngrx/store';
import { ProductUsersHttpService } from '../../services/product-users-http.service';
import {
  ProductUsersActionTypes,
  SaveEditedUserAction,
  SaveEditedUserFailedAction,
  SaveEditedUserSuccessAction
} from '@state/actions/product-users.actions';

@Injectable()
export class EditUserEffect {
  public constructor(
    private actions$: Actions,
    private productUsersHttpService: ProductUsersHttpService,
    private store$: Store
  ) {}
  public editUserEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.SaveEditedUser),
      switchMap((action: SaveEditedUserAction) => {
        return this.productUsersHttpService.editUser(action.payload).pipe(
          map(() => new SaveEditedUserSuccessAction()),
          catchError(() => of(new SaveEditedUserFailedAction()))
        );
      })
    )
  );
}
