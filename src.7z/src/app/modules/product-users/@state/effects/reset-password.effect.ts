import { Injectable } from '@angular/core';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import {
  ProductUsersActionTypes,
  ResetPasswordAction,
  ResetPasswordFailedAction,
  ResetPasswordSuccessAction
} from '@state/actions/product-users.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ProductUsersHttpService } from '../../services/product-users-http.service';

@Injectable()
export class ResetPasswordEffect {
  public constructor(
    private actions$: Actions,
    private productUsersHttpService: ProductUsersHttpService,
    private credentialsService: CredentialsService
  ) {}
  public resetPasswordEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductUsersActionTypes.ResetPassword),
      switchMap((action: ResetPasswordAction) =>
        this.productUsersHttpService.resetPassword(action.payload.userId).pipe(
          map(response => {
            this.credentialsService.set({
              password: response.Password,
              email: action.payload.email
            });

            return new ResetPasswordSuccessAction();
          }),
          catchError(_err => of(new ResetPasswordFailedAction()))
        )
      )
    )
  );
}
