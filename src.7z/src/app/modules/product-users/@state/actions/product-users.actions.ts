import { Action } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { ProductUserDetails } from '../../models/product-user.details';
import { ProductUser } from '../../models/product-users.model';

export enum ProductUsersActionTypes {
  LoadUsers = '[Product Users] Load Product Users',
  LoadUsersSuccess = '[Product Users] Load Product Users Success',
  LoadUsersFailed = '[Product Users] Load Product Users Failed',

  LoadUserDetails = '[Product Users] Load User Details',
  LoadUserDetailsSuccess = '[Product Users] Load User Details Success',
  LoadUserDetailsFailed = '[Product Users] Load User Details Failed',

  SaveEditedUser = '[Product Users] Save Edited User',
  SaveEditedUserSuccess = '[Product Users] Save Edited User Success',
  SaveEditedUserFailed = '[Product Users] Save Edited User Failed',

  ResetPassword = '[Product Users] Reset Password',
  ResetPasswordSuccess = '[Product Users] Reset Password Success',
  ResetPasswordFailed = '[Product Users] Reset Password Failed',

  UnlockUser = '[Product Users] Unlock User',
  UnlockUserSuccess = '[Product Users] Unlock User Success',
  UnlockUserFailed = '[Product Users] Unlock User Failed',

  ExportToXLSX = '[Product Users] Export to XLSX',
  ExportToXLSXSuccess = '[Product Users] Export to XLSX Success',
  ExportToXLSXFailed = '[Product Users] Export to XLSX Failed',

  CloseModals = '[Product Users] Close Modals'
}

export class LoadUsersAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUsers;
  public constructor(
    public payload: {
      params: IServerSideGetRowsRequest;
      filter: string;
    }
  ) {}
}

export class LoadUsersSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUsersSuccess;
  public constructor(
    public payload: {
      rowData: ProductUser[];
      rowCount: number;
    }
  ) {}
}

export class LoadUsersFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUsersFailed;
  public constructor() {}
}

export class LoadUserDetailsAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUserDetails;
  public constructor(public payload: { id: string }) {}
}

export class LoadUserDetailsSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUserDetailsSuccess;
  public constructor(public payload: { countries: Country[]; userDetails: ProductUserDetails }) {}
}

export class LoadUserDetailsFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.LoadUserDetailsFailed;
  public constructor() {}
}

export class SaveEditedUserAction implements Action {
  public readonly type = ProductUsersActionTypes.SaveEditedUser;
  public constructor(public payload: ProductUserDetails) {}
}

export class SaveEditedUserSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.SaveEditedUserSuccess;
  public constructor() {}
}

export class SaveEditedUserFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.SaveEditedUserFailed;
  public constructor() {}
}

export class ResetPasswordAction implements Action {
  public readonly type = ProductUsersActionTypes.ResetPassword;
  public constructor(public payload: { userId: string; email: string }) {}
}

export class ResetPasswordSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.ResetPasswordSuccess;
  public constructor() {}
}

export class ResetPasswordFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.ResetPasswordFailed;
  public constructor() {}
}

export class UnlockUserAction implements Action {
  public readonly type = ProductUsersActionTypes.UnlockUser;
  public constructor(public payload: { id: string; email: string }) {}
}

export class UnlockUserSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.UnlockUserSuccess;
  public constructor() {}
}

export class UnlockUserFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.UnlockUserFailed;
  public constructor() {}
}

export class ExportToXLSXAction implements Action {
  public readonly type = ProductUsersActionTypes.ExportToXLSX;
  public constructor(public filter: string) {}
}

export class ExportToXLSXSuccessAction implements Action {
  public readonly type = ProductUsersActionTypes.ExportToXLSXSuccess;
  public constructor() {}
}

export class ExportToXLSXFailedAction implements Action {
  public readonly type = ProductUsersActionTypes.ExportToXLSXFailed;
  public constructor() {}
}

export class CloseModalsAction implements Action {
  public readonly type = ProductUsersActionTypes.CloseModals;
  public constructor() {}
}

export type ProductUsersActionsUnion =
  | LoadUsersAction
  | LoadUsersSuccessAction
  | LoadUsersFailedAction
  | LoadUserDetailsAction
  | LoadUserDetailsSuccessAction
  | LoadUserDetailsFailedAction
  | SaveEditedUserAction
  | SaveEditedUserSuccessAction
  | SaveEditedUserFailedAction
  | ResetPasswordAction
  | ResetPasswordSuccessAction
  | ResetPasswordFailedAction
  | UnlockUserAction
  | UnlockUserSuccessAction
  | UnlockUserFailedAction
  | ExportToXLSXAction
  | ExportToXLSXSuccessAction
  | ExportToXLSXFailedAction
  | CloseModalsAction;
