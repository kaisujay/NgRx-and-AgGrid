import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Country } from '@shared/models/countries.model';
import { Observable } from 'rxjs';
import { ProductUserDetails } from '../models/product-user.details';

@Injectable()
export class ProductUsersHttpService {
  public constructor(private http: HttpClient) {}

  public getCountries(): Observable<{ countries: Country[] }> {
    return this.http.get<{ countries: Country[] }>(API.countries);
  }

  public getUserDetails(id: string): Observable<ProductUserDetails> {
    const url = buildApiString(API.productUsers.get, {
      id
    });

    return this.http.get<ProductUserDetails>(url);
  }

  public resetPassword(userId: string): Observable<{ Password: string }> {
    return this.http.put<{ Password: string }>(API.productUsers.resetPassword, {
      UserId: userId
    });
  }

  public unlock(userId: string): Observable<void> {
    return this.http.put<void>(API.productUsers.unlock, { UserId: userId });
  }

  public editUser(user: ProductUserDetails): Observable<any> {
    const url = buildApiString(API.productUsers.edit.put, {
      id: user.Id
    });
    return this.http.put(url, user);
  }
}
