import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { LoadAction } from '@state/actions/container-wrapper.actions';
import { ActivatedRoute, NavigationEnd, Router, RouterEvent } from '@angular/router';
import { filter } from 'rxjs';

@Component({
  selector: 'app-container-wrapper',
  templateUrl: 'container-wrapper.component.html'
})
export class ContainerWrapperComponent implements OnInit {
  public isContainerTabsShown: boolean;
  public activeUrl: string;
  public containerId: string;
  public companyId: string;
  public activeStyle: string;

  public constructor(
    private store$: Store,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  public ngOnInit(): void {
    this.activeUrl = this.route.snapshot['_routerState'].url;
    this.router.events
      .pipe(
        filter(event => {
          return event instanceof NavigationEnd;
        })
      )
      .subscribe((event: RouterEvent) => {
        this.isContainerTabsShown = !event.url.includes('company');
        this.activeUrl = this.route.snapshot['_routerState'].url;
        this.getContainerAndCompanyId(event.url);
      });

    this.store$.dispatch(new LoadAction({ id: this.route.snapshot.paramMap.get('containerId') }));
    this.getContainerAndCompanyId(this.activeUrl);
  }

  public getContainerAndCompanyId(url: string) {
    let splitted = url.split('/');
    this.containerId = splitted[2];
    this.companyId = splitted[4];
    this.activeStyle = splitted[5];
  }

  public goCompanyDetails() {
    this.router.navigate([`/containers/${this.containerId}/company/${this.companyId}/details`]);
  }

  public goCompanyMembers() {
    this.router.navigate([`/containers/${this.containerId}/company/${this.companyId}/members`]);
  }

  public goToCompanyPermissions(): void {
    this.router.navigate([`/containers/${this.containerId}/company/${this.companyId}/permissions`]);
  }

  public goToCompanyConnections(): void {
    this.router.navigate([`/containers/${this.containerId}/company/${this.companyId}/connections`]);
  }

  public goToIntegrationServices(): void {
    this.router.navigate([`/containers/${this.containerId}/company/${this.companyId}/integration`]);
  }
}
