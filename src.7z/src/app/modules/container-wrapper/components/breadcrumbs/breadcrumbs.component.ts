import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { getContainerWrapperState } from '@state/reducers/container-wrapper.reducer';
import { Observable, map } from 'rxjs';
import { CompanyDetailsModalService } from '../../modules/company-details/services/company-details.modal.service';

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: 'breadcrumbs.component.html'
})
export class BreadcrumbsComponent implements OnInit {
  public name$: Observable<string>;
  public containerId$: Observable<string>;
  public companyName: string;
  public constructor(
    private store$: Store,
    public route: Router,
    public modalService: CompanyDetailsModalService
  ) {}
  public ngOnInit(): void {
    this.name$ = this.store$.pipe(
      select(getContainerWrapperState),
      map(containerWrapperState => {
        return containerWrapperState.containerDetails?.Name;
      })
    );

    this.containerId$ = this.store$.pipe(
      select(getContainerWrapperState),
      map(containerWrapperState => {
        return containerWrapperState.containerDetails?.Id;
      })
    );

    this.modalService.shareDataSendCompanyName.subscribe(name => {
      this.companyName = name;
    });
  }

  public showNewName(): Observable<string> {
    return this.modalService.shareDataSendContainerName;
  }
}
