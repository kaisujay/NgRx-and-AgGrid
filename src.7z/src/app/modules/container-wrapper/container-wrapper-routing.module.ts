import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContainerWrapperComponent } from './components/container-wrapper.component';

const routes: Routes = [
  {
    path: '',
    component: ContainerWrapperComponent,
    children: [
      {
        path: 'details',
        loadChildren: () =>
          import('./modules/container-details/container-details.module').then(m => m.ContainerDetailsModule)
      },
      {
        path: 'members',
        loadChildren: () => import('./modules/user-pool/user-pool.module').then(m => m.UserPoolModule)
      },
      {
        path: 'tree',
        loadChildren: () => import('./modules/companies-tree/companies-tree.module').then(m => m.CompaniesTreeModule)
      },
      {
        path: 'company/:companyId/details',
        loadChildren: () => import('./modules/company-details/company-details.module').then(m => m.CompanyDetailsModule)
      },
      {
        path: 'company/:companyId/members',
        loadChildren: () => import('./modules/company-members/company-members.module').then(m => m.CompanyMembersModule)
      },
      {
        path: 'company/:companyId/permissions',
        loadChildren: () =>
          import('./modules/company-permissions/company-permissions.module').then(m => m.CompanyPermissionsModule)
      },
      {
        path: 'company/:companyId/connections',
        loadChildren: () =>
          import('./modules/company-connections/company-connections.module').then(m => m.CompanyConnectionsModule)
      },
      {
        path: 'company/:companyId/integration',
        loadChildren: () =>
          import('./modules/integration-services/integration-services.module').then(m => m.IntegrationServicesModule)
      },
      {
        path: 'ip-whitelist',
        loadChildren: () => import('./modules/ips-whitelist/ips-whitelist.module').then(m => m.IpsWhitelistModule)
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContainerWrapperRoutingModule {}
