import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { IconModule, TabTemplatePanelModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadCompanyDetailsEffect } from '@state/effects/load-company-details.effect';
import { LoadCompanySettingsEffect } from '@state/effects/load-company-settings.effect';
import { containerWrapperReducer } from '@state/reducers/container-wrapper.reducer';
import { AgGridModule } from 'ag-grid-angular';
import { BreadcrumbsComponent } from './components/breadcrumbs/breadcrumbs.component';
import { ContainerWrapperComponent } from './components/container-wrapper.component';
import { ContainerWrapperRoutingModule } from './container-wrapper-routing.module';
import { CompanyDetailsCheckDataService } from './modules/company-details/services/company-details.internal.service';
import { ContainerWrapperHttpService } from './services/container-wrapper-http.service';

@NgModule({
  declarations: [ContainerWrapperComponent, BreadcrumbsComponent],
  imports: [
    CommonModule,
    CoreModule,
    ContainerWrapperRoutingModule,
    AgGridModule.withComponents([]),
    StoreModule.forFeature('containerWrapper', containerWrapperReducer),
    EffectsModule.forFeature([LoadCompanyDetailsEffect, LoadCompanySettingsEffect]),
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    TabTemplatePanelModule,
    IconModule
  ],
  providers: [ContainerWrapperHttpService, CompanyDetailsCheckDataService]
})
export class ContainerWrapperModule {}
