import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { ContainerDetails } from '../models/container-details.model';
import { CompanyDetailsModel } from '../modules/company-details/models/company-details.model';

@Injectable()
export class ContainerWrapperHttpService {
  public constructor(private http: HttpClient) {}
  public get(id: string): Observable<ContainerDetails> {
    const url = buildApiString(API.containers.get, { id });
    return this.http.get<ContainerDetails>(url);
  }

  public getCompanies(id: string): Observable<CompanyDetailsModel> {
    const url = buildApiString(API.companies.get, { id });
    return this.http.get<CompanyDetailsModel>(url);
  }

  public getCompanySettings(companyId: string): Observable<any> {
    return this.http.get(API.companySettings.get.replace(':companyId', companyId));
  }
}
