import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { deepClone, sortObject } from '@core/constants/constants';
import { isNullOrUndefined } from '@core/utils/util';
import { CupcakeFlavors, SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import { CompanyDetailsModalService } from '../../company-details/services/company-details.modal.service';
import {
  LoadContainerDetailsAction,
  LoadContainerStatusAction,
  SaveContainerDetailsAction
} from '../@states/actions/container-details.actions';
import { ContainerDetailsState, getContainerDetailsState } from '../@states/reducers/container-details.reducer';
import { ContainerDetailsModel, ContainerStatusModel } from '../models/container-details.model';

@Component({
  selector: 'app-container-details',
  templateUrl: 'container-details.component.html',
  styleUrls: ['container-details.component.scss']
})
export class ContainerDetailsComponent implements OnInit {
  public containerDetailsFormGroup: FormGroup;
  public containerDetailsState$: Observable<ContainerDetailsState>;

  public containerDetailsPayloadModel: ContainerDetailsModel;
  public initialContainerDetailsResponseModel: ContainerDetailsModel;
  public containerDetailsResponseModel: ContainerDetailsModel;
  public initialContainerStatusModel: ContainerStatusModel[];
  public containerId: string;
  public statusDropdown: SelectOptions[];
  public cupcakeFlavors = CupcakeFlavors;
  public testContainerCheck: boolean;

  public constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private store$: Store,
    private modalService: CompanyDetailsModalService,
    private router: Router
  ) {}

  public ngOnInit(): void {
    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.store$.dispatch(new LoadContainerStatusAction());
    this.store$.dispatch(new LoadContainerDetailsAction(this.containerId));

    this.subscribeToContainerDetailsData();
  }

  public subscribeToContainerDetailsData(): void {
    this.containerDetailsState$ = this.store$.pipe(
      select(getContainerDetailsState),
      tap(state => {
        if (state.containerDetails.isLoadSuccess && state.containerStatus.isLoadSuccess) {
          this.initialContainerDetailsResponseModel = deepClone(state.containerDetails.data);
          this.containerDetailsResponseModel = deepClone(state.containerDetails.data);
          this.initialContainerStatusModel = deepClone(state.containerStatus.data);

          this.prepareStatusDropdown(this.initialContainerStatusModel);

          this.initForm();
        }
        if (state.containerDetails.isSaveSuccess) {
          this.initialContainerDetailsResponseModel = deepClone(state.containerDetails.data);
          this.containerDetailsResponseModel = deepClone(state.containerDetails.data);
          this.modalService.sendContainerName(state.containerDetails.data.Name);
        }
      })
    );
  }

  public initForm() {
    this.containerDetailsFormGroup = this.formBuilder.group({
      Name: new FormControl(this.initialContainerDetailsResponseModel.Name, [
        Validators.required,
        Validators.pattern(/[\S]/)
      ]),
      Status: new FormControl(this.initialContainerDetailsResponseModel.Status),
      IsTestContainer: new FormControl({
        value: this.initialContainerDetailsResponseModel.IsTestContainer,
        disabled: true
      })
    });
    this.testContainerCheck = this.initialContainerDetailsResponseModel.IsTestContainer;
  }

  public prepareStatusDropdown(val: ContainerStatusModel[]) {
    this.statusDropdown = val.map((value, index) => {
      return {
        label: value.Code,
        value: value.Code
      };
    });
  }

  public onSave() {
    this.saveReady();

    this.store$.dispatch(new SaveContainerDetailsAction(this.containerDetailsPayloadModel));
  }

  private saveReady() {
    this.containerDetailsPayloadModel = this.containerDetailsResponseModel;

    if (
      !isNullOrUndefined(this.containerDetailsFormGroup.get('Name').value) &&
      !isNullOrUndefined(this.containerDetailsFormGroup.get('Status').value)
    ) {
      this.containerDetailsPayloadModel.Name = this.containerDetailsFormGroup.get('Name').value;
      this.containerDetailsPayloadModel.Status = this.containerDetailsFormGroup.get('Status').value;
    }

    this.containerDetailsResponseModel = deepClone(this.containerDetailsPayloadModel);
  }

  public isUnsavedChanges() {
    this.saveReady();

    if (!this.containerDetailsFormGroup.valid) {
      return true;
    }

    if (
      JSON.stringify(sortObject(this.initialContainerDetailsResponseModel)) !==
      JSON.stringify(sortObject(this.containerDetailsResponseModel))
    ) {
      return false;
    } else {
      return true;
    }
  }
}
