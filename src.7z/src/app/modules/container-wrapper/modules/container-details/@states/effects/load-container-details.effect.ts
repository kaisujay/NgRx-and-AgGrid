import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainerDetailsModel } from '../../models/container-details.model';
import { ContainerDetailsHttpService } from '../../services/container-details.http.service';
import {
  ContainerDetailsActionTypes,
  LoadContainerDetailsAction,
  LoadContainerDetailsFailedAction,
  LoadContainerDetailsSuccessAction
} from '../actions/container-details.actions';

@Injectable()
export class LoadContainerDetailsEffect {
  public constructor(
    private actions$: Actions,
    private containerDetailsHttpService: ContainerDetailsHttpService
  ) {}
  public loadContainerDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainerDetailsActionTypes.LoadContainerDetails),
      switchMap((action: LoadContainerDetailsAction) =>
        this.containerDetailsHttpService.getContainerDetails(action.containerId).pipe(
          map(data => this.handleSuccess(data)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: ContainerDetailsModel) {
    return new LoadContainerDetailsSuccessAction(res);
  }

  private handleError() {
    return of(new LoadContainerDetailsFailedAction());
  }
}
