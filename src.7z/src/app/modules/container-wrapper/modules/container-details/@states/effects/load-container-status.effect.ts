import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainerStatusModel } from '../../models/container-details.model';
import { ContainerDetailsHttpService } from '../../services/container-details.http.service';
import {
  ContainerDetailsActionTypes,
  LoadContainerStatusAction,
  LoadContainerStatusFailedAction,
  LoadContainerStatusSuccessAction
} from '../actions/container-details.actions';

@Injectable()
export class LoadContainerStatusEffect {
  public constructor(
    private actions$: Actions,
    private containerDetailsHttpService: ContainerDetailsHttpService
  ) {}
  public loadContainerStatusEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainerDetailsActionTypes.LoadContainerStatus),
      switchMap((action: LoadContainerStatusAction) =>
        this.containerDetailsHttpService.getContainerStatus().pipe(
          map(data => this.handleSuccess(data)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: ContainerStatusModel[]) {
    return new LoadContainerStatusSuccessAction(res);
  }

  private handleError() {
    return of(new LoadContainerStatusFailedAction());
  }
}
