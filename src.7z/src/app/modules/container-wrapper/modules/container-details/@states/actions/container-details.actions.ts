import { Action } from '@ngrx/store';
import { ContainerDetailsModel, ContainerStatusModel } from '../../models/container-details.model';

export enum ContainerDetailsActionTypes {
  LoadContainerStatus = '[ContainerDetails] Load Container Status',
  LoadContainerStatusSuccess = '[ContainerDetails] Load Container Status Success',
  LoadContainerStatusFailed = '[ContainerDetails] Load Container Status Failed',

  LoadContainerDetails = '[ContainerDetails] Load Container Details',
  LoadContainerDetailsSuccess = '[ContainerDetails] Load Container Details Success',
  LoadContainerDetailsFailed = '[ContainerDetails] Load Container Details Failed',

  SaveContainerDetails = '[ContainerDetails] Save Container Details',
  SaveContainerDetailsSuccess = '[ContainerDetails] Save Container Details Success',
  SaveContainerDetailsFailed = '[ContainerDetails] Save Container Details Failed'
}

export class LoadContainerStatusAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerStatus;
  public constructor() {}
}

export class LoadContainerStatusSuccessAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerStatusSuccess;
  public constructor(public payload: ContainerStatusModel[]) {}
}

export class LoadContainerStatusFailedAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerStatusFailed;
  public constructor() {}
}

export class LoadContainerDetailsAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerDetails;
  public constructor(public containerId: string) {}
}

export class LoadContainerDetailsSuccessAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerDetailsSuccess;
  public constructor(public payload: ContainerDetailsModel) {}
}

export class LoadContainerDetailsFailedAction implements Action {
  public readonly type = ContainerDetailsActionTypes.LoadContainerDetailsFailed;
  public constructor() {}
}

export class SaveContainerDetailsAction implements Action {
  public readonly type = ContainerDetailsActionTypes.SaveContainerDetails;
  public constructor(public payload: ContainerDetailsModel) {}
}

export class SaveContainerDetailsSuccessAction implements Action {
  public readonly type = ContainerDetailsActionTypes.SaveContainerDetailsSuccess;
  public constructor(public payload: ContainerDetailsModel) {}
}

export class SaveContainerDetailsFailedAction implements Action {
  public readonly type = ContainerDetailsActionTypes.SaveContainerDetailsFailed;
  public constructor() {}
}

export type ContainerDetailsActionsUnion =
  | LoadContainerStatusAction
  | LoadContainerStatusSuccessAction
  | LoadContainerStatusFailedAction
  | LoadContainerDetailsAction
  | LoadContainerDetailsSuccessAction
  | LoadContainerDetailsFailedAction
  | SaveContainerDetailsAction
  | SaveContainerDetailsSuccessAction
  | SaveContainerDetailsFailedAction;
