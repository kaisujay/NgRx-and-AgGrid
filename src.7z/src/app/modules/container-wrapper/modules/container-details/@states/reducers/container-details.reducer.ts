import { createFeatureSelector } from '@ngrx/store';
import { ContainerDetailsModel, ContainerStatusModel } from '../../models/container-details.model';
import { ContainerDetailsActionTypes, ContainerDetailsActionsUnion } from '../actions/container-details.actions';

export interface ContainerDetailsState {
  containerDetails: {
    data: ContainerDetailsModel;
    isLoading: boolean;
    isLoadSuccess: boolean;
    isLoadError: boolean;
    isSaving: boolean;
    isSaveSuccess: boolean;
    isSaveError: boolean;
  };
  containerStatus: {
    data: ContainerStatusModel[];
    isLoading: boolean;
    isLoadSuccess: boolean;
    isLoadError: boolean;
  };
}

export const initialState: ContainerDetailsState = {
  containerDetails: {
    data: null,
    isLoading: false,
    isLoadSuccess: false,
    isLoadError: false,
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  containerStatus: {
    data: null,
    isLoading: false,
    isLoadSuccess: false,
    isLoadError: false
  }
};

export function containerDetailsReducer(
  state: ContainerDetailsState = initialState,
  action: ContainerDetailsActionsUnion
): ContainerDetailsState {
  switch (action.type) {
    case ContainerDetailsActionTypes.LoadContainerStatus:
      return {
        ...state,
        containerStatus: {
          ...state.containerStatus,
          isLoading: true,
          isLoadSuccess: false,
          isLoadError: false
        }
      };

    case ContainerDetailsActionTypes.LoadContainerStatusSuccess:
      return {
        ...state,
        containerStatus: {
          data: action.payload,
          isLoading: false,
          isLoadSuccess: true,
          isLoadError: false
        }
      };

    case ContainerDetailsActionTypes.LoadContainerStatusFailed:
      return {
        ...state,
        containerStatus: {
          ...state.containerStatus,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: true
        }
      };

    case ContainerDetailsActionTypes.LoadContainerDetails:
      return {
        ...state,
        containerDetails: {
          ...state.containerDetails,
          isLoading: true,
          isLoadSuccess: false,
          isLoadError: false,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: false
        }
      };

    case ContainerDetailsActionTypes.LoadContainerDetailsSuccess:
      return {
        ...state,
        containerDetails: {
          data: action.payload,
          isLoading: false,
          isLoadSuccess: true,
          isLoadError: false,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: false
        }
      };

    case ContainerDetailsActionTypes.LoadContainerDetailsFailed:
      return {
        ...state,
        containerDetails: {
          ...state.containerDetails,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: true,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: false
        }
      };

    case ContainerDetailsActionTypes.SaveContainerDetails:
      return {
        ...state,
        containerDetails: {
          ...state.containerDetails,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: false,
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };

    case ContainerDetailsActionTypes.SaveContainerDetailsSuccess:
      return {
        ...state,
        containerDetails: {
          data: action.payload,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: false,
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };

    case ContainerDetailsActionTypes.SaveContainerDetailsFailed:
      return {
        ...state,
        containerDetails: {
          ...state.containerDetails,
          isLoading: false,
          isLoadSuccess: false,
          isLoadError: false,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };

    default:
      return state;
  }
}

export const getContainerDetailsState = createFeatureSelector<ContainerDetailsState>('containerDetails');
