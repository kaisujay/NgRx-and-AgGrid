import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainerDetailsModel } from '../../models/container-details.model';
import { ContainerDetailsHttpService } from '../../services/container-details.http.service';
import {
  ContainerDetailsActionTypes,
  SaveContainerDetailsAction,
  SaveContainerDetailsFailedAction,
  SaveContainerDetailsSuccessAction
} from '../actions/container-details.actions';

@Injectable()
export class SaveContainerDetailsEffect {
  public constructor(
    private actions$: Actions,
    private containerDetailsHttpService: ContainerDetailsHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public saveContainerDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainerDetailsActionTypes.SaveContainerDetails),
      switchMap((action: SaveContainerDetailsAction) =>
        this.containerDetailsHttpService.saveContainerDetails(action.payload).pipe(
          map(data => this.handleSuccess(data)),
          catchError(_err => this.handleError())
        )
      )
    )
  );
  private handleSuccess(res: ContainerDetailsModel) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Container Details saved successfully');
    return new SaveContainerDetailsSuccessAction(res);
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Container Details');
    return of(new SaveContainerDetailsFailedAction());
  }
}
