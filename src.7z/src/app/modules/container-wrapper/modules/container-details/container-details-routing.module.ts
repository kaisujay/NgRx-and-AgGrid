import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContainerDetailsComponent } from './components/container-details.component';
import { ContainerDetailsGuard } from './guards/container-details.guard';

const routes: Routes = [
  {
    path: '',
    component: ContainerDetailsComponent,
    canDeactivate: [ContainerDetailsGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContainerDetailsRoutingModule {}
