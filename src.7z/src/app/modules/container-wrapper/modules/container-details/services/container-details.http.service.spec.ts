import { TestBed } from '@angular/core/testing';

import { ContainerDetailsHttpService } from './container-details.http.service';

describe('ContainerDetailsHttpService', () => {
  let service: ContainerDetailsHttpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContainerDetailsHttpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
