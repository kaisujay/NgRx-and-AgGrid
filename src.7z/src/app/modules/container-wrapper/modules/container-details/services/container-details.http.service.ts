import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { ContainerDetailsModel, ContainerStatusModel } from '../models/container-details.model';

@Injectable()
export class ContainerDetailsHttpService {
  public constructor(private http: HttpClient) {}

  public getContainerStatus(): Observable<ContainerStatusModel[]> {
    const url = buildApiString(API.containers.statuses);
    return this.http.get<ContainerStatusModel[]>(url);
  }

  public getContainerDetails(containerId: string): Observable<ContainerDetailsModel> {
    const url = buildApiString(API.containers.get, { id: containerId });
    return this.http.get<ContainerDetailsModel>(url);
  }

  public saveContainerDetails(payload: ContainerDetailsModel): Observable<ContainerDetailsModel> {
    return this.http.put<ContainerDetailsModel>(API.containers.post, payload);
  }
}
