import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { LoaderModule, SPRFormsModule, SprCommonModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { LoadContainerDetailsEffect } from './@states/effects/load-container-details.effect';
import { LoadContainerStatusEffect } from './@states/effects/load-container-status.effect';
import { SaveContainerDetailsEffect } from './@states/effects/save-container-details.effect';
import { containerDetailsReducer } from './@states/reducers/container-details.reducer';
import { ContainerDetailsComponent } from './components/container-details.component';
import { ContainerDetailsRoutingModule } from './container-details-routing.module';
import { ContainerDetailsGuard } from './guards/container-details.guard';
import { ContainerDetailsHttpService } from './services/container-details.http.service';

@NgModule({
  declarations: [ContainerDetailsComponent],
  imports: [
    CommonModule,
    SprCommonModule,
    SPRFormsModule,
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    CoreModule,
    LoaderModule,
    HttpClientModule,
    ContainerDetailsRoutingModule,
    AgGridModule.withComponents([]),
    StoreModule.forFeature('containerDetails', containerDetailsReducer),
    EffectsModule.forFeature([LoadContainerStatusEffect, LoadContainerDetailsEffect, SaveContainerDetailsEffect])
  ],
  providers: [ContainerDetailsHttpService, ContainerDetailsGuard, DialogService]
})
export class ContainerDetailsModule {}
