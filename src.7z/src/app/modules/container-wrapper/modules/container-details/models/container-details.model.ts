export interface ContainerDetailsModel {
  Id: string;
  Name: string;
  Status: string;
  IsTestContainer: boolean;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
}

export interface ContainerStatusModel {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}
