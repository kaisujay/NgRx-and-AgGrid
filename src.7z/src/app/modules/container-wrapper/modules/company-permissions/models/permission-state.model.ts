export interface CompanyPermissionsState extends CompanyPermissionsResponse {
  isLoading: boolean;
  isError: boolean;
  isDataLoaded: boolean;
  isSaving: boolean;
  isSavingSuccess: boolean;
  isSavingError: boolean;
}

export const FIX_PERMISSIONS_VALUE = {
  FIRM: 'firm',
  FUND: 'fund'
};

export const FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE = {
  AUTO: 'auto',
  MANUAL: 'manual'
};

export const ReleaseFixExecutionsOptions = [
  { key: 'Firm', value: FIX_PERMISSIONS_VALUE.FIRM },
  { key: 'Fund', value: FIX_PERMISSIONS_VALUE.FUND }
];

export const ReleaseFixExecutionsOptionsFirmsPushType = [
  { key: 'Manually Release', value: FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.MANUAL },
  { key: 'Auto-Release', value: FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.AUTO }
];

export enum MultipleOrders {
  singleMultipleOrders = 1,
  minMultipleOrders = 2,
  defaultMaxMultipleOrders = 5
}

export interface CompanyPermissionsResponse {
  CompanyFeaturePermissions: CompanyPermissionsModel;
  CompanySettings?: CompanySettingsModel;
}

export interface UpdateCompanySettingsPermissionsModel {
  Permissions: UpdateCompanyPermissionsModel;
  CompanySettings: UpdateCompanySettingsModel;
}

export interface CompanySettingsModel {
  CompanyId: string;
  Id?: string;
  MaxMultipleOrdersCount: number;
  RowVersion?: string;
}

export interface UpdateCompanyPermissionsModel {
  id: string;
  CompanyFeaturePermissions: CompanyPermissionsModel;
}

export interface UpdateCompanySettingsModel {
  id?: string;
  companyId: string;
  maxMultipleOrdersCount: number;
  rowVersion?: string;
}

export interface CompanyPermissionsModel {
  MunicipalInternalStatusNotApproved: Permission;
  DistributionOrders: Permission;
  ReleaseFixExecutionsFirmAuto: Permission;
  SoftFirmOrders: Permission;
  NewCopyOrdersToClipboard: Permission;
  PrimaryOrderManagement: Permission;
  ReleaseFixExecutionsFirm: Permission;
  EquityDealMonitorV2: Permission;
  AutoReleaseFixExecutions: Permission;
  AggregatedOrderManagement: Permission;
  ActivityStream: Permission;
  TrancheSizeLimitOrder: Permission;
  MunicipalPermissioned: Permission;
  MunicipalInternalStatusInProgress: Permission;
  EquityAllowDealMonitor: Permission;
  MunicipalGroupFollow: Permission;
  EquityOrders: Permission;
  ThinkFolio: Permission;
  ChinaBondDeals: Permission;
  AccountX: Permission;
  EquityOrdersReadOnly: Permission;
  MunicipalAssignments: Permission;
  EquityAnalytics: Permission;
  Orders: Permission;
  DealMonitorEnterprise: Permission;
  MunicipalCommenting: Permission;
  DealQuery: Permission;
  ReleaseFixAllocations: Permission;
  ReadonlyManualOrders: Permission;
  MunicipalInternalStatusApproved: Permission;
  InternalCommentsAndAlerting: Permission;
  OperationalEntities: Permission;
  OrdersMultiple: Permission;
  FixedIncomeAllowDealMonitor: Permission;
  MunicipalMmdData: Permission;
  InternalDealCreate: Permission;
  ReleaseFixExecutionsFirmManual: Permission;
  OrdersReadOnly: Permission;
  MunicipalPublic: Permission;
  EquityDealDatabase: Permission;
  MunicipalStreetCalendar: Permission;
  MunicipalInternalStatusInterested: Permission;
  ManualOrdersOnly: Permission;
  MunicipalDealMonitor: Permission;
  Compliance: Permission;
  FixedIncomeAnalytics: Permission;
  InternalOrderEntry: Permission;
  UnderwritingOrders: Permission;
  EquityDealQuery: Permission;
  ReleaseFixExecutionsFund: Permission;
  BookStateChangeClOrdIDPermissions: Permission;
}

export interface Permission {
  Id: string;
  Enabled: boolean;
  RowVersion: number;
  CreationDate: string;
}
