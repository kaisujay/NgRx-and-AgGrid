import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { CompanyPermissionsService } from '../../services/company-permissions.service';
import {
  CompanyPermissionsActionTypes,
  UpdateCompanyPermissionsAction,
  UpdateCompanyPermissionsFailureAction,
  UpdateCompanyPermissionsSuccessAction
} from '../actions/company-permissions.action';

@Injectable()
export class LoadCompanyPermissionsEffect {
  public constructor(
    private actions$: Actions,
    private _companyPermissionSvc: CompanyPermissionsService
  ) {}

  public updateCompanyPermissionsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyPermissionsActionTypes.UpdateCompanyPermissions),
      switchMap((action: UpdateCompanyPermissionsAction) => {
        return forkJoin([
          this._companyPermissionSvc.updateCompanyPermissions(action.payload.Permissions),
          this._companyPermissionSvc.createOrUpdateCompanySetting(action.payload.CompanySettings)
        ]).pipe(
          map(_ => new UpdateCompanyPermissionsSuccessAction()),
          catchError(_ => of(new UpdateCompanyPermissionsFailureAction()))
        );
      })
    )
  );
}
