import { Action } from '@ngrx/store';
import { CompanyPermissionsResponse, UpdateCompanySettingsPermissionsModel } from '../../models/permission-state.model';

export enum CompanyPermissionsActionTypes {
  LoadCompanyPermissions = '[Company Permissions] Load Company Permissions',
  LoadCompanyPermissionsSuccess = '[Company Permissions] Load Company Permissions Success',
  LoadCompanyPermissionsFailure = '[Company Permissions] Load Company Permissions Failure',
  UpdateCompanyPermissions = '[Company Permissions] Update Company Permissions',
  UpdateCompanyPermissionsSuccess = '[Company Permissions] Update Company Permissions Success',
  UpdateCompanyPermissionsFailure = '[Company Permissions] Update Company Permissions Failure',
  UnsavedActionPermissionOpen = '[Company Permissions] Unsaved Action Permission Open',
  UnsavedActionPermissionSave = '[Company Permissions] Unsaved Action Permission Saved'
}

export class LoadCompanyPermissionsAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.LoadCompanyPermissions;
  public constructor(public id: string) {}
}

export class LoadCompanyPermissionsSuccessAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.LoadCompanyPermissionsSuccess;
  public constructor(public payload: CompanyPermissionsResponse) {}
}

export class LoadCompanyPermissionsFailureAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.LoadCompanyPermissionsFailure;
  public constructor() {}
}

export class UpdateCompanyPermissionsAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.UpdateCompanyPermissions;
  public constructor(public payload: UpdateCompanySettingsPermissionsModel) {}
}

export class UpdateCompanyPermissionsSuccessAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.UpdateCompanyPermissionsSuccess;
  public constructor() {}
}

export class UpdateCompanyPermissionsFailureAction implements Action {
  public readonly type = CompanyPermissionsActionTypes.UpdateCompanyPermissionsFailure;
  public constructor() {}
}

export type CompanyPermissionsActionsUnion =
  | LoadCompanyPermissionsAction
  | LoadCompanyPermissionsSuccessAction
  | LoadCompanyPermissionsFailureAction
  | UpdateCompanyPermissionsAction
  | UpdateCompanyPermissionsSuccessAction
  | UpdateCompanyPermissionsFailureAction;
