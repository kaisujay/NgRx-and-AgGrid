import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, combineLatest, map, of, switchMap } from 'rxjs';
import { CompanyPermissionsService } from '../../services/company-permissions.service';
import {
  CompanyPermissionsActionTypes,
  LoadCompanyPermissionsAction,
  LoadCompanyPermissionsFailureAction,
  LoadCompanyPermissionsSuccessAction
} from '../actions/company-permissions.action';

@Injectable()
export class LoadCompanyPermissionsEffect {
  public constructor(
    private actions$: Actions,
    private _companyPermissionSvc: CompanyPermissionsService
  ) {}

  public loadCompanyPermissionsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyPermissionsActionTypes.LoadCompanyPermissions),
      switchMap((action: LoadCompanyPermissionsAction) => {
        return combineLatest([
          this._companyPermissionSvc.getCompanyPermissions(action.id),
          this._companyPermissionSvc.getCompanySettings(action.id)
        ]).pipe(
          map(data => {
            return new LoadCompanyPermissionsSuccessAction({
              CompanyFeaturePermissions: data[0].CompanyFeaturePermissions,
              CompanySettings: data[1]
            });
          }),
          catchError(_ => {
            return of(new LoadCompanyPermissionsFailureAction());
          })
        );
      })
    )
  );
}
