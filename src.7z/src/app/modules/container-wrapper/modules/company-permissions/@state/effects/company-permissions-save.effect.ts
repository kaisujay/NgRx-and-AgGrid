import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { CompanyPermissionsService } from '../../services/company-permissions.service';
import {
  CompanyPermissionsActionTypes,
  UpdateCompanyPermissionsAction,
  UpdateCompanyPermissionsFailureAction,
  UpdateCompanyPermissionsSuccessAction
} from '../actions/company-permissions.action';

@Injectable()
export class SaveCompanyPermissionsEffect {
  public constructor(
    private actions$: Actions,
    private store$: Store,
    private _companyPermissionSvc: CompanyPermissionsService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public SaveCompanyPermissionsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyPermissionsActionTypes.UpdateCompanyPermissions),
      switchMap((action: UpdateCompanyPermissionsAction) => {
        return forkJoin([
          this._companyPermissionSvc.updateCompanyPermissions(action.payload.Permissions),
          this._companyPermissionSvc.createOrUpdateCompanySetting(action.payload.CompanySettings)
        ]).pipe(
          map(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Permissions saved successfully');
            return new UpdateCompanyPermissionsSuccessAction();
          }),
          catchError(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving permissions');
            return of(new UpdateCompanyPermissionsFailureAction());
          })
        );
      })
    )
  );
}
