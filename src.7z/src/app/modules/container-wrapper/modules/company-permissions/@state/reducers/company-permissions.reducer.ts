import { createFeatureSelector } from '@ngrx/store';
import { CompanyPermissionsState } from '../../models/permission-state.model';
import { CompanyPermissionsActionsUnion, CompanyPermissionsActionTypes } from '../actions/company-permissions.action';

export const permissionInitialState: CompanyPermissionsState = {
  isError: false,
  isLoading: false,
  isSaving: false,
  isSavingError: false,
  isSavingSuccess: false,
  isDataLoaded: false,
  CompanyFeaturePermissions: null,
  CompanySettings: null
};

export function CompanyPermissionsReducer(
  state: CompanyPermissionsState = permissionInitialState,
  action: CompanyPermissionsActionsUnion
): CompanyPermissionsState {
  switch (action.type) {
    case CompanyPermissionsActionTypes.LoadCompanyPermissions: {
      return {
        ...state,
        isLoading: true,
        isSaving: false,
        isSavingError: false,
        isSavingSuccess: false,
        isDataLoaded: false,
        isError: false
      };
    }
    case CompanyPermissionsActionTypes.LoadCompanyPermissionsSuccess: {
      return {
        ...state,
        CompanyFeaturePermissions: action.payload.CompanyFeaturePermissions,
        CompanySettings: action.payload.CompanySettings,
        isLoading: false,
        isDataLoaded: true,
        isError: false
      };
    }
    case CompanyPermissionsActionTypes.LoadCompanyPermissionsFailure: {
      return {
        ...state,
        isLoading: false,
        isDataLoaded: false,
        isError: true,
        CompanyFeaturePermissions: null,
        CompanySettings: null
      };
    }
    case CompanyPermissionsActionTypes.UpdateCompanyPermissions: {
      return {
        ...state,
        isSaving: true,
        isSavingError: false,
        isSavingSuccess: false,
        isLoading: false,
        isDataLoaded: false,
        isError: false
      };
    }
    case CompanyPermissionsActionTypes.UpdateCompanyPermissionsSuccess: {
      return {
        ...state,
        isSaving: false,
        isSavingError: false,
        isLoading: false,
        isSavingSuccess: true,
        isDataLoaded: false,
        isError: true
      };
    }
    case CompanyPermissionsActionTypes.UpdateCompanyPermissionsFailure: {
      return {
        ...state,
        isSaving: false,
        isSavingError: true,
        isSavingSuccess: false,
        isLoading: false,
        isDataLoaded: false,
        isError: true
      };
    }
    default:
      return state;
  }
}

export const getCompanyPermissionsState = createFeatureSelector<CompanyPermissionsState>('companyPermissions');
