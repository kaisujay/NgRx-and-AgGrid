import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { UnsavedChangesAlertComponent } from '@shared/components/unsaved-changes-alert/unsaved-changes-alert.component';
import { UnsavedChangesAlertActions } from '@shared/models/unsaved-change.model';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { Observable, map, of } from 'rxjs';
import { DialogService } from '../../../../../shared/services/dialog/dialog.service';
import { CompanyPermissionsComponent } from '../components/company-permissions/company-permissions.component';

@Injectable()
export class PermissionsCanDeactivateGuard implements CanDeactivate<CompanyPermissionsComponent> {
  public getValue = '';
  public constructor(
    private _dialogSvc: DialogService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public canDeactivate(
    component: CompanyPermissionsComponent,
    _currentRoute: ActivatedRouteSnapshot,
    _currentState: RouterStateSnapshot,
    _nextState: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (component.isUnsavedChanges()) {
      const dialogRef = this._dialogSvc.open(UnsavedChangesAlertComponent);
      return this._dialogSvc.responseFromModal().pipe(
        map(action => {
          if (action === UnsavedChangesAlertActions.DISCARD) {
            dialogRef.close();
            return true;
          } else if (action === UnsavedChangesAlertActions.STAY) {
            dialogRef.close();
            return false;
          } else if (action === UnsavedChangesAlertActions.SAVE) {
            if (component.isDataValid()) {
              component.save();
              dialogRef.close();
              return true;
            }
            this.messageAlertSvc.showMessageAlert(
              CupcakeFlavors.Danger,
              'Validation error, please amend before saving permissions'
            );
            dialogRef.close();
            return false;
          }
          return false;
        })
      );
    }
    return of(true);
  }
}
