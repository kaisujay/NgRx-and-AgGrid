import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { deepClone } from '@core/constants/constants';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import {
  LoadCompanyPermissionsAction,
  UpdateCompanyPermissionsAction
} from '../../@state/actions/company-permissions.action';
import { getCompanyPermissionsState } from '../../@state/reducers/company-permissions.reducer';
import {
  CompanyPermissionsModel,
  CompanyPermissionsState,
  CompanySettingsModel,
  FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE,
  FIX_PERMISSIONS_VALUE,
  MultipleOrders,
  ReleaseFixExecutionsOptions,
  ReleaseFixExecutionsOptionsFirmsPushType,
  UpdateCompanySettingsModel
} from '../../models/permission-state.model';

@Component({
  selector: 'app-company-permissions',
  templateUrl: './company-permissions.component.html',
  styleUrls: ['./company-permissions.component.scss']
})
export class CompanyPermissionsComponent implements OnInit {
  public companyPermissions$: Observable<CompanyPermissionsState>;
  private companyId: string;
  private containerId: string;
  public companyPermissions: CompanyPermissionsModel;
  private initialCompanyPermissions: CompanyPermissionsModel;
  private multipleOrderLimit = MultipleOrders;
  public FIX_PERMISSIONS_VALUE = FIX_PERMISSIONS_VALUE;
  public maxMultipleOrders: FormControl;
  public multipleOrdersEnabled: boolean;
  public initMultipleOrdersEnabled: boolean;
  public releaseFixExecutionsEnabled = false;
  public releaseFixExecutionsOptionsFirmTypes = ReleaseFixExecutionsOptionsFirmsPushType;
  public releaseFixExecutionsOptionsList = ReleaseFixExecutionsOptions;
  public selectedReleaseFixExecutionsModel = null;
  public selectedReleaseFixExecutionsFirmPushTypeModel = null;
  public companySettings: CompanySettingsModel;
  private initialCompanySettings: CompanySettingsModel;
  public showManualOrderAlert: boolean;
  public initMaxMultipleOrders: number;
  public dataLoaded = false;

  public constructor(
    private store$: Store,
    private route: ActivatedRoute
  ) {}

  public ngOnInit(): void {
    this.subscribeToCompanyPermissionData();
    this.companyId = this.route.snapshot.parent.paramMap.get('companyId');
    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.store$.dispatch(new LoadCompanyPermissionsAction(this.companyId));
  }

  public subscribeToCompanyPermissionData(): void {
    this.companyPermissions$ = this.store$.pipe(
      select(getCompanyPermissionsState),
      tap(companyPermissionsState => {
        if (companyPermissionsState.isDataLoaded) {
          this.dataLoaded = true;
          this.companyPermissions = deepClone(companyPermissionsState.CompanyFeaturePermissions);
          this.companySettings = deepClone(companyPermissionsState.CompanySettings);
          this.initialCompanyPermissions = deepClone(companyPermissionsState.CompanyFeaturePermissions);
          this.initialCompanySettings = deepClone(companyPermissionsState.CompanySettings);
          this._initializeReleaseFixExecutionsPermissions();
          this._initializeReleaseFixExecutionsFirmPushTypePermisssions();
          this.prepareMaxMultipleOrderLimit();
          this.initMultipleOrdersEnabled = this.maxMultipleOrders.value > this.multipleOrderLimit.singleMultipleOrders;
          this.multipleOrdersEnabled = this.maxMultipleOrders.value > this.multipleOrderLimit.singleMultipleOrders;
        }
        if (companyPermissionsState.isSavingSuccess) {
          this.store$.dispatch(new LoadCompanyPermissionsAction(this.companyId));
        }
      })
    );
  }

  public prepareMaxMultipleOrderLimit(): void {
    this.initMaxMultipleOrders =
      this.companySettings?.MaxMultipleOrdersCount > this.multipleOrderLimit.singleMultipleOrders
        ? this.companySettings.MaxMultipleOrdersCount
        : null;
    this.maxMultipleOrders = new FormControl(this.initMaxMultipleOrders);
  }

  public setDMRelatedPermissions(isFixedIncomeAllowDealMonitor: boolean) {
    if (!isFixedIncomeAllowDealMonitor) {
      this.companyPermissions['PrimaryOrderManagement'].Enabled = false;
      this.companyPermissions['Orders'].Enabled = false;
      //WARNING: REMOVE FLAG INVERSION AFTER BE WILL BE READY
      this.companyPermissions['ReadonlyManualOrders'].Enabled = true;
      this.companyPermissions['TrancheSizeLimitOrder'].Enabled = false;
      this.companyPermissions['AutoReleaseFixExecutions'].Enabled = false;
      this.companyPermissions['SoftFirmOrders'].Enabled = false;
      this.companyPermissions['AccountX'].Enabled = false;
      this.companyPermissions['ChinaBondDeals'].Enabled = false;
      this.companyPermissions['DistributionOrders'].Enabled = false;
      this.companyPermissions['UnderwritingOrders'].Enabled = false;
      this.companyPermissions['FixedIncomeAnalytics'].Enabled = false;
      this.multipleOrdersEnabled = false;
      this._clearMaxMultipleOrdersError();
      this._disableReleaseFixExecutionsPermissions();
    }
  }

  public _clearMaxMultipleOrdersError(): void {
    this.prepareMaxMultipleOrderLimit();
  }

  public _disableReleaseFixExecutionsPermissions(): void {
    this.releaseFixExecutionsEnabled = false;
    this.selectedReleaseFixExecutionsModel = null;
    this.selectedReleaseFixExecutionsFirmPushTypeModel = null;
    this._changeReleaseFixExecutionsPermissions();
  }

  private _changeReleaseFixExecutionsPermissions() {
    if (this.selectedReleaseFixExecutionsModel === FIX_PERMISSIONS_VALUE.FIRM) {
      this.companyPermissions['ReleaseFixExecutionsFirm'].Enabled = true;
      this.companyPermissions['ReleaseFixExecutionsFund'].Enabled = false;
      this.changeReleaseFixExecutionsFirmPushTypePermissions();
    } else if (this.selectedReleaseFixExecutionsModel === FIX_PERMISSIONS_VALUE.FUND) {
      this.companyPermissions['ReleaseFixExecutionsFirm'].Enabled = false;
      this.companyPermissions['ReleaseFixExecutionsFund'].Enabled = true;
      this._disabeReleaseFixExecutionsFirmPushTypePermissions();
    } else {
      this.companyPermissions['ReleaseFixExecutionsFirm'].Enabled = false;
      this.companyPermissions['ReleaseFixExecutionsFund'].Enabled = false;
      this._disabeReleaseFixExecutionsFirmPushTypePermissions();
    }
  }

  private _disabeReleaseFixExecutionsFirmPushTypePermissions() {
    this.companyPermissions['ReleaseFixExecutionsFirmAuto'].Enabled = false;
    this.companyPermissions['ReleaseFixExecutionsFirmManual'].Enabled = false;
  }

  public changeReleaseFixExecutionsFirmPushTypePermissions() {
    if (this.selectedReleaseFixExecutionsFirmPushTypeModel === FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.AUTO) {
      this.companyPermissions['ReleaseFixExecutionsFirmAuto'].Enabled = true;
      this.companyPermissions['ReleaseFixExecutionsFirmManual'].Enabled = false;
    } else if (this.selectedReleaseFixExecutionsFirmPushTypeModel === FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.MANUAL) {
      this.companyPermissions['ReleaseFixExecutionsFirmAuto'].Enabled = false;
      this.companyPermissions['ReleaseFixExecutionsFirmManual'].Enabled = true;
    } else {
      this._disabeReleaseFixExecutionsFirmPushTypePermissions();
    }
  }

  private _disableChinaDealsPermissions(): void {
    this.companyPermissions['DistributionOrders'].Enabled = false;
    this.companyPermissions['UnderwritingOrders'].Enabled = false;
  }

  public setOrderRelatedPermissions(isOrdersEnabled: boolean): void {
    if (!isOrdersEnabled) {
      this.companyPermissions['ReadonlyManualOrders'].Enabled = true;
      this.companyPermissions['TrancheSizeLimitOrder'].Enabled = false;
      this.companyPermissions['AutoReleaseFixExecutions'].Enabled = false;
      this.companyPermissions['SoftFirmOrders'].Enabled = false;
      this.companyPermissions['AccountX'].Enabled = false;
      this.multipleOrdersEnabled = false;
      // this.companyPermissions['BookStateChangeClOrdIDPermissions'].Enabled = false;
      this.setMultipleOrders(false);
      this._disableReleaseFixExecutionsPermissions();
      this._disableChinaDealsPermissions();
    }

    if (isOrdersEnabled) {
      this.companyPermissions['SoftFirmOrders'].Enabled = true;
    }
  }

  public setMultipleOrders(isMultipleOrdersEnabled: boolean) {
    if (isMultipleOrdersEnabled) {
      if (this.maxMultipleOrders.value === null) {
        this.maxMultipleOrders.setValue(this.initMaxMultipleOrders);
      } else {
        this.maxMultipleOrders.setValue(this.initMaxMultipleOrders);
      }
      this.maxMultipleOrders.addValidators([
        Validators.required,
        Validators.pattern(/^[0-9]\d*$/),
        Validators.min(2),
        Validators.max(999999999)
      ]);
      this.maxMultipleOrders.enable();
    } else {
      this.maxMultipleOrders.reset();
      this.maxMultipleOrders.disable();
    }
  }

  public setReleaseFixExecutionsPermissions(releaseFixExecutionsEnabled: boolean): void {
    if (releaseFixExecutionsEnabled) {
      this.selectedReleaseFixExecutionsModel =
        this.selectedReleaseFixExecutionsModel !== null
          ? this.selectedReleaseFixExecutionsModel
          : FIX_PERMISSIONS_VALUE.FIRM;
      this.selectedReleaseFixExecutionsFirmPushTypeModel =
        this.selectedReleaseFixExecutionsFirmPushTypeModel !== null
          ? this.selectedReleaseFixExecutionsFirmPushTypeModel
          : FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.MANUAL;
      this._changeReleaseFixExecutionsPermissions();
    } else {
      this._disableReleaseFixExecutionsPermissions();
    }
  }

  public changeReleaseFixExecutions(): void {
    this.releaseFixExecutionsEnabled = this.selectedReleaseFixExecutionsModel !== null ? true : false;
    if (this.selectedReleaseFixExecutionsModel === FIX_PERMISSIONS_VALUE.FIRM) {
      this.selectedReleaseFixExecutionsFirmPushTypeModel = FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.MANUAL;
    } else {
      this.selectedReleaseFixExecutionsFirmPushTypeModel = null;
    }
    this.changeReleaseFixExecutionsFirmPushTypePermissions();
  }

  public setEquityDMRelatedPermissions(isEquityAllowDealMonitor: boolean): void {
    if (!isEquityAllowDealMonitor) {
      this.companyPermissions['EquityOrders'].Enabled = false;
      this.companyPermissions['EquityAnalytics'].Enabled = false;
    }
  }

  public setMuniPublicPermissions(isMunicipalPublic: boolean): void {
    if (isMunicipalPublic) {
      this.companyPermissions['MunicipalPermissioned'].Enabled = false;
    }
    this._disableAllMuniPermissions();
  }

  public setMuniPermissionedPermissions(isMunicipalPermissioned: boolean): void {
    if (isMunicipalPermissioned) {
      this.companyPermissions['MunicipalPublic'].Enabled = false;
    }
    this._disableAllMuniPermissions();
  }

  private _disableAllMuniPermissions(): void {
    if (
      !this.companyPermissions['MunicipalPermissioned'].Enabled &&
      !this.companyPermissions['MunicipalPublic'].Enabled
    ) {
      this.companyPermissions['MunicipalStreetCalendar'].Enabled = false;
      this.companyPermissions['MunicipalGroupFollow'].Enabled = false;
      this.companyPermissions['MunicipalCommenting'].Enabled = false;
      this.companyPermissions['MunicipalAssignments'].Enabled = false;
      this.companyPermissions['MunicipalDealMonitor'].Enabled = false;
      this.companyPermissions['MunicipalMmdData'].Enabled = false;
    }
  }

  public setStreetCalendarRelatedPermissions(isStreetCalendarEnabled: boolean): void {
    if (!isStreetCalendarEnabled) {
      this.companyPermissions['MunicipalGroupFollow'].Enabled = false;
      this.companyPermissions['MunicipalCommenting'].Enabled = false;
      this.companyPermissions['MunicipalAssignments'].Enabled = false;
    }
  }

  public enablePOM(isPOMEnabled: boolean): void {
    if (isPOMEnabled) {
      this.companyPermissions['DealMonitorEnterprise'].Enabled = true;
    }
  }

  public _initializeReleaseFixExecutionsPermissions(): void {
    if (this.companyPermissions['ReleaseFixExecutionsFirm'].Enabled) {
      this.releaseFixExecutionsEnabled = true;
      this.selectedReleaseFixExecutionsModel = FIX_PERMISSIONS_VALUE.FIRM;
    } else if (this.companyPermissions['ReleaseFixExecutionsFund'].Enabled) {
      this.releaseFixExecutionsEnabled = true;
      this.selectedReleaseFixExecutionsModel = FIX_PERMISSIONS_VALUE.FUND;
    }
  }

  public _initializeReleaseFixExecutionsFirmPushTypePermisssions(): void {
    if (this.companyPermissions['ReleaseFixExecutionsFirmManual'].Enabled) {
      this.selectedReleaseFixExecutionsFirmPushTypeModel = FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.MANUAL;
    } else if (this.companyPermissions['ReleaseFixExecutionsFirmAuto'].Enabled) {
      this.selectedReleaseFixExecutionsFirmPushTypeModel = FIX_FIRMS_PERMISSIONS_PUSH_TYPE_VALUE.AUTO;
    }
  }

  public enableManualOrdersAlert(): void {
    setTimeout(() => {
      if (
        this.companyPermissions['Orders'].Enabled &&
        this.companyPermissions['PrimaryOrderManagement'].Enabled &&
        this.companyPermissions['ManualOrdersOnly'].Enabled
      ) {
        this.showManualOrderAlert = true;
      }
    }, 0);
  }

  public setChinaBondDealsRelatedPermissions(isChinaBondDealsEnabled: boolean): void {
    if (!isChinaBondDealsEnabled) {
      this.companyPermissions['DistributionOrders'].Enabled = false;
      this.companyPermissions['UnderwritingOrders'].Enabled = false;
    }
  }

  public isUnsavedChanges(): boolean {
    if (this.dataLoaded) {
      return (
        JSON.stringify(this.initialCompanyPermissions) !== JSON.stringify(this.companyPermissions) ||
        JSON.stringify(this.initialCompanySettings) !== JSON.stringify(this.companySettings) ||
        this.initMultipleOrdersEnabled !== this.multipleOrdersEnabled ||
        Number(this.initMaxMultipleOrders) !== Number(this.maxMultipleOrders.value)
      );
    }
    return false;
  }

  public isMultipleOrdersInvalid(): boolean {
    return this.maxMultipleOrders.disabled || this.maxMultipleOrders.valid;
  }

  public save(): void {
    const featurePermissionUpdateRequest = {
      id: this.companyId,
      CompanyFeaturePermissions: this.companyPermissions
    };
    this.store$.dispatch(
      new UpdateCompanyPermissionsAction({
        Permissions: featurePermissionUpdateRequest,
        CompanySettings: this.prepareCompanySettingRequest(this.companySettings?.Id)
      })
    );
  }

  public isDataValid(): boolean {
    return this.maxMultipleOrders.disabled || this.maxMultipleOrders.valid;
  }

  public prepareCompanySettingRequest(id: string): UpdateCompanySettingsModel {
    if (id) {
      return {
        id: this.companySettings.Id,
        companyId: this.companyId,
        maxMultipleOrdersCount: this.maxMultipleOrders.enabled
          ? parseInt(this.maxMultipleOrders.value)
          : this.multipleOrderLimit.singleMultipleOrders,
        rowVersion: this.companySettings.RowVersion
      };
    }
    return {
      companyId: this.companyId,
      maxMultipleOrdersCount: this.maxMultipleOrders.enabled
        ? parseInt(this.maxMultipleOrders.value)
        : this.multipleOrderLimit.singleMultipleOrders
    };
  }
}
