import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyPermissionsComponent } from './components/company-permissions/company-permissions.component';
import { PermissionsCanDeactivateGuard } from './gaurds/permission-deactivate.gaurd';

const routes: Routes = [
  {
    path: '',
    component: CompanyPermissionsComponent,
    canDeactivate: [PermissionsCanDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyPermissionsRoutingModule {}
