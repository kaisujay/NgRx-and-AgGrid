import { TestBed } from '@angular/core/testing';

import { CompanyPermissionsService } from './company-permissions.service';

describe('CompanyPermissionsService', () => {
  let service: CompanyPermissionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CompanyPermissionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
