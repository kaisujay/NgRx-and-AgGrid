import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Observable } from 'rxjs';
import {
  CompanyPermissionsResponse,
  CompanySettingsModel,
  UpdateCompanyPermissionsModel,
  UpdateCompanySettingsModel
} from '../models/permission-state.model';

@Injectable({
  providedIn: 'root'
})
export class CompanyPermissionsService {
  public constructor(private http: HttpClient) {}

  public getCompanyPermissions(companyId: string): Observable<CompanyPermissionsResponse> {
    return this.http.get<CompanyPermissionsResponse>(API.permissions.get.replace(':id', companyId));
  }

  public updateCompanyPermissions(payload: UpdateCompanyPermissionsModel): Observable<void> {
    return this.http.put<void>(API.permissions.update.replace(':id', payload.id), payload);
  }

  public createOrUpdateCompanySetting(payload: UpdateCompanySettingsModel): Observable<CompanySettingsModel> {
    return payload.id ? this.updateCompanySettings(payload) : this.createCompanySettings(payload);
  }

  public createCompanySettings(payload: UpdateCompanySettingsModel): Observable<CompanySettingsModel> {
    return this.http.post<CompanySettingsModel>(
      API.companySettings.create.replace(':companyId', payload.companyId),
      payload
    );
  }

  public updateCompanySettings(payload: UpdateCompanySettingsModel): Observable<CompanySettingsModel> {
    return this.http.put<CompanySettingsModel>(
      API.companySettings.update.replace(':companyId', payload.companyId),
      payload
    );
  }

  public getCompanySettings(companyId: string): Observable<CompanySettingsModel> {
    return this.http.get<CompanySettingsModel>(API.companySettings.get.replace(':companyId', companyId));
  }
}
