import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  AlertModule,
  ButtonModule,
  LoaderModule,
  RadioButtonModule,
  SPRFormsModule,
  SprCommonModule,
  SwitchModule
} from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadCompanyPermissionsEffect } from './@state/effects/company-permissions-load.effect';
import { SaveCompanyPermissionsEffect } from './@state/effects/company-permissions-save.effect';
import { CompanyPermissionsReducer } from './@state/reducers/company-permissions.reducer';
import { CompanyPermissionsRoutingModule } from './company-permissions-routing.module';
import { CompanyPermissionsComponent } from './components/company-permissions/company-permissions.component';
import { PermissionsCanDeactivateGuard } from './gaurds/permission-deactivate.gaurd';
import { CompanyPermissionsService } from './services/company-permissions.service';

@NgModule({
  declarations: [CompanyPermissionsComponent],
  imports: [
    CommonModule,
    FormsModule,
    SPRFormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SwitchModule,
    ButtonModule,
    AdminSharedModule,
    AlertModule,
    SprCommonModule,
    RadioButtonModule,
    LoaderModule,
    StoreModule.forFeature('companyPermissions', CompanyPermissionsReducer),
    CompanyPermissionsRoutingModule,
    EffectsModule.forFeature([LoadCompanyPermissionsEffect, SaveCompanyPermissionsEffect])
  ],
  providers: [CompanyPermissionsService, PermissionsCanDeactivateGuard, DialogService]
})
export class CompanyPermissionsModule {}
