import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardsModule, IconModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { SaveCompanyConnectionVisibiltyEffect } from './@state/effects/company-connection-visibility.effect';
import { LoadCompanyConnectionsEffect } from './@state/effects/company-connections.effects';
import { ConnectToAllBanksEffect } from './@state/effects/connect-to-all-banks.effect';
import { LoadCompanyDetailsEffect } from './@state/effects/load-company-details.effect';
import { CompanyConnectionsReducer } from './@state/reducers/company-connections.reducer';
import { CompanyConnectionsRoutingModule } from './company-connections-routing.module';
import { AdminContactsRendererComponent } from './components/ag-grid-template/admin-contact-renderer/admin-contact-renderer.component';
import { BankNameRendererComponent } from './components/ag-grid-template/bank-name-renderer.component';
import { ConnectionVisibiltyRendererComponent } from './components/ag-grid-template/connection-visibility-renderer/connection-visibilty-renderer.component';
import { CompanyConnectionsComponent } from './components/company-connections/company-connections.component';
import { CompanyConnectionsService } from './services/company-connections.service';

@NgModule({
  declarations: [
    CompanyConnectionsComponent,
    BankNameRendererComponent,
    AdminContactsRendererComponent,
    ConnectionVisibiltyRendererComponent
  ],
  imports: [
    CommonModule,
    SPRFormsModule,
    IconModule,
    CardsModule,
    ReactiveFormsModule,
    FormsModule,
    AdminSharedModule,
    AgGridModule.withComponents([
      BankNameRendererComponent,
      AdminContactsRendererComponent,
      ConnectionVisibiltyRendererComponent,
      ConnectToAllBanksEffect
    ]),
    StoreModule.forFeature('companyConnections', CompanyConnectionsReducer),
    EffectsModule.forFeature([
      LoadCompanyConnectionsEffect,
      SaveCompanyConnectionVisibiltyEffect,
      LoadCompanyDetailsEffect,
      ConnectToAllBanksEffect
    ]),
    CompanyConnectionsRoutingModule
  ],
  providers: [CompanyConnectionsService]
})
export class CompanyConnectionsModule {}
