import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyConnectionsComponent } from './components/company-connections/company-connections.component';

const routes: Routes = [
  {
    path: '',
    component: CompanyConnectionsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyConnectionsRoutingModule {}
