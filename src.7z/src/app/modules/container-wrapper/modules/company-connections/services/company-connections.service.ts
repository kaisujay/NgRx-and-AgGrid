import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { CompanyDetailsModel } from '../../company-details/models/company-details.model';
import {
  CompanyConnection,
  CompanyConnectionPreferencePayload,
  SaveCompanyConnectionVisibiltyPayload
} from '../models/company-connections.model';

@Injectable()
export class CompanyConnectionsService {
  public constructor(private http: HttpClient) {}

  public getCompanies(id: string): Observable<CompanyDetailsModel> {
    const url = buildApiString(API.companies.get, { id });
    return this.http.get<CompanyDetailsModel>(url);
  }

  public saveCompanyConnectionVisibilty(
    payload: Partial<SaveCompanyConnectionVisibiltyPayload>
  ): Observable<CompanyConnection> {
    return this.http.post<CompanyConnection>(API.connections.updateConnection, payload);
  }

  public connectToAllBanks(companyId: string): Observable<unknown> {
    const url = buildApiString(API.connections.connectToAllBanks, { companyId });
    return this.http.post<unknown>(url, { companyId: companyId });
  }

  public deleteConnectionVisibility(payload: SaveCompanyConnectionVisibiltyPayload): Observable<void> {
    const url = buildApiString(API.connections.deleteConnection, {
      sellSideCompanyId: payload.sellSideCompanyOrionId.toString()
    });
    return this.http.delete<void>(url);
  }

  public getCompanyConnectionPreference(companyId: string): Observable<CompanyConnectionPreferencePayload> {
    const url = buildApiString(API.connections.prefernce, { companyId });
    return this.http.get<CompanyConnectionPreferencePayload>(url);
  }

  public saveCompanyConnectionPreference(
    payload: CompanyConnectionPreferencePayload
  ): Observable<CompanyConnectionPreferencePayload> {
    const url = buildApiString(API.connections.prefernce, { companyId: payload.companyId });
    return this.http.put<CompanyConnectionPreferencePayload>(url, payload);
  }

  public updateCompanyConnectionPreference(
    companyId: string,
    payload: CompanyConnectionPreferencePayload
  ): Observable<CompanyConnectionPreferencePayload> {
    const url = buildApiString(API.connections.connectToAllBanks, { companyId });
    return this.http.post<CompanyConnectionPreferencePayload>(url, payload);
  }
}
