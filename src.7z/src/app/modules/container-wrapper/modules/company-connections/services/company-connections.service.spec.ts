import { TestBed } from '@angular/core/testing';

import { CompanyConnectionsService } from './company-connections.service';

describe('CompanyConnectionsService', () => {
  let service: CompanyConnectionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CompanyConnectionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
