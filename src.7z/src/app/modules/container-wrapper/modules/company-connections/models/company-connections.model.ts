export interface CompanyConnectionsResponse {
  page: number;
  pageSize: number;
  statusCount: CompanyConnectionStatusCount;
  totalRecords: number;
  connections: CompanyConnection[];
}

export interface CompanyConnectionStatusCount {
  total: number;
  pending: number;
  noRelationship: number;
  connected: number;
}

export interface SaveCompanyConnectionVisibiltyPayload {
  companyId: string;
  sellSideCompanyOrionId: number;
  isVisibile: boolean;
}

export enum CompanyConnectionBankStatusTypes {
  TOTAL = 'total',
  PENDING = 'pending',
  NO_RELATIONSHIP = 'noRelationship',
  CONNECTED = 'connected'
}

export enum CompanyConnectionBankStatus {
  total = 'All Banks',
  pending = 'Pending',
  noRelationship = 'No Relationship',
  connected = 'Connected'
}

export interface CompanyPreferenceResponse {
  companyId: string;
  rowVersion: string;
  visible: boolean;
}

export interface CompanyConnectionsFetchPayload {
  companyId: string;
  status: string;
}

export interface CompanyConnectionPreferencePayload {
  rowVersion: string;
  visible: boolean;
  companyId: string;
}

export interface CompanyConnectionVisibleClick {
  connection: CompanyConnection;
  isVisible: boolean;
}

export interface CompanyConnection {
  id: number;
  companyId: string;
  sellSideCompanyId: number;
  reportedName: string;
  sellSideAdminContacts: SellsideAdminContact[];
  reportedShortName: string;
  sellSideCountry: string;
  sellSideCity: string;
  status: string;
  lastModifiedDateTime: string;
  tandCIndicator: boolean;
  orderIndicator: boolean;
  isVisible: boolean;
  sellSideCompanyJoinedDateTime: string;
  iaReady: boolean;
  rowVersion: string;
  isNew: boolean;
  isOrderEligible: boolean;
  isTermEligible: boolean;
}

export interface SellsideAdminContact {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  comment: string;
}
