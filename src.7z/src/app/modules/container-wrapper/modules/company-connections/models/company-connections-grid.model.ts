import { dateSortFunction } from '@core/utils/util';
import { CustomLoadingCellRendererComponent } from '@shared/components/loading-cell-renderer/loading-cell-renderer.component';
import { GridOptions } from 'ag-grid-community';
import { AdminContactsRendererComponent } from '../components/ag-grid-template/admin-contact-renderer/admin-contact-renderer.component';
import { BankNameRendererComponent } from '../components/ag-grid-template/bank-name-renderer.component';
import { ConnectionVisibiltyRendererComponent } from '../components/ag-grid-template/connection-visibility-renderer/connection-visibilty-renderer.component';
import { SellsideAdminContact } from './company-connections.model';

export const COMPANY_CONNECTIONS_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'Bank Name',
      tooltipField: 'reportedName',
      field: 'reportedName',
      suppressColumnsToolPanel: true,
      cellRendererFramework: BankNameRendererComponent
    },
    {
      headerName: 'Admin Contact',
      field: 'adminContactCellText',
      cellRendererFramework: AdminContactsRendererComponent,
      valueGetter: params => {
        return (<SellsideAdminContact[]>params.data.sellSideAdminContacts).map(
          contact => `${contact.firstName} ${contact.lastName}, ${contact.email}`
        )[0];
      }
    },
    {
      headerName: 'Country',
      field: 'sellSideCountry',
      tooltipField: 'sellSideCountry'
    },
    {
      headerName: 'City',
      tooltipField: 'sellSideCity',
      field: 'sellSideCity'
    },
    {
      headerName: 'Visibility',
      tooltipField: 'Visibility',
      field: 'isVisible',
      width: 40,
      cellRendererFramework: ConnectionVisibiltyRendererComponent
    },
    {
      headerName: 'Connection Status',
      tooltipField: 'status',
      field: 'status'
    },
    {
      headerName: 'Status Updated',
      tooltipField: 'lastModifiedDateTime',
      field: 'lastModifiedDateTime',
      sort: 'desc',
      comparator: (_, __, nodeA, nodeB) => dateSortFunction(nodeA, nodeB, 'lastModifiedDateTime')
    },
    {
      headerName: 'They Are Sending Me Terms & Conditions',
      wrapText: true,
      field: 'tandCIndicator',
      valueGetter: params => {
        if ('tandCIndicator' in params.data) {
          return params.data['tandCIndicator'] ? 'Yes' : 'No';
        }
        return '';
      },
      minWidth: 200
    },
    {
      headerName: 'They Are Allowing Me to Place Orders',
      field: 'orderIndicator',
      valueGetter: params => {
        if ('orderIndicator' in params.data) {
          return params.data['orderIndicator'] ? 'Yes' : 'No';
        }
        return '';
      },
      minWidth: 200
    }
  ],
  defaultColDef: {
    flex: 1,
    minWidth: 50,
    resizable: true,
    sortable: true
  },
  pagination: true,
  paginationPageSize: 50,
  cacheBlockSize: 50,
  tooltipShowDelay: 1000,
  animateRows: true,
  loadingCellRendererFramework: CustomLoadingCellRendererComponent,
  suppressRowClickSelection: true,
  overlayNoRowsTemplate: 'No records to dispaly',
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressNoRowsOverlay: false,
  suppressLoadingOverlay: false,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true,
  suppressHorizontalScroll: false
};
