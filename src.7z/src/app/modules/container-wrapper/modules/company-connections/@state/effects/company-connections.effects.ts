import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyConnectionsResponse } from '../../models/company-connections.model';
import {
  CompanyConnectionActionTypes,
  LoadCompanyConnectionsAction,
  LoadCompanyConnectionsFailedAction,
  LoadCompanyConnectionsSuccessAction
} from '../actions/company-connections.action';

@Injectable()
export class LoadCompanyConnectionsEffect {
  public constructor(
    private actions$: Actions,
    private kendoAdapterService: KendoAdapterService
  ) {}
  public loadCompanyConnectionEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.LoadCompanyConnections),
      switchMap((action: LoadCompanyConnectionsAction) => {
        return this.kendoAdapterService
          .getConnections<CompanyConnectionsResponse>(
            buildApiString(API.connections.get, { companyId: action.payload.companyId }),
            action.payload.status
          )
          .pipe(
            map(response => {
              return new LoadCompanyConnectionsSuccessAction(response);
            }),
            catchError(_ => of(new LoadCompanyConnectionsFailedAction()))
          );
      })
    )
  );
}
