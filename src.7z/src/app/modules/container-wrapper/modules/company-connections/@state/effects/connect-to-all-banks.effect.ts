import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyConnectionsService } from '../../services/company-connections.service';
import {
  CompanyConnectionActionTypes,
  ConnectToAllBanksAction,
  ConnectToAllBanksFailedAction,
  ConnectToAllBanksSuccessAction
} from '../actions/company-connections.action';

@Injectable()
export class ConnectToAllBanksEffect {
  public constructor(
    private actions$: Actions,
    private companyConnectionSvc: CompanyConnectionsService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public connectToAllBankEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.ConnectToAllBanks),
      switchMap((action: ConnectToAllBanksAction) => {
        return this.companyConnectionSvc.connectToAllBanks(action.companyId).pipe(
          map(_data => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Successfully connected to all banks');
            return new ConnectToAllBanksSuccessAction();
          }),
          catchError(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while connecting to all banks');
            return of(new ConnectToAllBanksFailedAction());
          })
        );
      })
    )
  );
}
