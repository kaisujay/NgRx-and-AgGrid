import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CompanyDetailsModel } from '../../../company-details/models/company-details.model';
import { CompanyConnectionPreferencePayload, CompanyConnectionsResponse } from '../../models/company-connections.model';
import { CompanyConnectionActionTypes, CompanyConnectionsActionsUnion } from '../actions/company-connections.action';

export interface CompanyConnectionsState {
  companyDetailsData: CompanyDetailsState;
  data: CompanyConnectionsResponse;
  isLoading: boolean;
  isLoadSuccess: boolean;
  isError: boolean;
  visibiltyAction: CompanyConnectionSavingState;
  connectToAllBanks: CompanyConnectionSavingState;
  preference: CompanyConnectionPreference;
}

export interface CompanyDetailsState {
  data: CompanyDetailsModel;
  isLoading: boolean;
  isLoaded: boolean;
  isError: boolean;
}

export interface CompanyConnectionPreference extends CompanyConnectionSavingState, CompanyConnectionLoadingState {
  data: CompanyConnectionPreferencePayload;
}

export interface CompanyConnectionSavingState {
  isSaving: boolean;
  isSaveSuccess: boolean;
  isSaveError: boolean;
}

export interface CompanyConnectionLoadingState {
  isLoading: boolean;
  isLoadSuccess: boolean;
  isLoadError: boolean;
}

export const initialConnectionState: CompanyConnectionsState = {
  companyDetailsData: {
    data: null,
    isLoading: false,
    isLoaded: false,
    isError: false
  },
  data: null,
  isLoading: false,
  isLoadSuccess: false,
  isError: false,
  visibiltyAction: {
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  connectToAllBanks: {
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false
  },
  preference: {
    data: null,
    isSaving: false,
    isSaveSuccess: false,
    isSaveError: false,
    isLoading: false,
    isLoadSuccess: false,
    isLoadError: false
  }
};

export function CompanyConnectionsReducer(
  state: CompanyConnectionsState = initialConnectionState,
  action: CompanyConnectionsActionsUnion
): CompanyConnectionsState {
  switch (action.type) {
    case CompanyConnectionActionTypes.LoadCompanyDetails:
      return {
        ...state,
        companyDetailsData: {
          ...state.companyDetailsData,
          isLoading: true,
          isLoaded: false,
          isError: false
        }
      };

    case CompanyConnectionActionTypes.LoadCompanyDetailsSuccess:
      return {
        ...state,
        companyDetailsData: {
          data: {
            ...action.payload
          },
          isLoading: false,
          isLoaded: true,
          isError: false
        }
      };

    case CompanyConnectionActionTypes.LoadCompanyDetailsFailed:
      return {
        ...state,
        companyDetailsData: {
          ...state.companyDetailsData,
          isLoading: false,
          isLoaded: false,
          isError: true
        }
      };

    case CompanyConnectionActionTypes.LoadCompanyConnections:
      return {
        ...state,
        isError: false,
        isLoadSuccess: false,
        isLoading: true,
        data: null
      };
    case CompanyConnectionActionTypes.LoadCompanyConnectionsSuccess:
      return {
        ...state,
        isError: false,
        isLoadSuccess: true,
        isLoading: false,
        data: action.payload
      };
    case CompanyConnectionActionTypes.LoadCompanyConnectionsFailed:
      return {
        ...state,
        isError: true,
        isLoadSuccess: false,
        isLoading: false,
        data: null
      };
    case CompanyConnectionActionTypes.SaveCompanyConnectionVisibilty:
      return {
        ...state,
        visibiltyAction: {
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    case CompanyConnectionActionTypes.SaveCompanyConnectionVisibiltySuccess:
      return {
        ...state,
        visibiltyAction: {
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    case CompanyConnectionActionTypes.SaveCompanyConnectionVisibiltyFailed:
      return {
        ...state,
        visibiltyAction: {
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: true
        }
      };

    case CompanyConnectionActionTypes.ConnectToAllBanks:
      return {
        ...state,
        connectToAllBanks: {
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    case CompanyConnectionActionTypes.ConnectToAllBanksSuccess:
      return {
        ...state,
        connectToAllBanks: {
          isSaving: false,
          isSaveSuccess: true,
          isSaveError: false
        }
      };
    case CompanyConnectionActionTypes.ConnectToAllBanksFailed:
      return {
        ...state,
        connectToAllBanks: {
          isSaving: true,
          isSaveSuccess: false,
          isSaveError: false
        }
      };
    case CompanyConnectionActionTypes.LoadCompanyConnectionPreference:
      return {
        ...state,
        preference: {
          data: null,
          isSaving: false,
          isSaveSuccess: false,
          isSaveError: false,
          isLoading: true,
          isLoadSuccess: false,
          isLoadError: false
        }
      };
    case CompanyConnectionActionTypes.LoadCompanyConnectionPreferenceSuccess:
      return {
        ...state,
        preference: {
          ...state.preference,
          isLoading: false,
          data: action.payload,
          isLoadSuccess: true
        }
      };
    case CompanyConnectionActionTypes.LoadCompanyConnectionPreferenceFailed:
      return {
        ...state,
        preference: {
          ...state.preference,
          isLoading: false,
          data: null,
          isLoadError: true
        }
      };

    case CompanyConnectionActionTypes.SaveCompanyConnectionPreference:
      return {
        ...state,
        preference: {
          ...state.preference,
          isSaving: true,
          isSaveError: false,
          isSaveSuccess: false
        }
      };
    case CompanyConnectionActionTypes.SaveCompanyConnectionPreferenceSuccess:
      return {
        ...state,
        preference: {
          ...state.preference,
          isSaving: false,
          isSaveError: false,
          isSaveSuccess: true,
          data: action.payload
        }
      };
    case CompanyConnectionActionTypes.SaveCompanyConnectionPreferenceFailed:
      return {
        ...state,
        preference: {
          ...state.preference,
          isSaving: false,
          isSaveError: true,
          isSaveSuccess: false
        }
      };

    default:
      return { ...state };
  }
}
export const getCompanyConnectionsState = createFeatureSelector<CompanyConnectionsState>('companyConnections');
export const saveCompanyConnectionVisiblityState = createSelector(
  getCompanyConnectionsState,
  state => state.visibiltyAction
);
export const connectToAllBanksState = createSelector(getCompanyConnectionsState, state => state.connectToAllBanks);
