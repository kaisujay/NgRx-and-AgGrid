import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyConnectionsService } from '../../services/company-connections.service';
import {
  CompanyConnectionActionTypes,
  LoadCompanyConnectionPreferenceAction,
  LoadCompanyConnectionPreferenceFailedAction,
  LoadCompanyConnectionPreferenceSuccessAction,
  SaveCompanyConnectionPreferenceAction,
  SaveCompanyConnectionPreferenceSuccessAction,
  SaveCompanyConnectionVisibiltyAction,
  SaveCompanyConnectionVisibiltyFailedAction,
  SaveCompanyConnectionVisibiltySuccessAction
} from '../actions/company-connections.action';

@Injectable()
export class SaveCompanyConnectionVisibiltyEffect {
  public constructor(
    private actions$: Actions,
    private companyConnectionSvc: CompanyConnectionsService,
    private msgAlertSvc: MessageAlertService
  ) {}
  public saveCompanyConnectionVisibiltyEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.SaveCompanyConnectionVisibilty),
      switchMap((action: SaveCompanyConnectionVisibiltyAction) => {
        if (action.payload.isVisibile) {
          return this.companyConnectionSvc
            .saveCompanyConnectionVisibilty({
              companyId: action.payload.companyId,
              sellSideCompanyOrionId: action.payload.sellSideCompanyOrionId
            })
            .pipe(
              map(_ => {
                this.msgAlertSvc.showMessageAlert(
                  CupcakeFlavors.Success,
                  'Enabled company connection visibility succesfully'
                );
                return new SaveCompanyConnectionVisibiltySuccessAction();
              }),
              catchError(_err => {
                this.msgAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error saving connection visibility');
                return of(new SaveCompanyConnectionVisibiltyFailedAction());
              })
            );
        }
        return this.companyConnectionSvc.deleteConnectionVisibility(action.payload).pipe(
          map(_ => {
            this.msgAlertSvc.showMessageAlert(
              CupcakeFlavors.Success,
              'Disabled company connection visibility succesfully'
            );
            return new SaveCompanyConnectionVisibiltySuccessAction();
          }),
          catchError(_err => {
            this.msgAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error saving connection visibility');
            return of(new SaveCompanyConnectionVisibiltyFailedAction());
          })
        );
      })
    )
  );

  public loadAlwaysVisibleToNewBank$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.LoadCompanyConnectionPreference),
      switchMap((action: LoadCompanyConnectionPreferenceAction) => {
        return this.companyConnectionSvc.getCompanyConnectionPreference(action.companyId).pipe(
          map(data => new LoadCompanyConnectionPreferenceSuccessAction(data)),
          catchError(_err => {
            return of(new LoadCompanyConnectionPreferenceFailedAction());
          })
        );
      })
    )
  );

  public saveAlwaysVisibleToNewBank$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.SaveCompanyConnectionPreference),
      switchMap((action: SaveCompanyConnectionPreferenceAction) => {
        return this.companyConnectionSvc.saveCompanyConnectionPreference(action.payload).pipe(
          map(data => {
            this.msgAlertSvc.showMessageAlert(
              CupcakeFlavors.Success,
              'Saved company connection preference succesfully'
            );
            return new SaveCompanyConnectionPreferenceSuccessAction(data);
          }),
          catchError(_err => {
            this.msgAlertSvc.showMessageAlert(
              CupcakeFlavors.Danger,
              'Error while saving company connection preference'
            );
            return of(new SaveCompanyConnectionVisibiltyFailedAction());
          })
        );
      })
    )
  );
}
