import { Action } from '@ngrx/store';
import { CompanyDetailsModel } from '../../../company-details/models/company-details.model';
import {
  CompanyConnectionPreferencePayload,
  CompanyConnectionsFetchPayload,
  CompanyConnectionsResponse,
  SaveCompanyConnectionVisibiltyPayload
} from '../../models/company-connections.model';

export enum CompanyConnectionActionTypes {
  LoadCompanyDetails = '[Company Connections] Load Company Details',
  LoadCompanyDetailsSuccess = '[Company Connections] Load Company Details Success',
  LoadCompanyDetailsFailed = '[Company Connections] Load Company Details Failed',

  LoadCompanyConnections = '[Company Connections] Load Company Connections',
  LoadCompanyConnectionsSuccess = '[Company Connections] Load Company Connections Success',
  LoadCompanyConnectionsFailed = '[Company Connections] Load Company Connections Failed',

  LoadCompanyConnectionPreference = '[Company Connections] Load Company Connections Preference',
  LoadCompanyConnectionPreferenceSuccess = '[Company Connections] Load Company Connections Preference Success',
  LoadCompanyConnectionPreferenceFailed = '[Company Connections] Load Company Connections Preference Failed',

  SaveCompanyConnectionPreference = '[Company Connections] Save Company Connections Preference',
  SaveCompanyConnectionPreferenceSuccess = '[Company Connections] Save Company Connections Preference Success',
  SaveCompanyConnectionPreferenceFailed = '[Company Connections] Save Company Connections Preference Failed',

  SaveCompanyConnectionVisibilty = '[Company Connections] Save Company Connections Visibilty',
  SaveCompanyConnectionVisibiltySuccess = '[Company Connections] Save Company Connections Visibilty Success',
  SaveCompanyConnectionVisibiltyFailed = '[Company Connections] Save Company Connections Visibilty Failed',

  ConnectToAllBanks = '[Company Connections] Connect to all banks',
  ConnectToAllBanksSuccess = '[Company Connections] Connect to all banks Success',
  ConnectToAllBanksFailed = '[Company Connections] Connect to all banks Failed'
}

export class LoadCompanyDetailsAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyDetails;
  public constructor(public companyId: string) {}
}

export class LoadCompanyDetailsSuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyDetailsSuccess;
  public constructor(public payload: CompanyDetailsModel) {}
}

export class LoadCompanyDetailsFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyDetailsFailed;
  public constructor() {}
}

export class LoadCompanyConnectionsAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnections;
  public constructor(public payload: CompanyConnectionsFetchPayload) {}
}

export class LoadCompanyConnectionsSuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnectionsSuccess;
  public constructor(public payload: CompanyConnectionsResponse) {}
}

export class LoadCompanyConnectionsFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnectionsFailed;
  public constructor() {}
}

export class LoadCompanyConnectionPreferenceAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnectionPreference;
  public constructor(public companyId: string) {}
}

export class LoadCompanyConnectionPreferenceSuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnectionPreferenceSuccess;
  public constructor(public payload: CompanyConnectionPreferencePayload) {}
}

export class LoadCompanyConnectionPreferenceFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.LoadCompanyConnectionPreferenceFailed;
  public constructor() {}
}

export class SaveCompanyConnectionPreferenceAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionPreference;
  public constructor(public payload: CompanyConnectionPreferencePayload) {}
}

export class SaveCompanyConnectionPreferenceSuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionPreferenceSuccess;
  public constructor(public payload: CompanyConnectionPreferencePayload) {}
}

export class SaveCompanyConnectionPreferenceFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionPreferenceFailed;
  public constructor() {}
}

export class SaveCompanyConnectionVisibiltyAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionVisibilty;
  public constructor(public payload: SaveCompanyConnectionVisibiltyPayload) {}
}

export class SaveCompanyConnectionVisibiltySuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionVisibiltySuccess;
  public constructor() {}
}

export class SaveCompanyConnectionVisibiltyFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.SaveCompanyConnectionVisibiltyFailed;
  public constructor() {}
}

export class ConnectToAllBanksAction implements Action {
  public readonly type = CompanyConnectionActionTypes.ConnectToAllBanks;
  public constructor(public companyId: string) {}
}

export class ConnectToAllBanksSuccessAction implements Action {
  public readonly type = CompanyConnectionActionTypes.ConnectToAllBanksSuccess;
  public constructor() {}
}

export class ConnectToAllBanksFailedAction implements Action {
  public readonly type = CompanyConnectionActionTypes.ConnectToAllBanksFailed;
  public constructor() {}
}

export type CompanyConnectionsActionsUnion =
  | LoadCompanyDetailsAction
  | LoadCompanyDetailsSuccessAction
  | LoadCompanyDetailsFailedAction
  | LoadCompanyConnectionsAction
  | LoadCompanyConnectionsSuccessAction
  | LoadCompanyConnectionsFailedAction
  | SaveCompanyConnectionVisibiltyAction
  | SaveCompanyConnectionVisibiltySuccessAction
  | SaveCompanyConnectionVisibiltyFailedAction
  | ConnectToAllBanksAction
  | ConnectToAllBanksFailedAction
  | ConnectToAllBanksSuccessAction
  | LoadCompanyConnectionPreferenceAction
  | LoadCompanyConnectionPreferenceFailedAction
  | LoadCompanyConnectionPreferenceSuccessAction
  | SaveCompanyConnectionPreferenceAction
  | SaveCompanyConnectionPreferenceFailedAction
  | SaveCompanyConnectionPreferenceSuccessAction;
