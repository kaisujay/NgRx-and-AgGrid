import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyConnectionsService } from '../../services/company-connections.service';
import {
  CompanyConnectionActionTypes,
  LoadCompanyDetailsAction,
  LoadCompanyDetailsFailedAction,
  LoadCompanyDetailsSuccessAction
} from '../actions/company-connections.action';

@Injectable()
export class LoadCompanyDetailsEffect {
  public constructor(
    private actions$: Actions,
    private companyConnectionsService: CompanyConnectionsService
  ) {}

  public loadCompanyDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyConnectionActionTypes.LoadCompanyDetails),
      switchMap((action: LoadCompanyDetailsAction) => {
        return this.companyConnectionsService.getCompanies(action.companyId).pipe(
          map(data => new LoadCompanyDetailsSuccessAction(data)),
          catchError(_err => of(new LoadCompanyDetailsFailedAction()))
        );
      })
    )
  );
}
