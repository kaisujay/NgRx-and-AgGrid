import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, _ } from 'ag-grid-community';
import { CompanyConnection } from '../../models/company-connections.model';

@Component({
  template: `
    <div class="c-d-flex c-justify-start c-align-center">
      <ng-container *ngIf="connectionData.iaReady">
        <div class="c-m-right-xs">
          <svg width="16" height="10">
            <rect style="fill:rgb(28,124,214)" x="0" y="0" width="16" height="10" rx="2" />
            <path
              d="M3.34667969,8.5 L4.84570312,1.34179688 L6.31542969,1.34179688 L4.82128906,8.5 L3.34667969,8.5 Z M10.8759766,6.91796875 L8.0390625,6.91796875 L7.1796875,8.5 L5.66601562,8.5 L9.71386719,1.34179688 L11.3496094,1.34179688 L12.5117187,8.5 L11.1152344,8.5 L10.8759766,6.91796875 Z M10.6953125,5.7265625 L10.2802734,2.84570313 L8.55175781,5.7265625 L10.6953125,5.7265625 Z"
              style="fill:rgb(255,255,255)" />
          </svg>
        </div>
      </ng-container>
      <span>{{ connectionData.reportedName }}</span>
    </div>
  `
})
export class BankNameRendererComponent implements ICellRendererAngularComp {
  public connectionData: CompanyConnection;

  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }
  public agInit(_params: ICellRendererParams): void {
    this.connectionData = _params.data;
  }
}
