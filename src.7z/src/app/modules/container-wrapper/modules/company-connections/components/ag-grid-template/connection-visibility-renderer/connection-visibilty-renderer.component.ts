import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  templateUrl: './connection-visibilty-renderer.component.html'
})
export class ConnectionVisibiltyRendererComponent implements ICellRendererAngularComp {
  public isVisible: boolean;
  public connectionParams: ICellRendererParams;
  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }
  public agInit(_params: ICellRendererParams): void {
    this.connectionParams = _params;
    this.isVisible = _params.data && _params.data.isVisible;
  }

  public onClick() {
    setTimeout(() => {
      if (this.connectionParams['onVisibiltyClick'] instanceof Function) {
        this.connectionParams['onVisibiltyClick']({
          connection: this.connectionParams.node.data,
          isVisible: this.isVisible
        });
      }
    }, 0);
  }
}
