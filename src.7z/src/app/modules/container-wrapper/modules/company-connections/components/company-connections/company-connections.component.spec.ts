import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyConnectionsComponent } from './company-connections.component';

describe('CompanyConnectionsComponent', () => {
  let component: CompanyConnectionsComponent;
  let fixture: ComponentFixture<CompanyConnectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CompanyConnectionsComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(CompanyConnectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
