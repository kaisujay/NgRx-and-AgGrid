import { Component, ElementRef } from '@angular/core';
import { PopoverOptions, PopoverService } from '@ipreo/ngx-sprinkles';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { CompanyConnection, SellsideAdminContact } from '../../../models/company-connections.model';

@Component({
  templateUrl: './admin-contact-renderer.component.html',
  styleUrls: ['./admin-contact-renderer.component.scss']
})
export class AdminContactsRendererComponent implements ICellRendererAngularComp {
  public simplePopover: Partial<PopoverOptions<ElementRef>>;
  public connectionData: CompanyConnection;
  public adminContactData: SellsideAdminContact[];
  public adminContactDisplay: string[];

  public constructor(private popoverService: PopoverService) {}

  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }
  public agInit(_params: ICellRendererParams): void {
    this.connectionData = _params.data;
    this.adminContactData = _params.data.sellSideAdminContacts;
    this.adminContactDisplay = this.adminContactData.map(contact =>
      ` ${contact.firstName} ${contact.lastName}, ${contact.phoneNumber}, ${contact.email}`.replaceAll(', ,', ', ')
    );
  }
}
