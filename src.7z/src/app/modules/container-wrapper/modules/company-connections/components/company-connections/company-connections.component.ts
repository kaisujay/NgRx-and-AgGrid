import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { userContext } from '@state/reducers';
import { ColDef, GridApi, GridReadyEvent, RowNode } from 'ag-grid-community';
import { Observable, Subscription, debounceTime, filter, first, fromEvent, switchMap, tap } from 'rxjs';
import { UserSessionContext } from 'src/app/modules/login/models/login.model';
import { CompanyDetailsModalService } from '../../../company-details/services/company-details.modal.service';
import {
  CompanyConnectionActionTypes,
  ConnectToAllBanksAction,
  LoadCompanyConnectionPreferenceAction,
  LoadCompanyConnectionsAction,
  LoadCompanyDetailsAction,
  SaveCompanyConnectionPreferenceAction,
  SaveCompanyConnectionVisibiltyAction
} from '../../@state/actions/company-connections.action';
import {
  CompanyConnectionPreference,
  CompanyConnectionSavingState,
  CompanyConnectionsState,
  connectToAllBanksState,
  getCompanyConnectionsState,
  saveCompanyConnectionVisiblityState
} from '../../@state/reducers/company-connections.reducer';
import { COMPANY_CONNECTIONS_GRID_OPTIONS } from '../../models/company-connections-grid.model';
import {
  CompanyConnection,
  CompanyConnectionBankStatus,
  CompanyConnectionPreferencePayload,
  CompanyConnectionStatusCount,
  CompanyConnectionVisibleClick
} from '../../models/company-connections.model';

@Component({
  selector: 'app-company-connections',
  templateUrl: './company-connections.component.html',
  styleUrls: ['./company-connections.component.scss']
})
export class CompanyConnectionsComponent implements OnInit, AfterViewInit {
  public companyId: string;
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;
  public gridOptions = COMPANY_CONNECTIONS_GRID_OPTIONS;
  public gridApi: GridApi;
  public companyConnectionState$: Observable<CompanyConnectionsState>;
  public bankOptions: SelectOptions[] = [];
  private subscriptions: Subscription[] = [];
  public statusDropdownControl = 'total';
  public alwaysVisibleToNewBank = false;
  public userSessionContext: UserSessionContext;
  public preference: CompanyConnectionPreferencePayload;
  public defaultSortModel = {
    sort: 'desc',
    colId: 'lastModifiedDateTime'
  };
  public rowData: CompanyConnection[] = [];
  public intialStausCount: CompanyConnectionStatusCount;

  public constructor(
    private route: ActivatedRoute,
    private store$: Store,
    private dateFormatSvc: DateFormatService,
    private actions$: Actions,
    private modalService: CompanyDetailsModalService,
    private userContextSvc: UserContextService
  ) {}

  public ngOnInit(): void {
    this.subscribeToUserContext();
    this.subscribeToVisibiltyAction();
    this.subscribeToConnectToAllBanksAction();
    this.bindVisibilityClickEvent();
    this.bindDateFormatFunction();
    this.setExternalFilter();
    this.companyId = this.route.snapshot.paramMap.get('companyId');
    this.store$.dispatch(new LoadCompanyDetailsAction(this.companyId));
    this.subscribeToCompanyState();
    this.loadCompanyConnections();
    this.subscribeToCompanyConnectionState();
    this.store$.dispatch(new LoadCompanyConnectionPreferenceAction(this.companyId));
  }

  private loadCompanyConnections(): void {
    this.store$.dispatch(
      new LoadCompanyConnectionsAction({
        companyId: this.companyId,
        status: this.statusDropdownControl
      })
    );
  }

  private subscribeToCompanyConnectionState() {
    this.store$.pipe(select(getCompanyConnectionsState)).subscribe(data => {
      if (data.companyDetailsData.data !== null) {
        this.modalService.sendCompanyName(data.companyDetailsData.data.Name);
      }
    });
  }

  private setExternalFilter(): void {
    this.gridOptions.isExternalFilterPresent = () => true;
    this.gridOptions.doesExternalFilterPass = params => this.filterCompanyConnections(params);
  }

  private filterCompanyConnections(params: RowNode): boolean {
    const searchString = this.filterTextBox.nativeElement.value.trim().toLowerCase();
    const { reportedName, status } = <CompanyConnection>params.data;
    if (searchString && searchString !== '' && !reportedName.toLowerCase().includes(searchString)) {
      return false;
    }
    const statusFilter = this.statusDropdownControl.toLowerCase();
    return !statusFilter || statusFilter === 'total' || status?.toLowerCase() === statusFilter;
  }

  private subscribeToCompanyState(): void {
    this.companyConnectionState$ = this.store$.pipe(select(getCompanyConnectionsState)).pipe(
      tap(state => {
        if (state.preference.isLoadSuccess) {
          this.preference = state.preference.data;
          this.alwaysVisibleToNewBank = state.preference.data.visible;
        }
      })
    );
  }

  public subscribeToUserContext(): void {
    this.subscriptions.push(
      this.store$.select(userContext).subscribe((state: UserSessionContext) => {
        this.userSessionContext = state;
      })
    );
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        const getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'lastModifiedDateTime'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['lastModifiedDateTime'], format);
        };
      })
    );
  }

  private bindVisibilityClickEvent(): void {
    const getVisibilityIndex = this.gridOptions.columnDefs.findIndex(colDef => (<ColDef>colDef).field === 'isVisible');
    (<ColDef>this.gridOptions.columnDefs[getVisibilityIndex]).cellRendererParams = {
      onVisibiltyClick: this.onVisibilityClick.bind(this)
    };
  }

  public subscribeToVisibiltyAction(): void {
    this.subscriptions.push(
      this.store$
        .select(saveCompanyConnectionVisiblityState)
        .subscribe((visibltyState: CompanyConnectionSavingState) => {
          if (this.gridApi) {
            if (visibltyState.isSaving) {
              this.gridApi.showLoadingOverlay();
            }
            if (visibltyState.isSaveSuccess || visibltyState.isSaveError) {
              this.gridApi.hideOverlay();
              if (visibltyState.isSaveSuccess) {
                this.gridApi.refreshServerSideStore({ route: null, purge: false });
              }
            }
          }
        })
    );
  }

  public subscribeToConnectToAllBanksAction(): void {
    this.subscriptions.push(
      this.store$.select(connectToAllBanksState).subscribe((connecToState: CompanyConnectionPreference) => {
        if (this.gridApi) {
          if (connecToState.isSaving) {
            this.gridApi.showLoadingOverlay();
          }
          if (connecToState.isSaveSuccess || connecToState.isSaveError) {
            this.gridApi.hideOverlay();
            if (connecToState.isSaveSuccess) {
              this.gridApi.refreshServerSideStore({ route: null, purge: false });
            }
          }
        }
      })
    );
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.subscriptions.push(
      this.actions$
        .pipe(
          filter(action => action.type === CompanyConnectionActionTypes.LoadCompanyConnectionsSuccess),
          switchMap(() => this.store$.select(getCompanyConnectionsState)),
          first()
        )
        .subscribe(state => {
          this.intialStausCount = state.data.statusCount;
          this.gridApi.hideOverlay();
          this.bankOptions = [];
          this.prepareBankStatusCountDropdown(state.data.statusCount);
          this.rowData = state.data.connections;
          this.gridApi?.setRowData(this.rowData);
        })
    );
  }

  public onVisibilityClick(event: CompanyConnectionVisibleClick): void {
    this.store$.dispatch(
      new SaveCompanyConnectionVisibiltyAction({
        companyId: this.companyId,
        sellSideCompanyOrionId: !event.isVisible ? event.connection.id : event.connection.sellSideCompanyId,
        isVisibile: event.isVisible
      })
    );
  }

  public ngAfterViewInit(): void {
    this.subscriptions.push(
      fromEvent(this.filterTextBox.nativeElement, 'input')
        .pipe(debounceTime(500))
        .subscribe(() => {
          this.gridApi.onFilterChanged();
          setTimeout(() => {
            let statusCount;
            if (this.filterTextBox.nativeElement.value === '') {
              statusCount = { ...this.intialStausCount };
            } else {
              statusCount = {
                connected: 0,
                noRelationship: 0,
                pending: 0,
                total: 0
              } as CompanyConnectionStatusCount;
              this.gridOptions.api.getRenderedNodes().forEach((node: RowNode) => {
                statusCount[node.data.status.toLowerCase()] += 1;
                statusCount.total += 1;
              });
            }
            this.bankOptions = [];
            this.prepareBankStatusCountDropdown(statusCount);
          }, 0);
        })
    );
  }

  public onStatusChange(): void {
    this.gridApi.onFilterChanged();
  }

  public prepareBankStatusCountDropdown(statusCount: CompanyConnectionStatusCount): void {
    Object.keys(CompanyConnectionBankStatus).forEach(key => {
      this.bankOptions.push({
        label: `${CompanyConnectionBankStatus[key]} (${statusCount[key]})`,
        value: key
      });
    });
  }

  public onAlwaysVisibleToNewBankChange(): void {
    this.store$.dispatch(
      new SaveCompanyConnectionPreferenceAction({
        companyId: this.companyId,
        visible: this.alwaysVisibleToNewBank,
        rowVersion: this.preference.rowVersion
      })
    );
  }

  public onConnectToAllBanks(): void {
    this.store$.dispatch(new ConnectToAllBanksAction(this.companyId));
  }
}
