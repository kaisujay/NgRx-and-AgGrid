export interface IpsWhitelistModel {
  IpListText: string;
  IsWhitelistEnabled: boolean;
  LastModifiedBy: string;
}

export interface UpdateIpsWhitelistModel {
  ipListText: string;
  isWhitelistEnabled: boolean;
}
