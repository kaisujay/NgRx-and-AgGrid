import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { IpsWhitelistModel, UpdateIpsWhitelistModel } from '../models/ips-whitelist.model';

@Injectable()
export class IpsWhitelistHttpService {
  public constructor(private http: HttpClient) {}

  public getIpsWhitelist(id: string): Observable<IpsWhitelistModel> {
    const url = buildApiString(API.ipWhitelist, {
      id
    });

    return this.http.get<IpsWhitelistModel>(url);
  }

  public setIpsWhitelist(id: string, ipsWhitelist: UpdateIpsWhitelistModel): Observable<IpsWhitelistModel> {
    const url = buildApiString(API.ipWhitelist, {
      id
    });

    return this.http.put<IpsWhitelistModel>(url, ipsWhitelist);
  }
}
