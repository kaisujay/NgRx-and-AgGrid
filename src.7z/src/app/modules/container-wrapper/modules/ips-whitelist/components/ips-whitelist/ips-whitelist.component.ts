import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import {
  ClearIpsWhitelistHttpErrorsAction,
  LoadIpsWhitelistAction,
  SaveIpsWhitelistAction
} from '../../@states/actions/ips-whitelist.action';
import { IpsWhitelistState, getIpsWhitelistStateState } from '../../@states/reducers/ips-whitelist.reducer';
import { IpsWhitelistModel, UpdateIpsWhitelistModel } from '../../models/ips-whitelist.model';
import { IpsWhitelistHttpService } from '../../services/ips-whitelist.http.service';

@Component({
  selector: 'app-ips-whitelist',
  templateUrl: './ips-whitelist.component.html',
  styleUrls: ['./ips-whitelist.component.scss']
})
export class IpsWhitelistComponent implements OnInit, DoCheck {
  public iPsWhitelistFormGroup: FormGroup;
  public ipsWhitelistState$: Observable<IpsWhitelistState>;
  public ipsWhitelistStateValue: IpsWhitelistState;
  public updateIpsWhitelist: UpdateIpsWhitelistModel;
  public tempIpsWhitelist: IpsWhitelistModel;
  public initialIpsWhitelist: IpsWhitelistModel;

  public containerId: string;
  public shouldErrorLabelBeDisabled: boolean;
  public shouldButtonsBeDisabled: boolean;
  public textVal: string;

  public constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private service: IpsWhitelistHttpService,
    private store$: Store
  ) {}

  public ngDoCheck(): void {
    this.tempIpsWhitelist = {
      IpListText: this.iPsWhitelistFormGroup.get('IpListText').value,
      IsWhitelistEnabled: this.iPsWhitelistFormGroup.get('IsWhitelistEnabled').value,
      LastModifiedBy: null
    };

    if (JSON.stringify(this.initialIpsWhitelist) === JSON.stringify(this.tempIpsWhitelist)) {
      this.shouldButtonsBeDisabled = false;
    } else if (
      this.iPsWhitelistFormGroup.get('IpListText').value == '' &&
      this.iPsWhitelistFormGroup.get('IsWhitelistEnabled').value == false
    ) {
      this.shouldButtonsBeDisabled = true;
    } else {
      this.shouldButtonsBeDisabled = true;
    }
  }

  public ngOnInit(): void {
    this.subscribeToAnalyticsData();
    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.initForm();

    this.ipsWhitelistState$ = this.store$.pipe(select(getIpsWhitelistStateState));
    this.store$.pipe(select(getIpsWhitelistStateState)).subscribe(data => {
      this.updateFormValue(data);
    });

    this.store$.dispatch(new LoadIpsWhitelistAction(this.containerId));
  }

  public subscribeToAnalyticsData() {
    this.ipsWhitelistState$ = this.store$.pipe(
      select(getIpsWhitelistStateState),
      tap(state => {
        if (state.isLoaded) {
          this.updateFormValue(state);
        }
        if (state.isSaved) {
          this.store$.dispatch(new LoadIpsWhitelistAction(this.containerId));
        }
      })
    );
  }

  public initForm() {
    this.iPsWhitelistFormGroup = this.formBuilder.group({
      IsWhitelistEnabled: new FormControl(false),
      IpListText: new FormControl('')
    });
  }

  public updateFormValue(data: IpsWhitelistState) {
    if (data.ipsWhitelistModel != null) {
      this.iPsWhitelistFormGroup.controls['IsWhitelistEnabled'].setValue(data.ipsWhitelistModel.IsWhitelistEnabled);
      this.iPsWhitelistFormGroup.controls['IpListText'].setValue(data.ipsWhitelistModel.IpListText);

      if (data.ipsWhitelistModel.IsWhitelistEnabled) {
        this.iPsWhitelistFormGroup.get('IpListText').enable();
      } else {
        this.iPsWhitelistFormGroup.get('IpListText').disable();
      }

      this.initialIpsWhitelist = {
        IpListText: this.iPsWhitelistFormGroup.get('IpListText').value,
        IsWhitelistEnabled: this.iPsWhitelistFormGroup.get('IsWhitelistEnabled').value,
        LastModifiedBy: null
      };

      this.shouldErrorLabelBeDisabled = data.ipsWhitelistModel.IsWhitelistEnabled;
    }
  }

  public saveIpsWhitelist() {
    this.updateIpsWhitelist = {
      ipListText: this.iPsWhitelistFormGroup.get('IpListText').value,
      isWhitelistEnabled: this.iPsWhitelistFormGroup.get('IsWhitelistEnabled').value
    };

    this.store$.dispatch(new SaveIpsWhitelistAction(this.containerId, this.updateIpsWhitelist));
  }

  public isChecked(event) {
    const isChecked = event.target.checked;

    if (isChecked) {
      this.shouldErrorLabelBeDisabled = true;
      this.iPsWhitelistFormGroup.get('IpListText').enable();
    } else {
      this.shouldErrorLabelBeDisabled = false;
      this.iPsWhitelistFormGroup.get('IpListText').disable();
    }
  }

  public cancelForm() {
    this.store$.pipe(select(getIpsWhitelistStateState)).subscribe(data => {
      this.updateFormValue(data);

      if (data.ipsWhitelistModel.IsWhitelistEnabled) {
        this.iPsWhitelistFormGroup.get('IpListText').enable();
      } else {
        this.iPsWhitelistFormGroup.get('IpListText').disable();
      }
    });
  }

  public onErrorModalClose() {
    this.store$.dispatch(new ClearIpsWhitelistHttpErrorsAction());
  }
}
