import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule, LoaderModule, SPRFormsModule, SprCommonModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadIpsWhitelistEffect } from './@states/effects/load-ips-whitelist.effect';
import { SaveIpsWhitelistEffect } from './@states/effects/save-ips-whitelist.effect';
import { IpsWhitelistReducer } from './@states/reducers/ips-whitelist.reducer';
import { IpsWhitelistComponent } from './components/ips-whitelist/ips-whitelist.component';
import { IpsWhitelistRoutingModule } from './ips-whitelist-routing.module';
import { IpsWhitelistHttpService } from './services/ips-whitelist.http.service';

@NgModule({
  declarations: [IpsWhitelistComponent],
  imports: [
    CommonModule,
    SprCommonModule,
    FormsModule,
    ReactiveFormsModule,
    LoaderModule,
    SPRFormsModule,
    CheckboxModule,
    IpsWhitelistRoutingModule,
    StoreModule.forFeature('ipsWhitelists', IpsWhitelistReducer),
    EffectsModule.forFeature([LoadIpsWhitelistEffect, SaveIpsWhitelistEffect]),
    AdminSharedModule
  ],
  providers: [IpsWhitelistHttpService]
})
export class IpsWhitelistModule {}
