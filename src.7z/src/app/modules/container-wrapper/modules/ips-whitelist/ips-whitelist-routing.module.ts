import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IpsWhitelistComponent } from './components/ips-whitelist/ips-whitelist.component';

const routes: Routes = [
  {
    path: '',
    component: IpsWhitelistComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IpsWhitelistRoutingModule {}
