import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { IpsWhitelistModel } from '../../models/ips-whitelist.model';
import { IpsWhitelistHttpService } from '../../services/ips-whitelist.http.service';
import {
  IpsWhitelistActionTypes,
  SaveIpsWhitelistAction,
  SaveIpsWhitelistFailedAction,
  SaveIpsWhitelistSuccessAction
} from '../actions/ips-whitelist.action';

@Injectable()
export class SaveIpsWhitelistEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private ipsWhitelistHttpService: IpsWhitelistHttpService
  ) {}

  public saveIpsWhitelistEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(IpsWhitelistActionTypes.SaveIpsWhitelist),
      switchMap((action: SaveIpsWhitelistAction) => {
        return this.ipsWhitelistHttpService.setIpsWhitelist(action.id, action.saveModel).pipe(
          map(response => this.handleSuccess(response)),
          catchError(error => this.handleError(error))
        );
      })
    )
  );

  private handleSuccess(response: IpsWhitelistModel) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Ips Whitelist saved successfully');
    return new SaveIpsWhitelistSuccessAction(response);
  }

  private handleError(error) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving IPs Whitelist');
    return of(new SaveIpsWhitelistFailedAction(error));
  }
}
