import { Action } from '@ngrx/store';
import { IpsWhitelistModel, UpdateIpsWhitelistModel } from '../../models/ips-whitelist.model';

export enum IpsWhitelistActionTypes {
  LoadIpsWhitelist = '[Ips Whitelist] Load Ips Whitelist',
  LoadIpsWhitelistSuccess = '[Ips Whitelist] Load Ips Whitelist Success',
  LoadIpsWhitelistFailed = '[Ips Whitelist] Load Ips Whitelist Failed',

  SaveIpsWhitelist = '[Ips Whitelist] Save Ips Whitelist',
  SaveIpsWhitelistSuccess = '[Ips Whitelist] Save Ips Whitelist Success',
  SaveIpsWhitelistFailed = '[Ips Whitelist] Save Ips Whitelist Failed',

  ClearIpsWhitelistHttpErrors = '[Ips Whitelist] Clear Ips Whitelist Http Errors'
}

export class LoadIpsWhitelistAction implements Action {
  public readonly type = IpsWhitelistActionTypes.LoadIpsWhitelist;
  public constructor(public id: string) {}
}

export class LoadIpsWhitelistSuccessAction implements Action {
  public readonly type = IpsWhitelistActionTypes.LoadIpsWhitelistSuccess;
  public constructor(public payload: IpsWhitelistModel) {}
}

export class LoadIpsWhitelistFailedAction implements Action {
  public readonly type = IpsWhitelistActionTypes.LoadIpsWhitelistFailed;
  public constructor() {}
}

export class SaveIpsWhitelistAction implements Action {
  public readonly type = IpsWhitelistActionTypes.SaveIpsWhitelist;
  public constructor(
    public id: string,
    public saveModel: UpdateIpsWhitelistModel
  ) {}
}

export class SaveIpsWhitelistSuccessAction implements Action {
  public readonly type = IpsWhitelistActionTypes.SaveIpsWhitelistSuccess;
  public constructor(public payload: IpsWhitelistModel) {}
}

export class SaveIpsWhitelistFailedAction implements Action {
  public readonly type = IpsWhitelistActionTypes.SaveIpsWhitelistFailed;
  public constructor(public error: string) {}
}

export class ClearIpsWhitelistHttpErrorsAction implements Action {
  public readonly type = IpsWhitelistActionTypes.ClearIpsWhitelistHttpErrors;
  public constructor() {}
}

export type IpsWhitelistActionsUnion =
  | LoadIpsWhitelistAction
  | LoadIpsWhitelistSuccessAction
  | LoadIpsWhitelistFailedAction
  | SaveIpsWhitelistAction
  | SaveIpsWhitelistSuccessAction
  | SaveIpsWhitelistFailedAction
  | ClearIpsWhitelistHttpErrorsAction;
