import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { IpsWhitelistActionTypes } from '../actions/ips-whitelist.action';
import {
  LoadIpsWhitelistAction,
  LoadIpsWhitelistSuccessAction,
  LoadIpsWhitelistFailedAction
} from '../actions/ips-whitelist.action';
import { IpsWhitelistHttpService } from '../../services/ips-whitelist.http.service';

@Injectable()
export class LoadIpsWhitelistEffect {
  public constructor(
    private actions$: Actions,
    private ipsWhitelistHttpService: IpsWhitelistHttpService
  ) {}

  public loadIpsWhitelistEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(IpsWhitelistActionTypes.LoadIpsWhitelist),
      switchMap((action: LoadIpsWhitelistAction) => {
        return this.ipsWhitelistHttpService.getIpsWhitelist(action.id).pipe(
          map(data => new LoadIpsWhitelistSuccessAction(data)),
          catchError(_err => of(new LoadIpsWhitelistFailedAction()))
        );
      })
    )
  );
}
