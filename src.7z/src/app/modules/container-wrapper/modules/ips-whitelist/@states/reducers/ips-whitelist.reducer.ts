import { createFeatureSelector } from '@ngrx/store';
import { IpsWhitelistModel } from '../../models/ips-whitelist.model';
import { IpsWhitelistActionTypes, IpsWhitelistActionsUnion } from '../actions/ips-whitelist.action';

export interface IpsWhitelistState {
  ipsWhitelistModel: IpsWhitelistModel;
  isLoading: boolean;
  isLoaded: boolean;
  isLoadError: boolean;
  isSaving: boolean;
  isSaved: boolean;
  isSaveError: boolean;
  errorMessage: string;
}

export const initialState: IpsWhitelistState = {
  ipsWhitelistModel: null,
  isLoading: false,
  isLoaded: false,
  isLoadError: false,
  isSaving: false,
  isSaved: false,
  isSaveError: false,
  errorMessage: null
};

export function IpsWhitelistReducer(
  state: IpsWhitelistState = initialState,
  action: IpsWhitelistActionsUnion
): IpsWhitelistState {
  switch (action.type) {
    case IpsWhitelistActionTypes.LoadIpsWhitelist:
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
        isLoadError: false,
        isSaving: false,
        isSaved: false,
        isSaveError: false
      };

    case IpsWhitelistActionTypes.LoadIpsWhitelistSuccess:
      return {
        ...state,
        ipsWhitelistModel: {
          ...action.payload
        },
        isLoading: false,
        isLoaded: true,
        isLoadError: false,
        isSaving: false,
        isSaved: false,
        isSaveError: false
      };

    case IpsWhitelistActionTypes.LoadIpsWhitelistFailed:
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        isLoadError: true,
        isSaving: false,
        isSaved: false,
        isSaveError: false
      };

    case IpsWhitelistActionTypes.SaveIpsWhitelist:
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        isLoadError: false,
        isSaving: true,
        isSaved: false,
        isSaveError: false,
        errorMessage: null
      };

    case IpsWhitelistActionTypes.SaveIpsWhitelistSuccess:
      return {
        ...state,
        ipsWhitelistModel: {
          ...action.payload
        },
        isLoading: false,
        isLoaded: false,
        isLoadError: false,
        isSaving: false,
        isSaved: true,
        isSaveError: false,
        errorMessage: null
      };

    case IpsWhitelistActionTypes.SaveIpsWhitelistFailed:
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        isLoadError: false,
        isSaving: false,
        isSaved: false,
        isSaveError: true,
        errorMessage: action.error
      };

    case IpsWhitelistActionTypes.ClearIpsWhitelistHttpErrors:
      return {
        ...state,
        ipsWhitelistModel: {
          ...state.ipsWhitelistModel
        },
        errorMessage: null
      };

    default:
      return state;
  }
}

export const getIpsWhitelistStateState = createFeatureSelector<IpsWhitelistState>('ipsWhitelists');
