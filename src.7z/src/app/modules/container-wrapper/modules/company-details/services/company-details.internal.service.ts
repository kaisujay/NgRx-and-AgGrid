import { Injectable } from '@angular/core';
import { UpdateCompanyDetailsCheck } from '../models/company-details.model';

@Injectable()
export class CompanyDetailsCheckDataService {
  public companyData: UpdateCompanyDetailsCheck;

  public dataService(data: UpdateCompanyDetailsCheck) {
    this.companyData = data;
  }
}
