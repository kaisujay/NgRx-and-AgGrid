import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompanyDetailsModalService {
  private behaviorSubjectSendCompanyName = new BehaviorSubject<string>('');
  public shareDataSendCompanyName = this.behaviorSubjectSendCompanyName.asObservable();

  private behaviorSubjectSendContainerName = new BehaviorSubject<string>('');
  public shareDataSendContainerName = this.behaviorSubjectSendContainerName.asObservable();

  public constructor() {}

  public sendCompanyName(value: string) {
    this.behaviorSubjectSendCompanyName.next(value);
  }

  public sendContainerName(value: string) {
    this.behaviorSubjectSendContainerName.next(value);
  }
}
