import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  CompanyDetailsModel,
  ContainersModel,
  ReceivedCompanyDetails,
  UpdateCompanyDetails
} from '../models/company-details.model';
import { Observable } from 'rxjs';
import { API, buildApiString } from '@core/constants/API';

@Injectable()
export class CompanyDetailsHttpService {
  public constructor(private http: HttpClient) {}

  public getCompanyDetails(id: string): Observable<CompanyDetailsModel> {
    const url = buildApiString(API.companies.get, { id });

    return this.http.get<CompanyDetailsModel>(url);
  }

  public saveCompanyDetails(id: string, data: UpdateCompanyDetails): Observable<CompanyDetailsModel> {
    const url = buildApiString(API.companies.put, { id });

    return this.http.put<CompanyDetailsModel>(url, data);
  }

  public getCompany(containerId: string): Observable<ContainersModel[]> {
    const url = buildApiString(API.company.get, { containerId });

    return this.http.get<ContainersModel[]>(url);
  }

  public syncCompanyName(id: string): Observable<void> {
    const url = buildApiString(API.sync.syncCompanyName.put, { id });

    return this.http.put<void>(url, id);
  }

  public syncPMIDandLEI(id: string): Observable<void> {
    const url = buildApiString(API.sync.syncPMIDandLEI.put, { id });

    return this.http.put<void>(url, id);
  }
}
