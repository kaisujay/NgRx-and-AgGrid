export class CompanyDetailsService {
  public static getOptions<T>(settings: T[], label: string, value: string): { label: string; value: string }[] {
    if (!settings || !settings.length) {
      return [];
    }
    return settings.map(setting => {
      return {
        label: setting[label],
        value: setting[value]
      };
    });
  }
}
