import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { SPRFormsModule, SprCommonModule, TabTemplatePanelModule } from '@ipreo/ngx-sprinkles';
import { CompanyDetailsRoutingModule } from './company-details-routing.module';
import { CompanyDetailsComponent } from './components/company-details.component';

import { FormsModule } from '@angular/forms';
import { CanDeactivateGuard } from '@core/gaurds/can-deactivate.guard';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { AdminSharedModule } from '@shared/shared.module';
import { LoadCompanyDetailsEffect } from './@state/effects/company-details.load.effect';
import { SaveCompanyDetailsEffect } from './@state/effects/company-details.save.effect';
import { LoadContainerDetailsEffect } from './@state/effects/container-details.load.effect';
import { SyncCompanyNameEffect } from './@state/effects/sync-company.effect';
import { SyncPMIDandLEIEffect } from './@state/effects/sync-pmid.effect';
import { CompanyDetailsReducer } from './@state/reducers/company-details.reducer';
import { CompanyDetailsHttpService } from './services/company-details.http.service';

@NgModule({
  declarations: [CompanyDetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AdminSharedModule,
    TabTemplatePanelModule,
    SprCommonModule,
    SPRFormsModule,
    StoreModule.forFeature('companyDetails', CompanyDetailsReducer),
    EffectsModule.forFeature([
      LoadCompanyDetailsEffect,
      SaveCompanyDetailsEffect,
      LoadContainerDetailsEffect,
      SyncCompanyNameEffect,
      SyncPMIDandLEIEffect
    ]),
    CompanyDetailsRoutingModule
  ],
  providers: [CanDeactivateGuard, CompanyDetailsHttpService, DialogService],
  exports: [CompanyDetailsComponent]
})
export class CompanyDetailsModule {}
