import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { CompanyDetailsHttpService } from '../../services/company-details.http.service';
import {
  CompanyDetailsActionTypes,
  LoadCompanyDetailsAction,
  LoadCompanyDetailsFailedAction,
  LoadCompanyDetailsSuccessAction,
  LoadContainerDetailsSuccessAction
} from '../actions/company-details.action';

@Injectable()
export class LoadCompanyDetailsEffect {
  public constructor(
    private actions$: Actions,
    private store: Store,
    private companyDetailsHttpService: CompanyDetailsHttpService
  ) {}

  public loadCompanyDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyDetailsActionTypes.LoadCompanyDetails),
      switchMap((action: LoadCompanyDetailsAction) => {
        const companyDetails$ = this.companyDetailsHttpService.getCompanyDetails(action.payload.companyId);
        const containerDetails$ = this.companyDetailsHttpService.getCompany(action.payload.containerId);
        return forkJoin([companyDetails$, containerDetails$]).pipe(
          map(data => {
            this.store.dispatch(new LoadContainerDetailsSuccessAction(data[1]));
            return new LoadCompanyDetailsSuccessAction(data[0]);
          }),
          catchError(_err => of(new LoadCompanyDetailsFailedAction()))
        );
      })
    )
  );
}
