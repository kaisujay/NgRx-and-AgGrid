import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyDetailsModel, UpdateCompanyDetails } from '../../models/company-details.model';
import { CompanyDetailsHttpService } from '../../services/company-details.http.service';
import {
  CompanyDetailsActionTypes,
  SaveCompanyDetailsAction,
  SaveCompanyDetailsFailedAction,
  SaveCompanyDetailsSuccessAction
} from '../actions/company-details.action';

@Injectable()
export class SaveCompanyDetailsEffect {
  public constructor(
    private actions$: Actions,
    private companyDetailsHttpService: CompanyDetailsHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveCompanyDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyDetailsActionTypes.SaveCompanyDetails),
      switchMap((action: SaveCompanyDetailsAction) => {
        return this.companyDetailsHttpService.saveCompanyDetails(action.id, action.payload).pipe(
          map(data => this.handleSuccess(data, action.payload)),
          catchError(_ => this.handleError())
        );
      })
    )
  );

  private handleSuccess(res: CompanyDetailsModel, payload: UpdateCompanyDetails) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company Details saved successfully');
    return new SaveCompanyDetailsSuccessAction({
      AssetClasses: [...payload.AssetClasses],
      ...res
    });
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Company Details');
    return of(new SaveCompanyDetailsFailedAction());
  }
}
