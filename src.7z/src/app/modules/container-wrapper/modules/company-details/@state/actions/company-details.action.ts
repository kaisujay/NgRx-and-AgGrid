import { Action } from '@ngrx/store';
import {
  CompanyDetailsModel,
  CompanyDetailsRequestPayload,
  ContainersModel,
  UpdateCompanyDetails
} from '../../models/company-details.model';

export enum CompanyDetailsActionTypes {
  LoadCompanyDetails = '[Company Details] Load Company Details',
  LoadCompanyDetailsSuccess = '[Company Details] Load Company Details Success',
  LoadCompanyDetailsFailed = '[Company Details] Load Company Details Failed',

  LoadContainerDetails = '[Company Details] Load Container Details',
  LoadContainerDetailsSuccess = '[Company Details] Load Container Details Success',
  LoadContainerDetailsFailed = '[Company Details] Load Container Details Failed',

  SaveCompanyDetails = '[Company Details] Save Company Details',
  SaveCompanyDetailsSuccess = '[Company Details] Save Company Details Success',
  SaveCompanyDetailsFailed = '[Company Details] Save Company Details Failed',

  SyncCompanyName = '[Company Details] Sync Company Name',
  SyncCompanyNameSuccess = '[Company Details] Sync Company Name Success',
  SyncCompanyNameFailed = '[Company Details] Sync Company Name Failed',

  SyncPMIDandLEI = '[Company Details] Sync PMID and LEI',
  SyncPMIDandLEISuccess = '[Company Details] Sync PMID and LEI Success',
  SyncPMIDandLEIFailed = '[Company Details] Sync PMID and LEI Failed',

  CompanyDetailsCloseModal = '[Company Details] Company Details Close Modal'
}

export class LoadCompanyDetailsAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadCompanyDetails;
  public constructor(public payload: CompanyDetailsRequestPayload) {}
}

export class LoadCompanyDetailsSuccessAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadCompanyDetailsSuccess;
  public constructor(public payload: CompanyDetailsModel) {}
}

export class LoadCompanyDetailsFailedAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadCompanyDetailsFailed;
  public constructor() {}
}

export class LoadContainerDetailsAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadContainerDetails;
  public constructor(public id: string) {}
}

export class LoadContainerDetailsSuccessAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadContainerDetailsSuccess;
  public constructor(public payload: ContainersModel[]) {}
}

export class LoadContainerDetailsFailedAction implements Action {
  public readonly type = CompanyDetailsActionTypes.LoadContainerDetailsFailed;
  public constructor() {}
}

export class SaveCompanyDetailsAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SaveCompanyDetails;
  public constructor(
    public id: string,
    public payload: UpdateCompanyDetails
  ) {}
}

export class SaveCompanyDetailsSuccessAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SaveCompanyDetailsSuccess;
  public constructor(public payload: CompanyDetailsModel) {}
}

export class SaveCompanyDetailsFailedAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SaveCompanyDetailsFailed;
  public constructor() {}
}

export class SyncCompanyNameAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncCompanyName;
  public constructor(public id: string) {}
}

export class SyncCompanyNameSuccessAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncCompanyNameSuccess;
  public constructor() {}
}

export class SyncCompanyNameFailedAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncCompanyNameFailed;
  public constructor() {}
}

export class SyncPMIDandLEIAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncPMIDandLEI;
  public constructor(public id: string) {}
}

export class SyncPMIDandLEISuccessAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncPMIDandLEISuccess;
  public constructor() {}
}

export class SyncPMIDandLEIFailedAction implements Action {
  public readonly type = CompanyDetailsActionTypes.SyncPMIDandLEIFailed;
  public constructor() {}
}

export class CompanyDetailsCloseModalAction implements Action {
  public readonly type = CompanyDetailsActionTypes.CompanyDetailsCloseModal;
  public constructor() {}
}

export type CompanyDetailsActionsUnion =
  | LoadCompanyDetailsAction
  | LoadCompanyDetailsSuccessAction
  | LoadCompanyDetailsFailedAction
  | LoadContainerDetailsAction
  | LoadContainerDetailsSuccessAction
  | LoadContainerDetailsFailedAction
  | SaveCompanyDetailsAction
  | SaveCompanyDetailsSuccessAction
  | SaveCompanyDetailsFailedAction
  | SyncCompanyNameAction
  | SyncCompanyNameSuccessAction
  | SyncCompanyNameFailedAction
  | SyncPMIDandLEIAction
  | SyncPMIDandLEISuccessAction
  | SyncPMIDandLEIFailedAction
  | CompanyDetailsCloseModalAction;
