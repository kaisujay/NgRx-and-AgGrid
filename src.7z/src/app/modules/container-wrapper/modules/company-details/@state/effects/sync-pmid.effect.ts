import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyDetailsHttpService } from '../../services/company-details.http.service';
import {
  CompanyDetailsActionTypes,
  SyncPMIDandLEIAction,
  SyncPMIDandLEIFailedAction,
  SyncPMIDandLEISuccessAction
} from '../actions/company-details.action';

@Injectable()
export class SyncPMIDandLEIEffect {
  public constructor(
    private actions$: Actions,
    private companyDetailsHttpService: CompanyDetailsHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public syncPMIDandLEIEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyDetailsActionTypes.SyncPMIDandLEI),
      switchMap((action: SyncPMIDandLEIAction) => {
        return this.companyDetailsHttpService.syncPMIDandLEI(action.id).pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError())
        );
      })
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Sync PMID and LEI saved successfully');
    return new SyncPMIDandLEISuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Sync PMID and LEI');
    return of(new SyncPMIDandLEIFailedAction());
  }
}
