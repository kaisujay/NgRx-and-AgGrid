import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyDetailsHttpService } from '../../services/company-details.http.service';
import {
  CompanyDetailsActionTypes,
  SyncCompanyNameAction,
  SyncCompanyNameFailedAction,
  SyncCompanyNameSuccessAction
} from '../actions/company-details.action';

@Injectable()
export class SyncCompanyNameEffect {
  public constructor(
    private actions$: Actions,
    private companyDetailsHttpService: CompanyDetailsHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public syncCompanyNameEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyDetailsActionTypes.SyncCompanyName),
      switchMap((action: SyncCompanyNameAction) => {
        return this.companyDetailsHttpService.syncCompanyName(action.id).pipe(
          map(_data => this.handleSuccess()),
          catchError(_err => this.handleError())
        );
      })
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Sync Company Name saved successfully');
    return new SyncCompanyNameSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while saving Sync Company Name');
    return of(new SyncCompanyNameFailedAction());
  }
}
