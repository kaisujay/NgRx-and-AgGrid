import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CompanyDetailsModel, ContainersModel, UpdateCompanyDetails } from '../../models/company-details.model';
import { CompanyDetailsActionTypes, CompanyDetailsActionsUnion } from '../actions/company-details.action';

export interface CompanyDetailsState {
  data: {
    companyDetailsModel: CompanyDetailsModel;
    isLoading: boolean;
    isError: boolean;
    isLoadSuccess: boolean;
  };
  editPage: {
    updateCompanyDetails: UpdateCompanyDetails;
    companyDetailsModel: CompanyDetailsModel;
    isSaving: boolean;
    isError: boolean;
    isSaveSuccess: boolean;
  };
  getContainer: {
    containerDetailsModel: ContainersModel[];
    isLoading: boolean;
    isError: boolean;
  };
  syncCompany: {
    isLoading: boolean;
    isError: boolean;
  };
  syncPMIDandLEI: {
    isLoading: boolean;
    isError: boolean;
  };
}

export const initialState: CompanyDetailsState = {
  data: {
    companyDetailsModel: null,
    isLoading: false,
    isError: false,
    isLoadSuccess: false
  },
  editPage: {
    updateCompanyDetails: null,
    companyDetailsModel: null,
    isSaving: false,
    isError: false,
    isSaveSuccess: false
  },
  getContainer: {
    containerDetailsModel: null,
    isLoading: false,
    isError: false
  },
  syncCompany: {
    isLoading: false,
    isError: false
  },
  syncPMIDandLEI: {
    isLoading: false,
    isError: false
  }
};

export function CompanyDetailsReducer(
  state: CompanyDetailsState = initialState,
  action: CompanyDetailsActionsUnion
): CompanyDetailsState {
  switch (action.type) {
    case CompanyDetailsActionTypes.LoadCompanyDetails:
      return {
        ...state,
        data: {
          ...state.data,
          isLoading: true,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.LoadCompanyDetailsSuccess:
      return {
        ...state,
        data: {
          companyDetailsModel: {
            ...action.payload
          },
          isLoadSuccess: true,
          isLoading: false,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.LoadCompanyDetailsFailed:
      return {
        ...state,
        data: {
          ...state.data,
          isLoadSuccess: false,
          isLoading: false,
          isError: true
        }
      };

    case CompanyDetailsActionTypes.LoadContainerDetails:
      return {
        ...state,
        getContainer: {
          ...state.getContainer,
          isLoading: true,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.LoadContainerDetailsSuccess:
      return {
        ...state,
        getContainer: {
          containerDetailsModel: {
            ...action.payload
          },
          isLoading: false,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.LoadContainerDetailsFailed:
      return {
        ...state,
        getContainer: {
          ...state.getContainer,
          isLoading: false,
          isError: true
        }
      };

    case CompanyDetailsActionTypes.SaveCompanyDetails:
      return {
        ...state,
        data: {
          ...state.data,
          isLoadSuccess: false
        },
        editPage: {
          ...state.editPage,
          companyDetailsModel: null,
          isSaving: true,
          isSaveSuccess: false,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SaveCompanyDetailsSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          companyDetailsModel: {
            ...action.payload
          }
        },
        editPage: {
          companyDetailsModel: {
            ...action.payload
          },
          updateCompanyDetails: null,
          isSaving: false,
          isSaveSuccess: true,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SaveCompanyDetailsFailed:
      return {
        ...state,
        editPage: {
          ...state.editPage,
          isSaving: false,
          isError: true,
          isSaveSuccess: false
        }
      };

    case CompanyDetailsActionTypes.SyncCompanyName:
      return {
        ...state,
        syncCompany: {
          ...state.syncCompany,
          isLoading: true,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SyncCompanyNameSuccess:
      return {
        ...state,
        syncCompany: {
          ...state.syncCompany,
          isLoading: false,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SyncCompanyNameFailed:
      return {
        ...state,
        syncCompany: {
          ...state.syncCompany,
          isLoading: false,
          isError: true
        }
      };

    case CompanyDetailsActionTypes.SyncPMIDandLEI:
      return {
        ...state,
        syncPMIDandLEI: {
          ...state.syncPMIDandLEI,
          isLoading: true,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SyncPMIDandLEISuccess:
      return {
        ...state,
        syncPMIDandLEI: {
          ...state.syncPMIDandLEI,
          isLoading: false,
          isError: false
        }
      };

    case CompanyDetailsActionTypes.SyncPMIDandLEIFailed:
      return {
        ...state,
        syncPMIDandLEI: {
          ...state.syncPMIDandLEI,
          isLoading: false,
          isError: true
        }
      };

    case CompanyDetailsActionTypes.CompanyDetailsCloseModal:
      return {
        ...state,
        ...initialState
      };

    default:
      return state;
  }
}

export const getCompanyDetailsState = createFeatureSelector<CompanyDetailsState>('companyDetails');
export const companyDetailsSaveSuccess = createSelector(getCompanyDetailsState, state => state.editPage.isSaveSuccess);
export const companyDetailsLoadSuccess = createSelector(getCompanyDetailsState, state => state.data.isLoadSuccess);
