import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CompanyDetailsHttpService } from '../../services/company-details.http.service';
import {
  CompanyDetailsActionTypes,
  LoadContainerDetailsAction,
  LoadContainerDetailsSuccessAction,
  LoadContainerDetailsFailedAction
} from '../actions/company-details.action';
import { catchError, map, of, switchMap } from 'rxjs';

@Injectable()
export class LoadContainerDetailsEffect {
  public constructor(
    private actions$: Actions,
    private companyDetailsHttpService: CompanyDetailsHttpService
  ) {}

  public loadContainerDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyDetailsActionTypes.LoadContainerDetails),
      switchMap((action: LoadContainerDetailsAction) => {
        return this.companyDetailsHttpService.getCompany(action.id).pipe(
          map(data => new LoadContainerDetailsSuccessAction(data)),
          catchError(_err => of(new LoadContainerDetailsFailedAction()))
        );
      })
    )
  );
}
