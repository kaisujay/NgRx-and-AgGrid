import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Observable, combineLatest, filter, switchMap } from 'rxjs';
import { companyDetailsForOptions } from '../data/company-details.data';
import {
  CompanyDetailsModel,
  ContainersModel,
  ContainersOption,
  UpdateCompanyDetails,
  UpdateCompanyDetailsCheck
} from '../models/company-details.model';
import { CompanyDetailsHttpService } from '../services/company-details.http.service';
import { CompanyDetailsService } from '../services/company-details.option.service';

import { deepClone } from '@core/constants/constants';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { checkIfPushMechanismRequired } from '../../companies-tree/models/add-company-dto.model';
import {
  CompanyDetailsActionTypes,
  CompanyDetailsCloseModalAction,
  LoadCompanyDetailsAction,
  SaveCompanyDetailsAction,
  SyncCompanyNameAction,
  SyncPMIDandLEIAction
} from '../@state/actions/company-details.action';
import { CompanyDetailsState, getCompanyDetailsState } from '../@state/reducers/company-details.reducer';
import { CompanyDetailsCheckDataService } from '../services/company-details.internal.service';
import { CompanyDetailsModalService } from '../services/company-details.modal.service';

@Component({
  selector: 'app-company-details',
  templateUrl: './company-details.component.html',
  styleUrls: ['./company-details.component.scss']
})
export class CompanyDetailsComponent implements OnInit, OnDestroy {
  @Input() public companyId: string;
  public companyDetailsFormGroupValues: FormGroup;
  public disable = true;
  public containerId: string;
  public companyDetailsModel: CompanyDetailsModel;
  public initialCompanyDetailsModel: UpdateCompanyDetailsCheck;
  public lastCompanyDetailsModel: UpdateCompanyDetailsCheck;
  public containersModel: ContainersModel[];
  public containersUseOption: ContainersOption[] = [];
  public parentCompanyOptions: SelectOptions[];
  public assetClassesOptions: SelectOptions[];
  public iaMemberTypeOptions: SelectOptions[];
  public updateCompanyDetails: UpdateCompanyDetails;
  public shouldEnabledButtons: boolean;

  public companyDetailsState$: Observable<CompanyDetailsState>;
  public apiSettingsSelectedIndex = 0;

  public constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private actions$: Actions,
    private httpService: CompanyDetailsHttpService,
    private modalService: CompanyDetailsModalService,
    private companyDetailsDataService: CompanyDetailsCheckDataService,
    private store$: Store
  ) {}

  public ngOnInit(): void {
    this.companyDetailsState$ = this.store$.pipe(select(getCompanyDetailsState));
    this.getContainerAndCompanyId();
    this.init();

    this.store$.dispatch(
      new LoadCompanyDetailsAction({
        companyId: this.companyId,
        containerId: this.containerId
      })
    );
    this.subscribeToCompanyDetails();
  }

  private subscribeToCompanyDetails(): void {
    this.actions$
      .pipe(
        filter(
          action =>
            action.type === CompanyDetailsActionTypes.LoadCompanyDetailsSuccess ||
            action.type === CompanyDetailsActionTypes.SaveCompanyDetailsSuccess ||
            action.type === CompanyDetailsActionTypes.SyncCompanyNameSuccess ||
            action.type === CompanyDetailsActionTypes.SyncPMIDandLEISuccess
        ),
        switchMap(_ => this.store$.select(getCompanyDetailsState))
      )
      .subscribe(state => {
        if (state.data.isLoadSuccess || state.editPage.isSaveSuccess) {
          this.companyDetailsModel = { ...state.data.companyDetailsModel };
          this.companyDetailsModel.Url = state.data.companyDetailsModel.ApiSetting?.Url;
          this.companyDetailsModel.UserName = state.data.companyDetailsModel.ApiSetting?.UserName;
          this.companyDetailsModel.Password = state.data.companyDetailsModel.ApiSetting?.Password;
          this.containersModel = state.getContainer.containerDetailsModel;

          this.setOptionsForParentCompany();
          this.setOptionValues();
          setTimeout(() => {
            this.updateFormValue();
            this.initialCompanyDetailsModel = this.companyDetailsFormGroupValues.value;
            this.shouldEnabledButtons = false;
          }, 0);
        }
      });
  }

  public init() {
    this.companyDetailsFormGroupValues = this.formBuilder.group({
      ParentCompanyId: new FormControl(null),
      Name: new FormControl({ value: '', disabled: true }, []),
      PMID: new FormControl({ value: '', disabled: true }, []),
      Lei: new FormControl({ value: '', disabled: true }, []),
      OrionId: new FormControl({ value: '', disabled: true }, []),
      CompanyType: new FormControl({ value: '', disabled: true }, []),
      IAMemberType: new FormControl(''),
      AssetClasses: new FormControl(''),
      Country: new FormControl({ value: '', disabled: true }, []),
      Region: new FormControl({ value: '', disabled: true }, []),
      Address1: new FormControl({ value: '', disabled: true }, []),
      Address2: new FormControl({ value: '', disabled: true }, []),
      Address3: new FormControl({ value: '', disabled: true }, []),
      City: new FormControl({ value: '', disabled: true }, []),
      Metro: new FormControl({ value: '', disabled: true }, []),
      State: new FormControl({ value: '', disabled: true }, []),
      ZipCode: new FormControl({ value: '', disabled: true }, []),
      Url: new FormControl({ value: '', disabled: false }, []),
      UserName: new FormControl({ value: '', disabled: false }, []),
      Password: new FormControl({ value: '', disabled: false }, []),
      EnablePush: new FormControl({ value: false, disabled: false }, []),
      AuthenticationType: new FormControl({ value: '', disabled: false }, [])
    });
    this.subscribeToFormValueChanges();
    this.companyDetailsFormGroupValues.valueChanges.subscribe(_ => {
      setTimeout(() => {
        const currentDetails = this.companyDetailsFormGroupValues.value;
        if (this.initialCompanyDetailsModel && currentDetails) {
          this.shouldEnabledButtons =
            this.companyDetailsFormGroupValues.valid &&
            Object.keys(this.initialCompanyDetailsModel).some(
              key => JSON.stringify(currentDetails[key]) !== JSON.stringify(this.initialCompanyDetailsModel[key])
            );
        }
      }, 0);
    });
  }

  public updateFormValue() {
    if (this.companyDetailsModel != null) {
      this.modalService.sendCompanyName(this.companyDetailsModel.Name);
      this.companyDetailsFormGroupValues.patchValue({ ...this.companyDetailsModel }, { emitEvent: false });
      this.shouldEnabledButtons = false;
    }
  }

  public subscribeToFormValueChanges(): void {
    const memberTypeChanges = this.companyDetailsFormGroupValues.get('IAMemberType').valueChanges;
    const assetClassesChanges = this.companyDetailsFormGroupValues.get('AssetClasses').valueChanges;
    combineLatest([memberTypeChanges, assetClassesChanges]).subscribe(([_, __]) => {
      this.updatePushApiSettingsFormValidity();
    });
  }

  private updatePushApiSettingsFormValidity(): void {
    if (
      this.apiSettingsSelectedIndex == 2 &&
      checkIfPushMechanismRequired(
        this.companyDetailsFormGroupValues.get('IAMemberType').value,
        this.companyDetailsFormGroupValues.get('AssetClasses').value
      )
    ) {
      this.setControlValidity('Url', true);
      this.setControlValidity('UserName', true);
      this.setControlValidity('Password', true);
      this.companyDetailsFormGroupValues.get('EnablePush').setValue(true, { emitEvent: false });
      this.companyDetailsFormGroupValues.get('AuthenticationType').setValue(0, { emitEvent: false });
    } else {
      this.setControlValidity('Url', false);
      this.setControlValidity('UserName', false);
      this.setControlValidity('Password', false);
      this.companyDetailsFormGroupValues.get('EnablePush').setValue(false, { emitEvent: false });
      this.companyDetailsFormGroupValues.get('AuthenticationType').setValue(null, { emitEvent: false });
      this.companyDetailsFormGroupValues.get('Url').setValue(null, { emitEvent: false });
      this.companyDetailsFormGroupValues.get('UserName').setValue(null, { emitEvent: false });
      this.companyDetailsFormGroupValues.get('Password').setValue(null, { emitEvent: false });
    }
  }

  private setControlValidity(controlName: string, setValidators: boolean): void {
    if (setValidators) {
      this.companyDetailsFormGroupValues.get(controlName).setValidators([Validators.required]);
    } else {
      this.companyDetailsFormGroupValues.get(controlName).clearValidators();
    }
    this.companyDetailsFormGroupValues.get(controlName).updateValueAndValidity();
  }

  public onTabIndexChanged(_: number) {
    this.apiSettingsSelectedIndex = _;
    this.updatePushApiSettingsFormValidity();
  }

  public setOptionsForParentCompany() {
    if (this.containersModel != null && this.companyDetailsModel != null) {
      for (let index = 0; index < Object.keys(this.containersModel).length; index++) {
        this.containersUseOption[index] = {
          label: this.containersModel[index].Name,
          value: this.containersModel[index].Id
        };
      }
      const arr = this.containersUseOption.filter(item => item.label !== this.companyDetailsModel.Name);
      this.parentCompanyOptions = arr;
    }
  }

  public setOptionValues() {
    this.assetClassesOptions = CompanyDetailsService.getOptions(
      companyDetailsForOptions.AssetClass,
      'AssetClassId',
      'Value'
    );

    this.iaMemberTypeOptions = CompanyDetailsService.getOptions(
      companyDetailsForOptions.IAMemberType,
      'IAMemberTypeId',
      'Value'
    );
  }

  public saveCompanyDetails() {
    this.updateCompanyDetails = deepClone(this.companyDetailsFormGroupValues.value);
    this.updateCompanyDetails.Id = this.companyDetailsModel.Id;
    this.updateCompanyDetails.RowVersion = this.companyDetailsModel.RowVersion;
    if (!this.updateCompanyDetails.AssetClasses.includes('FixedIncome')) {
      this.updateCompanyDetails.AssetClasses.push('FixedIncome');
    }

    if (this.updateCompanyDetails.ParentCompanyId == null) {
      this.updateCompanyDetails.ParentCompanyId = this.companyDetailsModel.ParentCompanyId;
    }

    this.store$.dispatch(new SaveCompanyDetailsAction(this.companyId, this.updateCompanyDetails));

    this.companyDetailsDataService.companyData = this.updateCompanyDetails;
  }

  public syncCompanyName() {
    this.store$.dispatch(new SyncCompanyNameAction(this.companyId));
  }

  public syncPMIDandLEI() {
    this.store$.dispatch(new SyncPMIDandLEIAction(this.companyId));
  }

  private getContainerAndCompanyId() {
    this.containerId = '';
    this.companyId = '';
    const url = this.router.url;
    let splitted = url.split('/');
    this.containerId = splitted[2];
    this.companyId = splitted[4];
  }

  public ngOnDestroy(): void {
    this.store$.dispatch(new CompanyDetailsCloseModalAction());
  }
}
