import { CompanyDetailsForOptions } from '../models/company-details.model';

export let companyDetailsForOptions: CompanyDetailsForOptions = {
  ParentCompany: [],
  AssetClass: [
    // {
    //     AssetClassId: 'FixedIncome',
    //     Value: 'FixedIncome'
    // },
    {
      AssetClassId: 'Municipal',
      Value: 'Municipal'
    },
    {
      AssetClassId: 'Equity',
      Value: 'Equity'
    }
  ],
  IAMemberType: [
    {
      IAMemberTypeId: 'Sell Side',
      Value: 'Sellside'
    },
    {
      IAMemberTypeId: 'Internal Sell Side',
      Value: 'InternalSellside'
    },
    {
      IAMemberTypeId: 'Buy Side',
      Value: 'Buyside'
    },
    {
      IAMemberTypeId: 'Ipreo',
      Value: 'Ipreo'
    },
    {
      IAMemberTypeId: 'Other',
      Value: 'Other'
    },
    {
      IAMemberTypeId: 'IA Third Party Vendor',
      Value: 'IaThirdPartyVendor'
    }
  ]
};
