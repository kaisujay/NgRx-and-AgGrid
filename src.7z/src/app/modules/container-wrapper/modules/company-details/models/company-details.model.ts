export interface CompanyDetailsModel {
  Id: string;
  ContainerId: string;
  ParentCompanyId: string;
  Name: string;
  PMID: string;
  LEI: string;
  OrionId: number;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  CompanyType: string;
  Country: string;
  Region: string;
  Address1: string;
  Address2: string;
  Address3: string;
  City: string;
  Metro: string;
  State: string;
  ZipCode: string;
  FixCompIds: string;
  IAMemberType: string;
  AssetClasses: string[];
  AuthenticationType?: string;
  EnablePush?: boolean;
  Password?: string;
  Url?: string;
  UserName?: string;
  ApiSetting: {
    AuthenticationType: string;
    EnablePush: boolean;
    Password: string;
    Url: string;
    UserName: string;
  };
}

export interface ReceivedCompanyDetails {
  Id: string;
  Name: string;
  PMID: string;
  OrionId: number;
  ContainerId: string;
  ParentCompanyId: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  ActiveUsers: number;
}

export interface UpdateCompanyDetails {
  Id: string;
  ParentCompanyId: string;
  RowVersion: number;
  IAMemberType: string;
  AssetClasses: string[];
}

export interface UpdateCompanyDetailsCheck {
  ParentCompanyId: string;
  IAMemberType: string;
  AssetClasses: string[];
}

export interface CompanyDetailsForOptions {
  ParentCompany: ContainersModel[];
  AssetClass: AssetClass[];
  IAMemberType: IAMemberType[];
}

export interface AssetClass {
  AssetClassId: string;
  Value: string;
}

export interface IAMemberType {
  IAMemberTypeId: string;
  Value: string;
}

export interface CompanyDetailsRequestPayload {
  companyId: string;
  containerId: string;
}

export interface ContainersModel {
  Id: string;
  Name: string;
  PMID: string;
  OrionId: number;
  ContainerId: string;
  ParentCompanyId: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  ActiveUsers: number;
}

export interface ContainersOption {
  label: string;
  value: string;
}

export interface CanDeactivateCompanyDetailsCheck {
  ParentCompanyId: string;
  IAMemberType: string;
  AssetClasses: string[];
  ButtonNumber: string;
}
