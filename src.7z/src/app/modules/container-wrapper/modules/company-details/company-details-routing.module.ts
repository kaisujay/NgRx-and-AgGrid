import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyDetailsComponent } from './components/company-details.component';
import { CanDeactivateGuard } from '@core/gaurds/can-deactivate.guard';

const routes: Routes = [
  {
    path: '',
    component: CompanyDetailsComponent,
    canDeactivate: [CanDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyDetailsRoutingModule {}
