import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompaniesTreeComponent } from './components/companies-tree.component';

const routes: Routes = [
  {
    path: '',
    component: CompaniesTreeComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompaniesTreeRoutingModule {}
