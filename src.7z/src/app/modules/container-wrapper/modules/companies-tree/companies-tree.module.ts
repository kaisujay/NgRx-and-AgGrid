import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import {
  DropdownsModule,
  IconModule,
  ModalService,
  OverlayService,
  SPRFormsModule,
  SelectorsModule,
  SprCommonModule,
  TabTemplatePanelModule
} from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminSharedModule } from '@shared/shared.module';
import { AddCompanyEffect } from '@state/effects/add-new-company.effect';
import { CheckDeletedCompanyEffect } from '@state/effects/check-deleted-company.effect';
import { LoadCompaniesStructureEffect } from '@state/effects/load-company-structure.effect';
import { RemoveCompanyEffect } from '@state/effects/remove-company.effect';
import { RestoreCompanyEffect } from '@state/effects/restore-company.effect';
import { companiesTreeReducer } from '@state/reducers/companies-tree.reducer';
import { AgGridModule } from 'ag-grid-angular';
import { CompaniesTreeRoutingModule } from './companies-tree-routing.module';
import { AddCompanyComponent } from './components/add-company/add-company.component';
import { CompaniesTreeComponent } from './components/companies-tree.component';
import { CompanyTableComponent } from './components/company-table/company-table.component';
import { RestoreCompanyComponent } from './components/restore-company/restore-company.component';
import { ClickOutsideDirective } from './directives/click-outside.directive';
import { AddCompanyHttpService } from './services/add-company-http.service';
import { CompaniesTreeHttpService } from './services/companies-tree-http.service';
import { DeleteCompanyHttpService } from './services/remove-company-http.service';
import { RestoreCompanyHttpService } from './services/restore-company-http.service';

@NgModule({
  declarations: [
    CompaniesTreeComponent,
    CompanyTableComponent,
    ClickOutsideDirective,
    AddCompanyComponent,
    RestoreCompanyComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    CompaniesTreeRoutingModule,
    AgGridModule.withComponents([]),
    StoreModule.forFeature('companiesTree', companiesTreeReducer),
    EffectsModule.forFeature([
      LoadCompaniesStructureEffect,
      AddCompanyEffect,
      CheckDeletedCompanyEffect,
      RestoreCompanyEffect,
      RemoveCompanyEffect
    ]),
    IconModule,
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    SprCommonModule,
    SPRFormsModule,
    DropdownsModule,
    SelectorsModule,
    TabTemplatePanelModule
  ],
  providers: [
    CompaniesTreeHttpService,
    OverlayService,
    AddCompanyHttpService,
    RestoreCompanyHttpService,
    ModalService,
    DeleteCompanyHttpService
  ]
})
export class CompaniesTreeModule {}
