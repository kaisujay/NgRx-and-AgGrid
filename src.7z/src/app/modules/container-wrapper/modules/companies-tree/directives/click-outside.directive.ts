import { Directive, ElementRef, EventEmitter, HostListener, Output } from '@angular/core';

@Directive({
  selector: '[appClickOutside]'
})
export class ClickOutsideDirective {
  @Output() private appClickOutside = new EventEmitter<void>();

  public constructor(private elementRef: ElementRef) {}

  @HostListener('document:click', ['$event.target'])
  public onClick(target: HTMLElement): void {
    const isContextMenuChild = element => {
      let node = element.parentNode;
      while (node != null) {
        if (node.classList && node.classList.contains('company-table__context-menu-cell')) {
          return true;
        }
        node = node.parentNode;
      }
      return false;
    };

    const clickedInside = isContextMenuChild(target);
    if (!clickedInside) {
      this.appClickOutside.emit();
    }
  }
}
