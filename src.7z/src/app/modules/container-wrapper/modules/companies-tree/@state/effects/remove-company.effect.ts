import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { DeleteCompanyHttpService } from '../../services/remove-company-http.service';
import {
  CompaniesTreeActionTypes,
  RemoveCompanyAction,
  RemoveCompanyFailedAction,
  RemoveCompanySuccessAction
} from '../actions/companies-tree.actions';

@Injectable()
export class RemoveCompanyEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private deleteCompanyHttpService: DeleteCompanyHttpService
  ) {}

  public removeCompanyEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.RemoveCompany),
      switchMap(({ payload }: RemoveCompanyAction) => {
        return this.deleteCompanyHttpService.deleteCompany(payload.companyId).pipe(
          map(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company removed successfully');
            return new RemoveCompanySuccessAction({
              containerId: payload.containerId
            });
          }),
          catchError(() => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while removing company');
            return of(new RemoveCompanyFailedAction());
          })
        );
      })
    )
  );
}
