import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import {
  CompaniesTreeActionTypes,
  CheckDeletedCompaniesAction,
  CheckDeletedCompaniesFailedAction,
  CheckDeletedCompaniesSuccessAction
} from '../actions/companies-tree.actions';
import { switchMap, map, catchError, of } from 'rxjs';
import { RestoreCompanyHttpService } from '../../services/restore-company-http.service';

@Injectable()
export class CheckDeletedCompanyEffect {
  public constructor(
    private actions$: Actions,
    private restoreCompanyHttpService: RestoreCompanyHttpService
  ) {}

  public checkDeletedCompaniesEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.CheckDeletedCompanies),
      switchMap((action: CheckDeletedCompaniesAction) => {
        return this.restoreCompanyHttpService.getDeletedCompanies(action.containerId).pipe(
          map(deletedCompanies => new CheckDeletedCompaniesSuccessAction(deletedCompanies)),
          catchError(() => of(new CheckDeletedCompaniesFailedAction()))
        );
      })
    )
  );
}
