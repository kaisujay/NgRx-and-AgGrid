import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { AddCompanyHttpService } from '../../services/add-company-http.service';

import { HttpErrorResponse } from '@angular/common/http';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { AddCompanyDto } from '../../models/add-company-dto.model';
import {
  AddCompanyAction,
  AddCompanyFailedAction,
  AddCompanySuccessAction,
  CompaniesTreeActionTypes
} from '../actions/companies-tree.actions';

@Injectable()
export class AddCompanyEffect {
  public constructor(
    private actions$: Actions,
    private addCompanyHttpService: AddCompanyHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public addCompanyEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.AddCompany),
      switchMap(({ payload }: AddCompanyAction) => {
        const addCompanyDto: AddCompanyDto = {
          AssetClasses: [...payload.assetClasses.map(ac => ac.id), 'FixedIncome'],
          ContainerId: payload.containerId,
          IAMemberType: payload.memberType,
          Lei: payload.lei,
          Name: payload.name,
          OrionId: payload.orionId,
          ParentCompanyId: payload.parentCompany,
          PMID: payload.pmid,
          ApiSetting: null
        };

        if (payload.enablePush) {
          addCompanyDto.ApiSetting = {
            Url: payload.url,
            UserName: payload.userName,
            Password: payload.password,
            EnablePush: payload.enablePush,
            AuthenticationType: payload.authenticationType
          };
        }

        return this.addCompanyHttpService.post(addCompanyDto).pipe(
          map(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company Added Succesfully', 3000);
            return new AddCompanySuccessAction({ containerId: payload.containerId });
          }),
          catchError(_ => {
            this.handleAddCompanyError(_);
            return of(new AddCompanyFailedAction());
          })
        );
      })
    )
  );

  public handleAddCompanyError(errRes: HttpErrorResponse): void {
    let errorMsg = 'Error while adding company';
    if (errRes.error && errRes.error.ErrorCode && errRes.error.ErrorCode === 'DuplicateKeyExceptionWithArgument') {
      errorMsg = `Company cannot be added as it already exists in a container "${errRes.error.Details.arg1}"`;
    }
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, errorMsg, 3000);
  }
}
