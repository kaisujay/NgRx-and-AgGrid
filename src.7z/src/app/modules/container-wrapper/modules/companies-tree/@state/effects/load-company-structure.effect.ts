import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';

import { CompaniesTreeHttpService } from '../../services/companies-tree-http.service';
import {
  AddCompanySuccessAction,
  CompaniesTreeActionTypes,
  LoadAction,
  LoadFailedAction,
  LoadSuccessAction,
  RemoveCompanySuccessAction,
  RestoreCompanyAction
} from '../actions/companies-tree.actions';

@Injectable()
export class LoadCompaniesStructureEffect {
  public constructor(
    private actions$: Actions,
    private companiesTreeHttpService: CompaniesTreeHttpService
  ) {}
  public loadCompaniesStructureEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.Load),
      switchMap((action: LoadAction) => {
        return this.companiesTreeHttpService.get(action.payload.id).pipe(
          map(response => new LoadSuccessAction({ structure: response })),
          catchError(() => of(new LoadFailedAction()))
        );
      })
    )
  );

  public triggerLoadCompaniesAfterCreationEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.AddCompanySuccess),
      map(({ payload }: AddCompanySuccessAction) => new LoadAction({ id: payload.containerId }))
    )
  );

  public triggerLoadCompaniesAfterRestoringEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.RestoreCompanySuccess),
      map(({ payload }: RestoreCompanyAction) => new LoadAction({ id: payload.containerId }))
    )
  );

  public triggerLoadCompaniesAfterDeletionEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.RemoveCompanySuccess),
      map(({ payload }: RemoveCompanySuccessAction) => new LoadAction({ id: payload.containerId }))
    )
  );
}
