import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { RestoreCompanyHttpService } from '../../services/restore-company-http.service';
import {
  CompaniesTreeActionTypes,
  LoadDeletedCompaniesAction,
  LoadDeletedCompaniesFailedAction,
  LoadDeletedCompaniesSuccessAction,
  RestoreCompanyAction,
  RestoreCompanyFailedAction,
  RestoreCompanySuccessAction
} from '../actions/companies-tree.actions';

@Injectable()
export class RestoreCompanyEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private restoreCompanyHttpService: RestoreCompanyHttpService
  ) {}

  public loadDeletedCompaniesEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.LoadDeletedCompanies),
      switchMap(({ payload }: LoadDeletedCompaniesAction) => {
        return this.restoreCompanyHttpService.getDeletedCompanies(payload.containerId).pipe(
          map(deletedCompanies => new LoadDeletedCompaniesSuccessAction({ deletedCompanies })),
          catchError(() => of(new LoadDeletedCompaniesFailedAction()))
        );
      })
    )
  );

  public restoreCompanyEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompaniesTreeActionTypes.RestoreCompany),
      switchMap(({ payload }: RestoreCompanyAction) => {
        return this.restoreCompanyHttpService.restoreCompany(payload.achieveId).pipe(
          map(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Company restored successfully');
            return new RestoreCompanySuccessAction({
              containerId: payload.containerId
            });
          }),
          catchError(() => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while restoring company');
            return of(new RestoreCompanyFailedAction());
          })
        );
      })
    )
  );
}
