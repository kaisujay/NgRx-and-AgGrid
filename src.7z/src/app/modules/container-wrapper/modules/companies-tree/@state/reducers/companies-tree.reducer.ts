import { createFeatureSelector } from '@ngrx/store';
import { CompanyInfoWrapModel } from '../../models/company-info.model';
import { DeletedCompanyDto } from '../../models/deleted-company-dto.model';
import { CompanyStructureService } from '../../services/company-structure.service';
import { CompaniesTreeActionsUnion, CompaniesTreeActionTypes } from '../actions/companies-tree.actions';

export interface CompaniesTreeState {
  structure: CompanyInfoWrapModel[];
  deletedCompanies: DeletedCompanyDto[];
  preselectedParentCompanyId?: string;
  isAddCompanyMode: boolean;
  isCheckDeletedCompaniesSuccess: boolean;
  isRemoveSuccess: boolean;
  isAddingCompany: boolean;
  isRestoreCompanyMode: boolean;
  isRestoringCompany: boolean;
  isLoadingStatuses: boolean;
  isLoadError: boolean;
  isDeletedCompaniesError: boolean;
}

export const initialState: CompaniesTreeState = {
  structure: null,
  deletedCompanies: [],
  preselectedParentCompanyId: null,
  isAddCompanyMode: false,
  isCheckDeletedCompaniesSuccess: false,
  isRemoveSuccess: false,
  isAddingCompany: false,
  isRestoreCompanyMode: false,
  isRestoringCompany: false,
  isLoadingStatuses: false,
  isLoadError: false,
  isDeletedCompaniesError: false
};

export function companiesTreeReducer(
  state: CompaniesTreeState = initialState,
  action: CompaniesTreeActionsUnion
): CompaniesTreeState {
  switch (action.type) {
    case CompaniesTreeActionTypes.Load:
      return {
        ...initialState,
        isAddCompanyMode: false,
        isAddingCompany: false,
        isRemoveSuccess: false,
        isLoadError: false
      };

    case CompaniesTreeActionTypes.LoadSuccess:
      return {
        ...state,
        structure: CompanyStructureService.wrapCompanies(action.payload.structure),

        isRemoveSuccess: false,
        isLoadError: false
      };

    case CompaniesTreeActionTypes.LoadFailed:
      return {
        ...state,
        isLoadError: true
      };

    case CompaniesTreeActionTypes.ToggleCompany:
      return {
        ...state,
        structure: CompanyStructureService.toggleCompany(state.structure, action.payload.id),

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.ToggleCompanyContextMenu:
      return {
        ...state,
        structure: CompanyStructureService.toggleContextMenu(
          JSON.parse(JSON.stringify(state.structure)) as CompanyInfoWrapModel[],
          action.payload.id
        ),

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.CollapseAllContextMenu:
      const structure = JSON.parse(JSON.stringify(state.structure)) as CompanyInfoWrapModel[];

      return {
        ...state,
        structure: CompanyStructureService.collapseAllContextMenu(structure),

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.AddCompanyModalOpen:
      return {
        ...state,
        preselectedParentCompanyId: action.payload.parentCompanyId,
        isAddCompanyMode: true,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.AddCompany:
      return {
        ...state,
        isAddingCompany: true,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.AddCompanySuccess:
      return {
        ...state,
        isAddingCompany: false,
        isAddCompanyMode: false,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.AddCompanyFailed:
      return {
        ...state,
        isAddingCompany: false,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.CheckDeletedCompanies:
      return {
        ...state,
        isCheckDeletedCompaniesSuccess: false,

        isRemoveSuccess: false,
        isDeletedCompaniesError: false
      };

    case CompaniesTreeActionTypes.CheckDeletedCompaniesSuccess:
      return {
        ...state,
        deletedCompanies: action.deletedCompanies,
        isCheckDeletedCompaniesSuccess: true,

        isRemoveSuccess: false,
        isDeletedCompaniesError: false
      };

    case CompaniesTreeActionTypes.CheckDeletedCompaniesFailed:
      return {
        ...state,
        isCheckDeletedCompaniesSuccess: false,

        isRemoveSuccess: false,
        isDeletedCompaniesError: true
      };

    case CompaniesTreeActionTypes.LoadDeletedCompanies:
      return {
        ...state,
        isLoadingStatuses: true,

        isRemoveSuccess: false,
        isDeletedCompaniesError: false
      };

    case CompaniesTreeActionTypes.LoadDeletedCompaniesSuccess:
      return {
        ...state,
        deletedCompanies: action.payload.deletedCompanies,
        isLoadingStatuses: false,
        isRestoreCompanyMode: true,

        isRemoveSuccess: false,
        isDeletedCompaniesError: false
      };

    case CompaniesTreeActionTypes.LoadDeletedCompaniesFailed:
      return {
        ...state,
        isLoadingStatuses: false,
        isRestoreCompanyMode: false,

        isRemoveSuccess: false,
        isDeletedCompaniesError: true
      };

    case CompaniesTreeActionTypes.RestoreCompany:
      return {
        ...state,
        isRestoringCompany: true,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.RestoreCompanySuccess:
      return {
        ...state,
        isRestoringCompany: false,
        isRestoreCompanyMode: false,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.RestoreCompanyFailed:
      return {
        ...state,
        isRestoringCompany: false,
        isRestoreCompanyMode: true,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.RemoveCompany:
      return {
        ...state,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.RemoveCompanySuccess:
      return {
        ...state,

        isRemoveSuccess: true
      };

    case CompaniesTreeActionTypes.RemoveCompanyFailed:
      return {
        ...state,

        isRemoveSuccess: false
      };

    case CompaniesTreeActionTypes.CloseModals:
      return {
        ...state,
        isAddCompanyMode: false,
        isRestoreCompanyMode: false,
        preselectedParentCompanyId: null,
        isRemoveSuccess: false
      };

    default:
      return state;
  }
}

export const getCompaniesTreeState = createFeatureSelector<CompaniesTreeState>('companiesTree');
