import { Action } from '@ngrx/store';
import { AddCompanyRequestPayload } from '../../models/add-company-dto.model';
import { CompanyInfoModel } from '../../models/company-info.model';
import { DeletedCompanyDto } from '../../models/deleted-company-dto.model';

export enum CompaniesTreeActionTypes {
  Load = '[Companies Tree] Load',
  LoadSuccess = '[Companies Tree] Load Success',
  LoadFailed = '[Companies Tree] Load Failed',

  ToggleCompany = '[Companies Tree] Toggle Company',
  ToggleCompanyContextMenu = '[Companies Tree] Toggle Company Context Menu',
  CollapseAllContextMenu = '[Companies Tree] Collapse All Context Menu',

  AddCompanyModalOpen = '[Companies Tree] Add Company Modal Open',

  AddCompany = '[Companies Tree] Add Company',
  AddCompanySuccess = '[Companies Tree] Add Company Success',
  AddCompanyFailed = '[Companies Tree] Add Company Failed',

  RestoreCompanyModalOpen = '[Companies Tree] Restore Company Modal Open',

  CheckDeletedCompanies = '[Companies Tree] Check Deleted Companies',
  CheckDeletedCompaniesSuccess = '[Companies Tree] Check Deleted Companies Success',
  CheckDeletedCompaniesFailed = '[Companies Tree] Check Deleted Companies Failed',

  LoadDeletedCompanies = '[Companies Tree] Load Deleted Companies',
  LoadDeletedCompaniesSuccess = '[Companies Tree] Load Deleted Companies Success',
  LoadDeletedCompaniesFailed = '[Companies Tree] Load Deleted Companies Failed',

  RestoreCompany = '[Companies Tree] Restore Company',
  RestoreCompanySuccess = '[Companies Tree] Restore Company Success',
  RestoreCompanyFailed = '[Companies Tree] Restore Company Failed',

  CloseModals = '[Companies Tree] Close Modals',
  RemoveCompany = '[Companies Tree] Remove Company',
  RemoveCompanySuccess = '[Companies Tree] Remove Company Success',
  RemoveCompanyFailed = '[Companies Tree] Remove Company Failed'
}

export class LoadAction implements Action {
  public readonly type = CompaniesTreeActionTypes.Load;
  public constructor(public payload: { id: string }) {}
}

export class LoadSuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.LoadSuccess;
  public constructor(public payload: { structure: CompanyInfoModel[] }) {}
}

export class LoadFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.LoadFailed;
  public constructor() {}
}

export class ToggleCompanyAction implements Action {
  public readonly type = CompaniesTreeActionTypes.ToggleCompany;
  public constructor(public payload: { id: string }) {}
}

export class ToggleCompanyContextMenuAction implements Action {
  public readonly type = CompaniesTreeActionTypes.ToggleCompanyContextMenu;
  public constructor(public payload: { id: string }) {}
}

export class CollapseAllContextMenuAction implements Action {
  public readonly type = CompaniesTreeActionTypes.CollapseAllContextMenu;
  public constructor() {}
}

export class AddCompanyModalOpenAction implements Action {
  public readonly type = CompaniesTreeActionTypes.AddCompanyModalOpen;
  public constructor(public payload: { parentCompanyId?: string }) {}
}

export class AddCompanyAction implements Action {
  public readonly type = CompaniesTreeActionTypes.AddCompany;
  public constructor(public payload: AddCompanyRequestPayload) {}
}

export class AddCompanySuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.AddCompanySuccess;
  public constructor(public payload: { containerId: string }) {}
}

export class AddCompanyFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.AddCompanyFailed;
  public constructor() {}
}

export class RestoreCompanyModalOpenAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RestoreCompanyModalOpen;
  public constructor() {}
}

export class CheckDeletedCompaniesAction implements Action {
  public readonly type = CompaniesTreeActionTypes.CheckDeletedCompanies;
  public constructor(public containerId: string) {}
}

export class CheckDeletedCompaniesSuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.CheckDeletedCompaniesSuccess;
  public constructor(public deletedCompanies: DeletedCompanyDto[]) {}
}

export class CheckDeletedCompaniesFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.CheckDeletedCompaniesFailed;
  public constructor() {}
}

export class LoadDeletedCompaniesAction implements Action {
  public readonly type = CompaniesTreeActionTypes.LoadDeletedCompanies;
  public constructor(public payload: { containerId: string }) {}
}

export class LoadDeletedCompaniesSuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.LoadDeletedCompaniesSuccess;
  public constructor(public payload: { deletedCompanies: DeletedCompanyDto[] }) {}
}

export class LoadDeletedCompaniesFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.LoadDeletedCompaniesFailed;
  public constructor() {}
}

export class RestoreCompanyAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RestoreCompany;
  public constructor(public payload: { achieveId: string; containerId: string }) {}
}

export class RestoreCompanySuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RestoreCompanySuccess;
  public constructor(public payload: { containerId: string }) {}
}

export class RestoreCompanyFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RestoreCompanyFailed;
  public constructor() {}
}

export class CloseModalsAction implements Action {
  public readonly type = CompaniesTreeActionTypes.CloseModals;
  public constructor() {}
}

export class RemoveCompanyAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RemoveCompany;
  public constructor(public payload: { companyId: string; containerId: string }) {}
}

export class RemoveCompanySuccessAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RemoveCompanySuccess;
  public constructor(public payload: { containerId: string }) {}
}

export class RemoveCompanyFailedAction implements Action {
  public readonly type = CompaniesTreeActionTypes.RemoveCompanyFailed;
  public constructor() {}
}

export type CompaniesTreeActionsUnion =
  | LoadAction
  | LoadSuccessAction
  | LoadFailedAction
  | ToggleCompanyAction
  | ToggleCompanyContextMenuAction
  | CollapseAllContextMenuAction
  | AddCompanyModalOpenAction
  | AddCompanyAction
  | AddCompanySuccessAction
  | AddCompanyFailedAction
  | CloseModalsAction
  | RestoreCompanyModalOpenAction
  | CheckDeletedCompaniesAction
  | CheckDeletedCompaniesSuccessAction
  | CheckDeletedCompaniesFailedAction
  | LoadDeletedCompaniesAction
  | LoadDeletedCompaniesSuccessAction
  | LoadDeletedCompaniesFailedAction
  | RestoreCompanyAction
  | RestoreCompanySuccessAction
  | RestoreCompanyFailedAction
  | RemoveCompanyAction
  | RemoveCompanySuccessAction
  | RemoveCompanyFailedAction;
