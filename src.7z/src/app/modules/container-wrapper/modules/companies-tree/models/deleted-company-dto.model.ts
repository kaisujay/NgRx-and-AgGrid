export interface DeletedCompanyDto {
  ArchiveId: string;
  CompanyName: string;
}
