export interface CompanyInfoModel {
  CompanyId: string;
  Name: string;
  OrionId: number;
  ActiveMembers: number;
  ChildCompanies: CompanyInfoModel[];
}
export interface CompanyInfoWrapModel {
  model: {
    CompanyId: string;
    Name: string;
    OrionId: number;
    ActiveMembers: number;
    ChildCompanies: CompanyInfoWrapModel[];
  };
  isOpen: boolean;
  isContextMenuOpen: boolean;
}
