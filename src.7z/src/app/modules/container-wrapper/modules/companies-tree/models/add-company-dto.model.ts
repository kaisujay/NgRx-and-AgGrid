export interface AddCompanyDto {
  AssetClasses: string[];
  ContainerId: string;
  IAMemberType: string;
  Lei: string;
  Name: string;
  OrionId: number;
  PMID: string;
  ParentCompanyId: string;
  ApiSetting: {
    Url?: string;
    UserName?: string;
    Password?: string;
    EnablePush?: string;
    AuthenticationType?: number;
  };
}

export interface AddCompanyRequestPayload {
  parentCompany: string;
  name: string;
  pmid: string;
  lei: string;
  orionId: number;
  companyType: string;
  memberType: string;
  assetClasses: AddCompanyassetClass[];
  address1: string;
  address2: string;
  address3: string;
  city: string;
  metro: string;
  state: string;
  zipCode: string;
  country: string;
  region: string;
  staffCount: string;
  totalAssetsUnderMgt: string;
  fiAssetsUnderMgt: string;
  eqAssetsUnderMgt: string;
  alternativeCompanyName: string;
  url?: string;
  userName?: string;
  password?: string;
  enablePush?: string;
  authenticationType?: number;
  containerId?: string;
}

export interface AddCompanyassetClass {
  id: string;
  text: string;
}

export function checkIfPushMechanismRequired(IAMemberType: string, AssetClasses: string[]): boolean {
  return (
    (IAMemberType === 'Buyside' || IAMemberType === 'IaThirdPartyVendor') &&
    AssetClasses.findIndex(ac => ac === 'Equity') > -1
  );
}
