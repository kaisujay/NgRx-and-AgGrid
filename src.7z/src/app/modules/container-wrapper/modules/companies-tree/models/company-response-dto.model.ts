export interface CompanyResponseDto {
  name: string;
  pmid: string;
  lei: string;
  orionId: number;
  companyType: string;
  address1: string;
  address2: string;
  address3: string;
  metro: string;
  country: string;
  region: string;
  city: string;
  state: string;
  zipCode: string;
  memberType: string;
  assetClasses: string[];
  searchString?: string;
}
