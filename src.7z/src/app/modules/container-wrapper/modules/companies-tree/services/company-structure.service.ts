import { CompanyInfoModel, CompanyInfoWrapModel } from '../models/company-info.model';

export class CompanyStructureService {
  public static wrapCompanies(structure: CompanyInfoModel[]): CompanyInfoWrapModel[] {
    return structure.map(company => {
      return {
        model: {
          ...company,
          ChildCompanies:
            company.ChildCompanies.length > 0 ? CompanyStructureService.wrapCompanies(company.ChildCompanies) : []
        },
        isOpen: false,
        isContextMenuOpen: false
      };
    });
  }

  public static toggleCompany(structure: CompanyInfoWrapModel[], id: string): CompanyInfoWrapModel[] {
    let companies = <CompanyInfoWrapModel[]>JSON.parse(JSON.stringify(structure));

    for (const company of companies) {
      const result = this.findCompanyById(company, id);
      if (result) {
        result.isOpen = !result.isOpen;
      }
    }

    return companies;
  }

  public static collapseAllContextMenu(structure: CompanyInfoWrapModel[]): CompanyInfoWrapModel[] {
    for (const company of structure) {
      company.isContextMenuOpen = false;

      if (company.model.ChildCompanies.length > 0) {
        this.collapseAllContextMenu(company.model.ChildCompanies);
      }
    }

    return structure;
  }

  public static toggleContextMenu(structure: CompanyInfoWrapModel[], id: string): CompanyInfoWrapModel[] {
    for (const company of structure) {
      if (company.model.CompanyId === id) {
        company.isContextMenuOpen = !company.isContextMenuOpen;
      } else {
        company.isContextMenuOpen = false;
      }

      if (company.model.ChildCompanies.length > 0) {
        this.toggleContextMenu(company.model.ChildCompanies, id);
      }
    }

    return structure;
  }

  private static findCompanyById(company: CompanyInfoWrapModel, id: string): CompanyInfoWrapModel {
    if (!company) {
      return null;
    }

    if (company.model.CompanyId === id) {
      return company;
    }

    if (company.model.ChildCompanies && company.model.ChildCompanies.length > 0) {
      for (const childCompany of company.model.ChildCompanies) {
        const result = this.findCompanyById(childCompany, id);
        if (result) {
          return result;
        }
      }
    }

    return null;
  }
}
