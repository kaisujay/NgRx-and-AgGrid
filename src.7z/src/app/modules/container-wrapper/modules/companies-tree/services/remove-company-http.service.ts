import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class DeleteCompanyHttpService {
  public constructor(private http: HttpClient) {}

  public deleteCompany(companyId: string): Observable<{}> {
    return this.http.delete<{}>(`api/Companies/${companyId}`);
  }
}
