import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DeletedCompanyDto } from '../models/deleted-company-dto.model';

@Injectable()
export class RestoreCompanyHttpService {
  public constructor(private http: HttpClient) {}

  public getDeletedCompanies(containerId: string): Observable<DeletedCompanyDto[]> {
    return this.http.get<DeletedCompanyDto[]>(`api/Archive/CompaniesInContainer/${containerId}`);
  }

  public restoreCompany(archiveId: string): Observable<{}> {
    return this.http.put<{}>(`api/Companies/${archiveId}/UnDelete`, {});
  }
}
