import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddCompanyDto } from '../models/add-company-dto.model';

@Injectable()
export class AddCompanyHttpService {
  public constructor(private http: HttpClient) {}

  public post(addCompanyDto: AddCompanyDto): Observable<{}> {
    return this.http.post<AddCompanyDto>('api/Companies', addCompanyDto);
  }
}
