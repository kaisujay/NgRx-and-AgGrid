import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { CompanyInfoModel } from '../models/company-info.model';

@Injectable()
export class CompaniesTreeHttpService {
  public constructor(private http: HttpClient) {}
  public get(id: string): Observable<CompanyInfoModel[]> {
    const url = buildApiString(API.containers.structure, { id });
    return this.http.get<CompanyInfoModel[]>(url);
  }
}
