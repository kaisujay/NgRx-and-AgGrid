import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { IListItem, IListSearchResult } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { CloseModalsAction, RestoreCompanyAction } from '@state/actions/companies-tree.actions';
import { CompaniesTreeState, getCompaniesTreeState } from '@state/reducers/companies-tree.reducer';
import { EMPTY, Observable, map } from 'rxjs';

@Component({
  selector: 'app-restore-company',
  templateUrl: 'restore-company.component.html',
  styleUrls: ['restore-company.component.scss']
})
export class RestoreCompanyComponent implements OnInit {
  public companiesTreeState$: Observable<CompaniesTreeState>;
  public searchResult$: Observable<IListSearchResult>;
  public selectedItems$: Observable<IListItem[]> = EMPTY;
  public currentItem: IListItem = null;

  public constructor(
    private store$: Store,
    private route: ActivatedRoute
  ) {}

  public ngOnInit(): void {
    this.companiesTreeState$ = this.store$.pipe(select(getCompaniesTreeState));
    this.searchResult$ = this.companiesTreeState$.pipe(
      map(s => ({
        items: s.deletedCompanies.map(
          c =>
            <IListItem>{
              id: c.ArchiveId,
              text: c.CompanyName
            }
        ),
        isLoading: false,
        isTooManyResults: false
      }))
    );
  }

  public onSelectionChanged(event): void {
    this.currentItem = event.added[0];
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }

  public onRestoreCompany(): void {
    const containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');

    this.store$.dispatch(
      new RestoreCompanyAction({
        achieveId: this.currentItem.id,
        containerId
      })
    );
  }
}
