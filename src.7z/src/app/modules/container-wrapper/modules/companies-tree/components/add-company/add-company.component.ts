import { HttpClient } from '@angular/common/http';
import { AfterViewChecked, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { flatten, isNullOrUndefined } from '@core/utils/util';
import { CupcakeFlavors, IListSearchResult, SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { AssetClasses } from '@shared/models/asset-class.model';
import { MemberTypes } from '@shared/models/member-type.model';
import { CupcakeSuggesterComponent } from '@shared/modules/cupcake-suggester/cupcake-suggester.component';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { AddCompanyAction, CloseModalsAction } from '@state/actions/companies-tree.actions';
import { CompaniesTreeState, getCompaniesTreeState } from '@state/reducers/companies-tree.reducer';
import { getContainerWrapperName } from '@state/reducers/container-wrapper.reducer';
import { Observable, Subscription, catchError, combineLatest, map, of, tap } from 'rxjs';
import { checkIfPushMechanismRequired } from '../../models/add-company-dto.model';
import { CompanyInfoWrapModel } from '../../models/company-info.model';
import { CompanyResponseDto } from '../../models/company-response-dto.model';

@Component({
  selector: 'app-add-company',
  templateUrl: 'add-company.component.html',
  styleUrls: ['add-company.component.scss']
})
export class AddCompanyComponent implements OnInit, AfterViewChecked {
  public companiesTreeState$: Observable<CompaniesTreeState>;
  public assesClassesSearchResult$: Observable<IListSearchResult>;
  public addCompanyFormGroup: FormGroup;
  public memberTypesOptions: SelectOptions[] = [
    ...MemberTypes.map(mt => ({ value: `${mt.value}`, label: `${mt.label}` }))
  ];
  public parentCompaniesOptions$: Observable<SelectOptions[]>;
  private containerId: string;
  private checkDeletedCompanies: string[];
  private checkExistingCompanies: string[];
  public isLoadError$: Observable<boolean> = of(false);
  public apiSettingsSelectedIndex = 0;
  public containerName: string;
  public subscriptions: Subscription[] = [];

  @ViewChild(CupcakeSuggesterComponent)
  private suggesterComponent: CupcakeSuggesterComponent;

  public constructor(
    private store$: Store,
    private formBuilder: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private http: HttpClient,
    private route: ActivatedRoute,
    private messageAlertSvc: MessageAlertService
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.companiesTreeState$ = this.store$.pipe(
      select(getCompaniesTreeState),
      tap(cts => {
        if (!isNullOrUndefined(cts.preselectedParentCompanyId)) {
          this.addCompanyFormGroup.patchValue({
            parentCompany: cts.preselectedParentCompanyId
          });
        }
      })
    );

    this.assesClassesSearchResult$ = of({
      isLoading: false,
      isTooManyResults: false,
      items: [...AssetClasses.map(ac => ({ id: `${ac}`, text: `${ac}` }))]
    });

    this.parentCompaniesOptions$ = this.companiesTreeState$.pipe(
      map(({ structure }) => {
        if (structure?.length) {
          return flatten(structure, el => el.model.ChildCompanies).map(({ model }) => ({
            value: model.CompanyId.toString(),
            label: model.Name
          }));
        }
        return [];
      })
    );
    this.subscribeToContainerDetails();
    this.subscribeToFormValueChanges();
  }

  private subscribeToContainerDetails(): void {
    this.subscriptions.push(
      this.store$.select(getContainerWrapperName).subscribe(containerName => {
        this.containerName = containerName;
      })
    );
  }

  public ngAfterViewChecked(): void {
    // fix for cupcake-suggester console error
    this.changeDetectorRef.detectChanges();
  }

  public onClose(): void {
    this.addCompanyFormGroup.reset();
    this.store$.dispatch(new CloseModalsAction());
  }

  public onAddCompany(): void {
    const formModel = this.addCompanyFormGroup.getRawValue();
    this.store$.dispatch(new AddCompanyAction({ ...formModel, containerId: this.containerId }));
  }

  public subscribeToFormValueChanges(): void {
    const memberTypeChanges = this.addCompanyFormGroup.get('memberType').valueChanges;
    const assetClassesChanges = this.addCompanyFormGroup.get('assetClasses').valueChanges;
    this.subscriptions.push(
      combineLatest([memberTypeChanges, assetClassesChanges]).subscribe(([_, __]) => {
        this.updatePushApiFormValidity();
      })
    );
  }

  private updatePushApiFormValidity(): void {
    if (
      this.apiSettingsSelectedIndex === 2 &&
      checkIfPushMechanismRequired(this.addCompanyFormGroup.get('memberType').value, this.getAssetClassValues())
    ) {
      this.setControlValidity('Url', true);
      this.setControlValidity('UserName', true);
      this.setControlValidity('Password', true);
      this.addCompanyFormGroup.get('enablePush').setValue(true);
      this.addCompanyFormGroup.get('authenticationType').setValue(0);
      this.addCompanyFormGroup.get('Url').updateValueAndValidity();
      this.addCompanyFormGroup.get('UserName').updateValueAndValidity();
      this.addCompanyFormGroup.get('Password').updateValueAndValidity();
    } else {
      this.setControlValidity('Url', false);
      this.setControlValidity('UserName', false);
      this.setControlValidity('Password', false);
      this.addCompanyFormGroup.get('enablePush').setValue(false);
      this.addCompanyFormGroup.get('authenticationType').setValue(null);
      this.addCompanyFormGroup.get('Url').setValue('');
      this.addCompanyFormGroup.get('UserName').setValue('');
      this.addCompanyFormGroup.get('Password').setValue('');
    }
  }

  private getAssetClassValues(): string[] {
    return this.addCompanyFormGroup.get('assetClasses').value?.map(ac => ac.id);
  }

  private setControlValidity(controlName: string, setValidators: boolean): void {
    if (setValidators) {
      this.addCompanyFormGroup.get(controlName).setValidators([Validators.required]);
    } else {
      this.addCompanyFormGroup.get(controlName).clearValidators();
    }
  }

  private initForm(): void {
    this.addCompanyFormGroup = this.formBuilder.group({
      parentCompany: new FormControl('', []),
      name: new FormControl('', [Validators.required]),
      pmid: new FormControl({ value: '', disabled: true }, []),
      lei: new FormControl({ value: '', disabled: true }, []),
      orionId: new FormControl({ value: '', disabled: true }, []),
      companyType: new FormControl({ value: '', disabled: true }, []),
      memberType: new FormControl('', []),
      assetClasses: new FormControl([''], []),
      address1: new FormControl({ value: '', disabled: true }, []),
      address2: new FormControl({ value: '', disabled: true }, []),
      address3: new FormControl({ value: '', disabled: true }, []),
      city: new FormControl({ value: '', disabled: true }, []),
      metro: new FormControl({ value: '', disabled: true }, []),
      state: new FormControl({ value: '', disabled: true }, []),
      zipCode: new FormControl({ value: '', disabled: true }, []),
      country: new FormControl({ value: '', disabled: true }, []),
      region: new FormControl({ value: '', disabled: true }, []),
      staffCount: new FormControl({ value: '', disabled: true }, []),
      totalAssetsUnderMgt: new FormControl({ value: '', disabled: true }, []),
      fiAssetsUnderMgt: new FormControl({ value: '', disabled: true }, []),
      eqAssetsUnderMgt: new FormControl({ value: '', disabled: true }, []),
      alternativeCompanyName: new FormControl({ value: '', disabled: true }, []),
      Url: new FormControl({ value: '', disabled: false }, []),
      UserName: new FormControl({ value: '', disabled: false }, []),
      Password: new FormControl({ value: '', disabled: false }, []),
      enablePush: new FormControl({ value: '', disabled: true }, []),
      authenticationType: new FormControl({ value: '', disabled: true }, [])
    });
  }

  public observableSource(): Observable<CompanyResponseDto[]> {
    this.companiesTreeState$.subscribe(datas => {
      this.checkDeletedCompanies = datas.deletedCompanies.map(data => data.CompanyName);
      this.checkExistingCompanies = this.getExistingCompaniesNames(datas.structure || []);
    });

    const searchText = this.suggesterComponent?.inputValue ?? '';
    return this.http.get<CompanyResponseDto[]>(`api/company-search?searchText=${searchText}`).pipe(
      map(datas => datas.filter(data => !this.checkDeletedCompanies.includes(data.name))),
      map(datas => datas.map(data => ({ ...data, searchString: data.name + data.pmid + data.orionId }))),
      catchError(err => {
        this.isLoadError$ = of(true);
        return of({ ...err });
      })
    );
  }

  private getExistingCompaniesNames(companiesData: CompanyInfoWrapModel[]): string[] {
    return companiesData.length
      ? companiesData.reduce((acc, curr) => {
          acc.push(curr.model.Name);
          if (curr.model.ChildCompanies.length) {
            acc.push(...this.getExistingCompaniesNames(curr.model.ChildCompanies));
          }
          return acc;
        }, [])
      : [];
  }

  public suggesterOnSelect(companies: CompanyResponseDto[]): void {
    const currentValue = this.addCompanyFormGroup.getRawValue();
    const company = companies[0];
    if (companies.length > 0) {
      if (!this.checkExistingCompanies.includes(company.name)) {
        this.addCompanyFormGroup.get('name').setErrors(null);
        company?.searchString ? delete company.searchString : null;
        this.addCompanyFormGroup.setValue({ ...currentValue, ...company });
        this.addCompanyFormGroup.markAsTouched();
      } else {
        this.addCompanyFormGroup.get('name').setErrors({ companyExists: true });
        this.messageAlertSvc.showMessageAlert(
          CupcakeFlavors.Danger,
          `Company already exists in the container ${this.containerName}`
        );
      }
    } else {
      this.addCompanyFormGroup.reset({
        parentCompany: currentValue.parentCompany
      });
    }
  }

  public onTabIndexChange(event: number): void {
    this.apiSettingsSelectedIndex = event;
    this.updatePushApiFormValidity();
  }

  public isCompanySelected({ value }: { value: string }) {
    return !!value;
  }
}
