import { Component, Input, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';

import { ActivatedRoute, Router } from '@angular/router';
import { ModalService, ModalType } from '@ipreo/ngx-sprinkles';
import {
  AddCompanyModalOpenAction,
  CheckDeletedCompaniesAction,
  CollapseAllContextMenuAction,
  RemoveCompanyAction,
  ToggleCompanyAction,
  ToggleCompanyContextMenuAction
} from '@state/actions/companies-tree.actions';
import { CompaniesTreeState, getCompaniesTreeState } from '@state/reducers/companies-tree.reducer';
import { Observable, tap } from 'rxjs';
import { CompanyInfoWrapModel } from '../../models/company-info.model';

@Component({
  selector: 'app-companies-table',
  templateUrl: 'company-table.component.html',
  styleUrls: ['company-table.component.scss']
})
export class CompanyTableComponent implements OnInit {
  @Input() public companies: CompanyInfoWrapModel[];

  public companiesTreeState$: Observable<CompaniesTreeState>;

  public constructor(
    private store$: Store,
    private route: ActivatedRoute,
    private router: Router,
    private modalService: ModalService
  ) {}

  public ngOnInit(): void {
    const containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');

    this.companiesTreeState$ = this.store$.pipe(
      select(getCompaniesTreeState),
      tap(state => {
        if (state.isRemoveSuccess) {
          this.store$.dispatch(new CheckDeletedCompaniesAction(containerId));
        }
      })
    );
  }

  public toggleCompany(id: string): void {
    this.store$.dispatch(new ToggleCompanyAction({ id }));
  }

  public toggleCompanyContextMenu(id: string): void {
    this.store$.dispatch(new ToggleCompanyContextMenuAction({ id }));
  }

  public clickOutside(): void {
    this.store$.dispatch(new CollapseAllContextMenuAction());
  }

  public addChild(company: CompanyInfoWrapModel): void {
    this.store$.dispatch(
      new AddCompanyModalOpenAction({
        parentCompanyId: company.model.CompanyId
      })
    );
  }

  public removeCompany(company: CompanyInfoWrapModel): void {
    const containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');

    this.modalService.create({
      type: ModalType.Dialog,
      cancelButtonText: 'Cancel',
      submitButtonText: 'Remove',
      title: 'Remove Company',
      content: `Are you sure you want to remove company: ${company.model.Name} ?`,
      closeButton: true,
      submitButtonAction: () => {
        this.store$.dispatch(
          new RemoveCompanyAction({
            companyId: company.model.CompanyId,
            containerId
          })
        );
      }
    });
  }

  public gotoCompanyDetails(id: string) {
    const containerId = this.router.url.replace('/tree', '');
    this.router.navigate([`${containerId}/company/${id}/details`]);
  }

  public gotoCompanyConnections(id: string) {
    const containerId = this.router.url.replace('/tree', '');
    this.router.navigate([`${containerId}/company/${id}/connections`]);
  }

  public gotoCompanyMembers(id: string) {
    const containerId = this.router.url.replace('/tree', '');
    this.router.navigate([`${containerId}/company/${id}/members`]);
  }
}
