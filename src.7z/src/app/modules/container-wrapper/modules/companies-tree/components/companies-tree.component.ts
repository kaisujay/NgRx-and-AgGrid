import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';
import {
  AddCompanyModalOpenAction,
  CheckDeletedCompaniesAction,
  LoadAction,
  LoadDeletedCompaniesAction
} from '@state/actions/companies-tree.actions';
import { CompaniesTreeState, getCompaniesTreeState } from '@state/reducers/companies-tree.reducer';
import { Observable } from 'rxjs';
import { CompanyDetailsModalService } from '../../company-details/services/company-details.modal.service';

@Component({
  selector: 'app-companies-tree',
  templateUrl: 'companies-tree.component.html',
  styleUrls: ['companies-tree.component.scss']
})
export class CompaniesTreeComponent implements OnInit {
  public companiesTreeState$: Observable<CompaniesTreeState>;
  public containerId: string;

  public constructor(
    private store$: Store,
    private modalService: CompanyDetailsModalService,
    private route: ActivatedRoute
  ) {}

  public ngOnInit(): void {
    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.companiesTreeState$ = this.store$.pipe(select(getCompaniesTreeState));

    this.store$.dispatch(
      new LoadAction({
        id: this.route.snapshot.parent.parent.paramMap.get('containerId')
      })
    );
    this.store$.dispatch(new CheckDeletedCompaniesAction(this.containerId));
    this.modalService.sendCompanyName('');
  }

  public onAddCompany(): void {
    this.store$.dispatch(new AddCompanyModalOpenAction({}));
  }

  public onRestoreCompany(): void {
    const containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.store$.dispatch(new LoadDeletedCompaniesAction({ containerId }));
  }
}
