import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, map, of } from 'rxjs';
import { IntegrationServicesComponent } from '../components/integration-services.component';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { UnsavedChangesAlertComponent } from '@shared/components/unsaved-changes-alert/unsaved-changes-alert.component';
import { UnsavedChangesAlertActions } from '@shared/models/unsaved-change.model';

@Injectable()
export class IntegrationDeactivateGuard implements CanDeactivate<IntegrationServicesComponent> {
  public getValue = '';
  public constructor(private _dialogSvc: DialogService) {}

  public canDeactivate(
    component: IntegrationServicesComponent,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _currentRoute: ActivatedRouteSnapshot,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _currentState: RouterStateSnapshot,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _nextState: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!component.isUnsavedChanges()) {
      const dialogRef = this._dialogSvc.open(UnsavedChangesAlertComponent);
      return this._dialogSvc.responseFromModal().pipe(
        map(action => {
          if (action === UnsavedChangesAlertActions.DISCARD) {
            dialogRef.close();
            return true;
          } else if (action === UnsavedChangesAlertActions.STAY) {
            dialogRef.close();
            return false;
          } else if (action === UnsavedChangesAlertActions.SAVE) {
            component.onSave();
            dialogRef.close();
            return true;
          }
          return false;
        })
      );
    }
    return of(true);
  }
}
