export interface IntegrationServiceResponseModel {
  AvailableVendors: AvailableVendor[];
  FixCompIds: string[];
  SelectedVendorOrionIds: number[];
}

export interface AvailableVendor {
  Name: string;
  Pmid: string;
  OrionId: number;
  HasPermissionToSendhMessageAtOrderLevel: boolean;
}

export interface IntegrationServicePayloadModel {
  companyId: string;
  fixCompIds: string[];
  selectedVendorOrionIds: number[];
}
