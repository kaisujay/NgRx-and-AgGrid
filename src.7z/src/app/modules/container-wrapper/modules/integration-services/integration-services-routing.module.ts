import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IntegrationServicesComponent } from './components/integration-services.component';
import { IntegrationDeactivateGuard } from './guards/integration-deactivate.guard';

const routes: Routes = [
  {
    path: '',
    component: IntegrationServicesComponent,
    canDeactivate: [IntegrationDeactivateGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntegrationServicesRoutingModule {}
