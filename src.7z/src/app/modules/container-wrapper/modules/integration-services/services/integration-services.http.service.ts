import { HttpClient, HttpStatusCode } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { IntegrationServicePayloadModel, IntegrationServiceResponseModel } from '../models/integration-services.model';

@Injectable()
export class IntegrationServicesHttpService {
  public constructor(private http: HttpClient) {}

  public getVendors(companyId: string): Observable<IntegrationServiceResponseModel> {
    const url = buildApiString(API.integrationServices, { companyId });

    return this.http.get<IntegrationServiceResponseModel>(url);
  }

  public postVendors(companyId: string, payload: IntegrationServicePayloadModel): Observable<void> {
    const url = buildApiString(API.integrationServices, { companyId });

    return this.http.post<void>(url, payload);
  }
}
