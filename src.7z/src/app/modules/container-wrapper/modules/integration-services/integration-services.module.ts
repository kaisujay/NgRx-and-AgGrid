import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IntegrationServicesRoutingModule } from './integration-services-routing.module';
import { IntegrationServicesComponent } from './components/integration-services.component';
import { IntegrationServicesHttpService } from './services/integration-services.http.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IconModule, LoaderModule, PopoverModule, SPRFormsModule, TabTemplatePanelModule } from '@ipreo/ngx-sprinkles';
import { AdminSharedModule } from '@shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { SaveIntegrationServicesEffect } from './@states/effects/save-integration-services.effect';
import { LoadIntegrationServicesEffect } from './@states/effects/load-integration-services.effect';
import { IntegrationServicesStateReducer } from './@states/reducers/integration-services.reducer';
import { DialogService } from '@shared/services/dialog/dialog.service';
import { IntegrationDeactivateGuard } from './guards/integration-deactivate.guard';

@NgModule({
  declarations: [IntegrationServicesComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    IconModule,
    LoaderModule,
    PopoverModule,
    TabTemplatePanelModule,
    SPRFormsModule,
    StoreModule.forFeature('integrationServices', IntegrationServicesStateReducer),
    EffectsModule.forFeature([LoadIntegrationServicesEffect, SaveIntegrationServicesEffect]),
    IntegrationServicesRoutingModule
  ],
  providers: [IntegrationServicesHttpService, IntegrationDeactivateGuard, DialogService]
})
export class IntegrationServicesModule {}
