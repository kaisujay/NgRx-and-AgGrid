import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { isNullOrUndefined } from '@core/utils/util';
import { Store, select } from '@ngrx/store';
import { Observable, tap } from 'rxjs';
import {
  ClearIntegrationServicesHttpErrorsAction,
  LoadIntegrationServicesAction,
  SaveIntegrationServicesAction
} from '../@states/actions/integraion-services.action';
import {
  IntegrationServicesState,
  getIntegrationServicesState
} from '../@states/reducers/integration-services.reducer';
import { IntegrationServicePayloadModel, IntegrationServiceResponseModel } from '../models/integration-services.model';

@Component({
  selector: 'app-integration-services',
  templateUrl: './integration-services.component.html',
  styleUrls: ['./integration-services.component.scss']
})
export class IntegrationServicesComponent implements OnInit {
  public integrationServicesState$: Observable<IntegrationServicesState>;

  public integrationServicesFormGroup: FormGroup;
  public integrationServiceResponse: IntegrationServiceResponseModel;
  public initialIntegrationServiceResponse: IntegrationServiceResponseModel;
  public integrationServicePayload: IntegrationServicePayloadModel;
  public companyId: string;
  public selectedOrionIds: number[];
  public selectedFIXSenderCompIds: string[];
  public checkboxSelected: boolean[] = [];
  public checkSelectedOrUnSelected: boolean;
  public checkSelected: boolean;
  public checkUnSelected: boolean;
  public checkboxItemName = 'item';
  public selectedIndex: number;
  public dataLoaded = false;

  public constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    public store$: Store
  ) {}

  public ngOnInit(): void {
    this.subscribeToIntegrationServicesData();
    this.companyId = this.route.snapshot.paramMap.get('companyId');

    this.store$.dispatch(new LoadIntegrationServicesAction(this.companyId));
  }

  public subscribeToIntegrationServicesData(): void {
    this.integrationServicesState$ = this.store$.pipe(
      select(getIntegrationServicesState),
      tap(state => {
        if (state.loadIntegrationServices.isLoaded) {
          this.dataLoaded = true;
          this.integrationServiceResponse = this.deepCopy(state.loadIntegrationServices.data);
          this.initialIntegrationServiceResponse = this.deepCopy(state.loadIntegrationServices.data);

          this.integrationServiceResponse = state.loadIntegrationServices.data;
          this.checkboxSelected.length = this.integrationServiceResponse.AvailableVendors.length;
          this.checkboxSelected.fill(false);

          this.initForm();
        }
        if (state.saveIntegrationServices.isSaved) {
          this.store$.dispatch(new LoadIntegrationServicesAction(this.companyId));
        }
      })
    );
  }

  public initForm() {
    this.integrationServicesFormGroup = this.formBuilder.group({
      None: new FormControl({ value: false, disabled: false }, []),
      checkboxItem: this.formBuilder.array(this.checkboxSelected),
      FIXSenderCompId: new FormControl({ value: '', disabled: false }, [])
    });

    this.updateInitialValues();
  }

  private updateInitialValues() {
    this.dataLoaded = true;
    this.checkboxSelected = [];
    if (!(this.integrationServiceResponse.SelectedVendorOrionIds.length > 0)) {
      this.integrationServicesFormGroup.patchValue({
        None: true
      });
    } else {
      this.integrationServicesFormGroup.patchValue({
        None: false
      });
    }

    this.integrationServiceResponse.AvailableVendors.forEach(data => {
      if (this.integrationServiceResponse.SelectedVendorOrionIds.includes(data.OrionId)) {
        this.checkboxSelected.push(true);
      } else {
        this.checkboxSelected.push(false);
      }
    });

    this.integrationServicesFormGroup.patchValue({
      checkboxItem: this.checkboxSelected,
      FIXSenderCompId: this.integrationServiceResponse.FixCompIds
    });
  }

  public isUnsavedChanges(): boolean {
    this.setSaveValues();

    if (this.initialIntegrationServiceResponse) {
      if (
        JSON.stringify(this.initialIntegrationServiceResponse.SelectedVendorOrionIds.slice().sort()) !==
        JSON.stringify(this.selectedOrionIds.slice().sort())
      ) {
        return false;
      }
      if (
        JSON.stringify(this.initialIntegrationServiceResponse.FixCompIds) == 'null' &&
        JSON.stringify(this.selectedFIXSenderCompIds) == '[""]'
      ) {
        return true;
      }
      if (
        JSON.stringify(this.initialIntegrationServiceResponse.FixCompIds) !==
        JSON.stringify(this.selectedFIXSenderCompIds)
      ) {
        return false;
      }
    }
    return true;
  }

  public onSave() {
    this.saveReady();

    this.store$.dispatch(new SaveIntegrationServicesAction(this.companyId, this.integrationServicePayload));
  }

  public isChecked(event) {
    const isChecked = event.target.checked;

    this.checkSelectedOrUnSelected = isChecked;
    if (isChecked) {
      this.checkSelected = isChecked;
      this.checkUnSelected = !isChecked;
    } else {
      this.checkSelected = isChecked;
      this.checkUnSelected = !isChecked;
    }
  }

  private saveReady() {
    this.setSaveValues();

    this.checkFixCompId();

    this.integrationServicePayload = {
      companyId: this.companyId,
      fixCompIds: this.selectedFIXSenderCompIds,
      selectedVendorOrionIds: this.selectedOrionIds
    };
  }

  public changeSelection(event, index) {
    if (event.target.checked) {
      for (let i = 0; i < this.checkboxSelected.length; i++) {
        if (i == index) {
          this.checkboxSelected[i] = true;
        } else {
          this.checkboxSelected[i] = false;
        }
      }

      this.integrationServicesFormGroup.patchValue({
        None: false,
        checkboxItem: this.checkboxSelected
      });
    } else {
      for (let i = 0; i < this.checkboxSelected.length; i++) {
        this.checkboxSelected[i] = false;
      }

      this.integrationServicesFormGroup.patchValue({
        None: true,
        checkboxItem: this.checkboxSelected
      });
    }
  }

  public isNoneChecked(event) {
    if (event.target.checked) {
      for (let i = 0; i < this.checkboxSelected.length; i++) {
        this.checkboxSelected[i] = false;
      }
      this.integrationServicesFormGroup.patchValue({
        checkboxItem: this.checkboxSelected
      });
    }

    if (this.checkboxSelected.some(x => x === true) === false) {
      this.integrationServicesFormGroup.patchValue({
        None: true
      });
    }
  }

  private setSaveValues() {
    if (this.dataLoaded) {
      this.selectedOrionIds = this.integrationServicesFormGroup.value.checkboxItem
        .map((checked, i) => (checked ? this.integrationServiceResponse.AvailableVendors[i].OrionId : null))
        .filter(v => v !== null);

      if (isNullOrUndefined(this.integrationServicesFormGroup.get('FIXSenderCompId').value)) {
        this.selectedFIXSenderCompIds = null;
      } else {
        const fIXSenderCompIdValue = this.integrationServicesFormGroup
          .get('FIXSenderCompId')
          .value.toString()
          .replace(/^\s*,+\s*|\s*,+\s*$/g, '');
        if (fIXSenderCompIdValue.includes(',')) {
          this.selectedFIXSenderCompIds = fIXSenderCompIdValue.split(',');
        } else {
          this.selectedFIXSenderCompIds = [fIXSenderCompIdValue];
        }
      }
    }
  }

  private checkFixCompId() {
    if (isNullOrUndefined(this.selectedFIXSenderCompIds) || this.selectedFIXSenderCompIds[0] === '') {
      this.selectedFIXSenderCompIds = [];
    }
  }

  public onErrorModalClose() {
    this.store$.dispatch(new ClearIntegrationServicesHttpErrorsAction());
  }

  public onCancel() {
    this.updateInitialValues();
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public deepCopy(oldObj: any) {
    let newObj = oldObj;
    if (oldObj && typeof oldObj === 'object') {
      if (oldObj instanceof Date) {
        return new Date(oldObj.getTime());
      }
      newObj = Object.prototype.toString.call(oldObj) === '[object Array]' ? [] : {};
      for (const i in oldObj) {
        newObj[i] = this.deepCopy(oldObj[i]);
      }
    }
    return newObj;
  }
}
