import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { IntegrationServicesHttpService } from '../../services/integration-services.http.service';
import {
  IntegrationServicesActionTypes,
  SaveIntegrationServicesAction,
  SaveIntegrationServicesFailedAction,
  SaveIntegrationServicesSuccessAction
} from '../actions/integraion-services.action';

@Injectable()
export class SaveIntegrationServicesEffect {
  public constructor(
    private actions$: Actions,
    private http: IntegrationServicesHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveIntegrationServicesEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(IntegrationServicesActionTypes.SaveIntegrationServices),
      switchMap((action: SaveIntegrationServicesAction) => {
        return this.http.postVendors(action.companyId, action.payload).pipe(
          map(_ => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Integration Services Saved Successfully');
            return new SaveIntegrationServicesSuccessAction();
          }),
          catchError(err => {
            this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error While Saving Integration Services');
            return of(new SaveIntegrationServicesFailedAction(err));
          })
        );
      })
    )
  );
}
