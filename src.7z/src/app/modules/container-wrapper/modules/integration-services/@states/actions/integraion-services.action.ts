import { Action } from '@ngrx/store';
import {
  IntegrationServicePayloadModel,
  IntegrationServiceResponseModel
} from '../../models/integration-services.model';

export enum IntegrationServicesActionTypes {
  LoadIntegrationServices = '[Integration Services] Load Integration Services',
  LoadIntegrationServicesSuccess = '[Integration Services] Load Integration Services Success',
  LoadIntegrationServicesFailed = '[Integration Services] Load Integration Services Failed',

  SaveIntegrationServices = '[Integration Services] Save Integration Services',
  SaveIntegrationServicesSuccess = '[Integration Services] Save Integration Services Success',
  SaveIntegrationServicesFailed = '[Integration Services] Save Integration Services Failed',

  ClearIntegrationServicesHttpErrors = '[Integration Services] Clear Integration Services Http Errors'
}

export class LoadIntegrationServicesAction implements Action {
  public readonly type = IntegrationServicesActionTypes.LoadIntegrationServices;
  public constructor(public companyId: string) {}
}

export class LoadIntegrationServicesSuccessAction implements Action {
  public readonly type = IntegrationServicesActionTypes.LoadIntegrationServicesSuccess;
  public constructor(public payload: IntegrationServiceResponseModel) {}
}

export class LoadIntegrationServicesFailedAction implements Action {
  public readonly type = IntegrationServicesActionTypes.LoadIntegrationServicesFailed;
  public constructor(public error: string) {}
}

export class SaveIntegrationServicesAction implements Action {
  public readonly type = IntegrationServicesActionTypes.SaveIntegrationServices;
  public constructor(
    public companyId: string,
    public payload: IntegrationServicePayloadModel
  ) {}
}

export class SaveIntegrationServicesSuccessAction implements Action {
  public readonly type = IntegrationServicesActionTypes.SaveIntegrationServicesSuccess;
  public constructor() {}
}

export class SaveIntegrationServicesFailedAction implements Action {
  public readonly type = IntegrationServicesActionTypes.SaveIntegrationServicesFailed;
  public constructor(public error: string) {}
}

export class ClearIntegrationServicesHttpErrorsAction implements Action {
  public readonly type = IntegrationServicesActionTypes.ClearIntegrationServicesHttpErrors;
  public constructor() {}
}

export type IntegrationServicesActionsUnion =
  | LoadIntegrationServicesAction
  | LoadIntegrationServicesSuccessAction
  | LoadIntegrationServicesFailedAction
  | SaveIntegrationServicesAction
  | SaveIntegrationServicesSuccessAction
  | SaveIntegrationServicesFailedAction
  | ClearIntegrationServicesHttpErrorsAction;
