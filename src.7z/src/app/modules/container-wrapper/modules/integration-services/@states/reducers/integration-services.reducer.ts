import { createFeatureSelector } from '@ngrx/store';
import { IntegrationServiceResponseModel } from '../../models/integration-services.model';
import { IntegrationServicesActionTypes, IntegrationServicesActionsUnion } from '../actions/integraion-services.action';

export interface IntegrationServicesState {
  loadIntegrationServices: {
    data: IntegrationServiceResponseModel;
    isLoading: boolean;
    isLoaded: boolean;
    error: string;
  };
  saveIntegrationServices: {
    // data: IntegrationServiceResponseModel;
    isSaving: boolean;
    isSaved: boolean;
    error: string;
  };
}

export const initialState: IntegrationServicesState = {
  loadIntegrationServices: {
    data: null,
    isLoading: false,
    isLoaded: false,
    error: null
  },
  saveIntegrationServices: {
    // data: null,
    isSaving: false,
    isSaved: false,
    error: null
  }
};

export function IntegrationServicesStateReducer(
  state: IntegrationServicesState = initialState,
  action: IntegrationServicesActionsUnion
): IntegrationServicesState {
  switch (action.type) {
    case IntegrationServicesActionTypes.LoadIntegrationServices:
      return {
        ...state,
        loadIntegrationServices: {
          ...state.loadIntegrationServices,
          isLoading: true,
          isLoaded: false,
          error: null
        },
        saveIntegrationServices: {
          ...state.saveIntegrationServices,
          isSaved: false,
          isSaving: false
        }
      };
    case IntegrationServicesActionTypes.LoadIntegrationServicesSuccess:
      return {
        ...state,
        loadIntegrationServices: {
          // ...action.payload,
          data: action.payload,
          isLoading: false,
          isLoaded: true,
          error: null
        },
        saveIntegrationServices: {
          ...state.saveIntegrationServices,
          isSaved: false,
          isSaving: false
        }
      };
    case IntegrationServicesActionTypes.LoadIntegrationServicesFailed:
      return {
        ...state,
        loadIntegrationServices: {
          ...state.loadIntegrationServices,
          isLoading: false,
          isLoaded: false,
          error: action.error
        }
      };
    case IntegrationServicesActionTypes.SaveIntegrationServices:
      return {
        ...state,
        loadIntegrationServices: {
          ...state.loadIntegrationServices,
          isLoading: false,
          isLoaded: false
        },
        saveIntegrationServices: {
          ...state.loadIntegrationServices,
          isSaving: true,
          isSaved: false,
          error: null
        }
      };
    case IntegrationServicesActionTypes.SaveIntegrationServicesSuccess:
      return {
        ...state,
        loadIntegrationServices: {
          ...state.loadIntegrationServices,
          isLoading: false,
          isLoaded: false
        },
        saveIntegrationServices: {
          // data: state.loadIntegrationServices.data,
          isSaving: false,
          isSaved: true,
          error: null
        }
      };
    case IntegrationServicesActionTypes.SaveIntegrationServicesFailed:
      return {
        ...state,
        saveIntegrationServices: {
          // data: state.loadIntegrationServices.data,
          isSaving: false,
          isSaved: false,
          error: action.error
        }
      };

    case IntegrationServicesActionTypes.ClearIntegrationServicesHttpErrors:
      return {
        ...state,
        saveIntegrationServices: {
          // data: state.loadIntegrationServices.data,
          isSaving: false,
          isSaved: false,
          error: null
        }
      };

    default:
      return state;
  }
}

export const getIntegrationServicesState = createFeatureSelector<IntegrationServicesState>('integrationServices');
