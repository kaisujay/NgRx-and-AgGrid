import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { IntegrationServicesHttpService } from '../../services/integration-services.http.service';
import {
  IntegrationServicesActionTypes,
  LoadIntegrationServicesAction,
  LoadIntegrationServicesFailedAction,
  LoadIntegrationServicesSuccessAction
} from '../actions/integraion-services.action';

@Injectable()
export class LoadIntegrationServicesEffect {
  public constructor(
    private actions$: Actions,
    private http: IntegrationServicesHttpService
  ) {}

  public loadIntegrationServicesEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(IntegrationServicesActionTypes.LoadIntegrationServices),
      switchMap((action: LoadIntegrationServicesAction) => {
        return this.http.getVendors(action.companyId).pipe(
          map(data => new LoadIntegrationServicesSuccessAction(data)),
          catchError(err => of(new LoadIntegrationServicesFailedAction(err)))
        );
      })
    )
  );
}
