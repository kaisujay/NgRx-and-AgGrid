import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CompanyDetailsModel } from '../../company-details/models/company-details.model';
import { CompanyPermissionsResponse } from '../../company-permissions/models/permission-state.model';
import { IndivisualUserModel } from '../../user-pool/models/create-new-user.model';
import {
  AddEditMembershipPayloadModel,
  MembershipPermissionsModel,
  MembershipsResponseModel
} from '../models/company-members.model';

@Injectable()
export class CompanyMembersHttpService {
  public constructor(
    private http: HttpClient,
    private store: Store
  ) {}

  public getCompanies(id: string): Observable<CompanyDetailsModel> {
    const url = buildApiString(API.companies.get, { id });
    return this.http.get<CompanyDetailsModel>(url);
  }

  public getUserDetails(id: string): Observable<IndivisualUserModel> {
    const url = buildApiString(API.companyMembership.getUserDetails, { id });

    return this.http.get<IndivisualUserModel>(url);
  }

  public deleteMembership(companyId: string, userId: string): Observable<MembershipsResponseModel> {
    const url = buildApiString(API.companyMembership.deleteMembership, {
      companyId,
      userId
    });

    return this.http.delete<MembershipsResponseModel>(url);
  }

  public getListOfPossibleNewMemberships(id: string): Observable<MembershipsResponseModel[]> {
    const url = buildApiString(API.companyMembership.getListOfPossibleNewMemberships, { id });

    return this.http.get<MembershipsResponseModel[]>(url);
  }

  public postAddMembership(
    id: string,
    payload: Partial<AddEditMembershipPayloadModel>
  ): Observable<MembershipsResponseModel> {
    const url = buildApiString(API.companyMembership.postAddMembership, { id });

    return this.http.post<MembershipsResponseModel>(url, payload);
  }

  public createNewMemberPermission(payload: AddEditMembershipPayloadModel): Observable<MembershipPermissionsModel> {
    const url = buildApiString(API.companyMembership.updateMemberPermissions, {
      companyId: payload.CompanyId,
      userId: payload.UserId
    });
    return this.http.put<MembershipPermissionsModel>(url, payload);
  }

  public getCompanyPermissions(companyId: string): Observable<CompanyPermissionsResponse> {
    return this.http.get<CompanyPermissionsResponse>(API.permissions.get.replace(':id', companyId));
  }

  public getUserFeaturePermissions(companyId: string, userId: string): Observable<MembershipPermissionsModel> {
    const url = buildApiString(API.companyMembership.getMemberPermissions, {
      companyId: companyId,
      userId: userId
    });
    return this.http.get<MembershipPermissionsModel>(url);
  }

  public updateMemberFeaturePermissions(
    payload: AddEditMembershipPayloadModel
  ): Observable<MembershipPermissionsModel> {
    const url = buildApiString(API.companyMembership.updateMemberPermissions, {
      companyId: payload.CompanyId,
      userId: payload.UserId
    });
    return this.http.put<MembershipPermissionsModel>(url, payload);
  }
}
