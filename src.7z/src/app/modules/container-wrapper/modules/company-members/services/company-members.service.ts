import { MembershipsResponseModel } from '../models/company-members.model';

export class CompanyMembersService {
  public static getMemberEmailOptions(memberEmail: MembershipsResponseModel[]): { label: string; value: string }[] {
    if (!memberEmail || !memberEmail.length) {
      return [];
    }

    return memberEmail.map(memberEmails => {
      return {
        label: memberEmails.Email,
        value: memberEmails.Email
      };
    });
  }
}
