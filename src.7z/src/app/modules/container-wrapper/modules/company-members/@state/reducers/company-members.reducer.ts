import { createFeatureSelector, createSelector } from '@ngrx/store';
import { CompanyDetailsModel } from '../../../company-details/models/company-details.model';
import { CompanyPermissionsModel } from '../../../company-permissions/models/permission-state.model';
import { IndivisualUserModel } from '../../../user-pool/models/create-new-user.model';
import {
  CompanyMembersModalType,
  CompanyMembersModalTypes,
  ItemModel,
  MembershipsResponseModel
} from '../../models/company-members.model';
import { CompanyMembersActionTypes, CompanyMembersActionsUnion } from '../actions/company-members.action';

export interface CompanyMembersState {
  data: {
    loadCompanyMembers: {
      rowData: ItemModel[];
      rowCount: number;
    };
    isLoading: boolean;
    isLoaded: boolean;
    isError: boolean;
  };
  exportToXLSX: {
    isExporting: boolean;
    isError: boolean;
  };
  companyDetailsModel: {
    data: CompanyDetailsModel;
    isLoading: boolean;
    isLoaded: boolean;
    isError: boolean;
  };
  editMember: {
    userData: IndivisualUserModel;
    isLoading: boolean;
    isDataLoaded: boolean;
    isDataLoadError: boolean;
    isSaving: boolean;
    isSaveSuccess: boolean;
    isSavingError: boolean;
  };
  removeMember: {
    isRemoveMode: boolean;
    isRemoving: boolean;
  };
  addMember: {
    data: {
      possibleNewMembers: MembershipsResponseModel[];
      isDataLoaded: boolean;
      isDataLoading: boolean;
      dataLoadError: string;
    };
    isSaving: boolean;
    isSaveSuccess: boolean;
    error: string;
  };
  companyPermissions: {
    isError: boolean;
    permissions: CompanyPermissionsModel;
  };
  companyMemberModalType: CompanyMembersModalType;
}

export const initAddMember = {
  data: {
    possibleNewMembers: null,
    isDataLoading: false,
    isDataLoaded: false,
    dataLoadError: null
  },
  isSaveSuccess: false,
  isSaving: false,
  error: null
};
export const initEditMember = {
  userData: null,
  isLoading: false,
  isDataLoaded: false,
  isDataLoadError: false,
  isSaving: false,
  isSaveSuccess: false,
  isSavingError: false
};

export const initialState: CompanyMembersState = {
  data: {
    loadCompanyMembers: {
      rowData: [],
      rowCount: 0
    },
    isLoading: false,
    isLoaded: false,
    isError: false
  },
  exportToXLSX: {
    isExporting: false,
    isError: false
  },
  companyDetailsModel: {
    data: null,
    isLoading: false,
    isLoaded: false,
    isError: false
  },
  addMember: initAddMember,
  editMember: initEditMember,
  removeMember: {
    isRemoveMode: false,
    isRemoving: false
  },
  companyPermissions: {
    isError: false,
    permissions: null
  },
  companyMemberModalType: null
};

export function CompanyMembersStateReducer(
  state: CompanyMembersState = initialState,
  action: CompanyMembersActionsUnion
): CompanyMembersState {
  switch (action.type) {
    case CompanyMembersActionTypes.LoadCompanyMembersSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          loadCompanyMembers: {
            ...action.payload
          },
          isLoading: false,
          isLoaded: true,
          isError: false
        }
      };
    case CompanyMembersActionTypes.LoadCompanyMembersFailed:
      return {
        ...state,
        data: {
          ...state.data,
          isLoading: false,
          isLoaded: false,
          isError: true
        }
      };
    case CompanyMembersActionTypes.ExportToXLSX:
      return {
        ...state,
        exportToXLSX: {
          isExporting: true,
          isError: false
        }
      };
    case CompanyMembersActionTypes.ExportToXLSXSuccess:
    case CompanyMembersActionTypes.ExportToXLSXFailed:
      return {
        ...state,
        exportToXLSX: {
          isExporting: false,
          isError: true
        }
      };
    case CompanyMembersActionTypes.LoadCompanyDetails:
      return {
        ...state,
        companyDetailsModel: {
          ...state.companyDetailsModel,
          isLoading: true,
          isLoaded: false,
          isError: false
        }
      };

    case CompanyMembersActionTypes.LoadCompanyDetailsSuccess:
      return {
        ...state,
        companyDetailsModel: {
          data: {
            ...action.payload
          },
          isLoading: false,
          isLoaded: true,
          isError: false
        }
      };

    case CompanyMembersActionTypes.LoadCompanyDetailsFailed:
      return {
        ...state,
        companyDetailsModel: {
          ...state.companyDetailsModel,
          isLoading: false,
          isLoaded: false,
          isError: true
        }
      };

    case CompanyMembersActionTypes.LoadEditMember:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          isLoading: true
        },
        addMember: {
          ...state.addMember
        },
        companyMemberModalType: CompanyMembersModalTypes.EDIT
      };

    case CompanyMembersActionTypes.LoadEditMemberSuccess:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          isLoading: false,
          isDataLoaded: true,
          isDataLoadError: false,
          userData: action.payload.userDetail
        },
        companyPermissions: {
          isError: false,
          permissions: action.payload.permissions
        }
      };

    case CompanyMembersActionTypes.LoadEditMemberFailed:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          isDataLoadError: true,
          isLoading: false,
          isDataLoaded: false
        },
        companyPermissions: {
          isError: false,
          permissions: null
        }
      };

    case CompanyMembersActionTypes.SaveEditMember:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          isSaving: true,
          isSaveSuccess: false,
          isSavingError: false
        }
      };

    case CompanyMembersActionTypes.SaveEditMemberSuccess:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          userData: {
            ...state.editMember.userData,
            featurePermissions: action.payload.MemberPermissions
          },
          isSaving: false,
          isSaveSuccess: true,
          isSavingError: false
        }
      };

    case CompanyMembersActionTypes.SaveEditMemberFailed:
      return {
        ...state,
        editMember: {
          ...state.editMember,
          isSaving: false,
          isSaveSuccess: false,
          isSavingError: true
        }
      };

    case CompanyMembersActionTypes.RemoveMember:
      return {
        ...state,
        removeMember: {
          ...state.removeMember,
          isRemoveMode: true
        }
      };

    case CompanyMembersActionTypes.SaveRemoveMember:
      return {
        ...state,
        removeMember: {
          ...state.removeMember,
          isRemoving: true
        }
      };

    case CompanyMembersActionTypes.SaveRemoveMemberSuccess:
      return {
        ...state,
        removeMember: {
          ...state.removeMember,
          isRemoveMode: false,
          isRemoving: false
        },
        addMember: initAddMember,
        editMember: initEditMember,
        companyMemberModalType: null
      };

    case CompanyMembersActionTypes.SaveRemoveMemberFailed:
      return {
        ...state,
        removeMember: {
          ...state.removeMember,
          isRemoveMode: true,
          isRemoving: false
        }
      };

    case CompanyMembersActionTypes.AddMember:
      return {
        ...state,
        addMember: {
          ...state.addMember
        }
      };

    case CompanyMembersActionTypes.SaveAddMember:
      return {
        ...state,
        addMember: {
          ...state.addMember,
          isSaving: true,
          isSaveSuccess: false,
          error: null
        }
      };

    case CompanyMembersActionTypes.SaveAddMemberSuccess:
      return {
        ...state,
        addMember: {
          ...state.addMember,
          isSaving: false,
          isSaveSuccess: true,
          error: null
        },
        companyMemberModalType: null
      };

    case CompanyMembersActionTypes.SaveAddMemberFailed:
      return {
        ...state,
        addMember: {
          ...state.addMember,
          isSaving: false,
          isSaveSuccess: false,
          error: state.addMember.error
        }
      };

    case CompanyMembersActionTypes.CloseModals:
      return {
        ...state,
        addMember: initAddMember,
        editMember: initEditMember,
        companyMemberModalType: null
      };
    case CompanyMembersActionTypes.CloseRemoveMemberModals:
      return {
        ...state,
        editMember: {
          ...state.editMember
        },
        removeMember: {
          ...state.removeMember,
          isRemoveMode: false
        }
      };

    case CompanyMembersActionTypes.LoadPossibleNewMembersFailed: {
      return {
        ...state,
        addMember: {
          ...state.addMember,
          data: {
            ...state.addMember.data,
            dataLoadError: 'Error'
          }
        }
      };
    }

    case CompanyMembersActionTypes.LoadAddCompanyMembersData: {
      return {
        ...state,
        addMember: {
          data: {
            possibleNewMembers: null,
            isDataLoaded: null,
            isDataLoading: true,
            dataLoadError: null
          },
          isSaving: null,
          isSaveSuccess: null,
          error: null
        },
        editMember: {
          ...state.editMember
        },
        companyMemberModalType: CompanyMembersModalTypes.ADD
      };
    }

    case CompanyMembersActionTypes.LoadAddCompanyMembersDataSuccess: {
      return {
        ...state,
        addMember: {
          data: {
            possibleNewMembers: action.payload.possibleNewMembers,
            isDataLoaded: true,
            isDataLoading: false,
            dataLoadError: null
          },
          isSaving: null,
          isSaveSuccess: null,
          error: null
        },
        companyPermissions: {
          isError: false,
          permissions: action.payload.permissions
        }
      };
    }
    case CompanyMembersActionTypes.LoadAddCompanyMembersDataFailure: {
      return {
        ...state,
        addMember: {
          data: {
            possibleNewMembers: null,
            isDataLoaded: false,
            isDataLoading: false,
            dataLoadError: 'Error'
          },
          isSaving: null,
          isSaveSuccess: null,
          error: null
        },
        companyPermissions: {
          isError: true,
          permissions: null
        }
      };
    }

    default:
      return state;
  }
}

export const getCompanyMembersState = createFeatureSelector<CompanyMembersState>('companyMembers');
export const getCompanyPermissionsFormMembersState = createSelector(
  getCompanyMembersState,
  state => state.companyPermissions
);
export const editMemberState = createSelector(getCompanyMembersState, state => state.editMember.userData);
export const addMemberState = createSelector(getCompanyMembersState, state => state.addMember.data);
export const companyMemberModalTypeState = createSelector(
  getCompanyMembersState,
  state => state.companyMemberModalType
);
