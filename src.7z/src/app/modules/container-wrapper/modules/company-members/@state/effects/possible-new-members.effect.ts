import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  LoadPossibleNewMembersAction,
  LoadPossibleNewMembersFailedAction,
  LoadPossibleNewMembersSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class PossibleNewMembersCompanyMembersEffect {
  public constructor(
    private actions$: Actions,
    private http: CompanyMembersHttpService
  ) {}

  public possibleNewMembersCompanyMembersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.LoadPossibleNewMembers),
      switchMap((action: LoadPossibleNewMembersAction) => {
        return this.http.getListOfPossibleNewMemberships(action.companyId).pipe(
          map(data => new LoadPossibleNewMembersSuccessAction(data)),
          catchError(err => of(new LoadPossibleNewMembersFailedAction(err)))
        );
      })
    )
  );
}
