import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { MembershipsResponseModel } from '../../models/company-members.model';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  SaveRemoveMemberAction,
  SaveRemoveMemberFailedAction,
  SaveRemoveMemberSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class SaveRemoveMemberEffect {
  public constructor(
    private actions$: Actions,
    private PermissonsHttpService: CompanyMembersHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveRemoveMemberEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.SaveRemoveMember),
      switchMap((action: SaveRemoveMemberAction) => {
        return this.PermissonsHttpService.deleteMembership(action.companyId, action.userId).pipe(
          map(data => this.handleSuccess(data)),
          catchError(err => this.handleError(err))
        );
      })
    )
  );

  private handleSuccess(createAddMemberResponse: MembershipsResponseModel) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'User removed successfully');
    return new SaveRemoveMemberSuccessAction(createAddMemberResponse);
  }

  private handleError(_err: HttpErrorResponse) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while removing user');
    return of(new SaveRemoveMemberFailedAction('Error while adding user'));
  }
}
