import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  SaveEditMemberAction,
  SaveEditMemberFailedAction,
  SaveEditMemberSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class SaveEditMemberEffect {
  public constructor(
    private actions$: Actions,
    private PermissonsHttpService: CompanyMembersHttpService
  ) {}

  public saveEditMemberEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.SaveEditMember),
      switchMap((action: SaveEditMemberAction) => {
        return this.PermissonsHttpService.updateMemberFeaturePermissions(action.payload).pipe(
          map(data => new SaveEditMemberSuccessAction(data)),
          catchError(err => of(new SaveEditMemberFailedAction(err)))
        );
      })
    )
  );
}
