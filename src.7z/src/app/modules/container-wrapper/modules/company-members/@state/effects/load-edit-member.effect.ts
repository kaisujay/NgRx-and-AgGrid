import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  LoadEditMemberAction,
  LoadEditMemberFailedAction,
  LoadEditMemberSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class LoadEditMemberEffect {
  public constructor(
    private actions$: Actions,
    private membersSvc: CompanyMembersHttpService
  ) {}

  public loadEditMemberEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.LoadEditMember),
      switchMap((action: LoadEditMemberAction) => {
        const userDetails = this.membersSvc.getUserDetails(action.userId);
        const userPermissions = this.membersSvc.getUserFeaturePermissions(action.companyId, action.userId);
        const companyPermissions = this.membersSvc.getCompanyPermissions(action.companyId);
        return forkJoin([userDetails, userPermissions, companyPermissions]).pipe(
          map(data => {
            data[0].featurePermissions = data[1].MemberPermissions;
            return new LoadEditMemberSuccessAction({
              userDetail: data[0],
              permissions: data[2].CompanyFeaturePermissions
            });
          }),
          catchError(err => of(new LoadEditMemberFailedAction(err)))
        );
      })
    )
  );
}
