import { Action } from '@ngrx/store';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { CompanyDetailsModel } from '../../../company-details/models/company-details.model';
import { CompanyPermissionsModel } from '../../../company-permissions/models/permission-state.model';
import { IndivisualUserModel } from '../../../user-pool/models/create-new-user.model';
import {
  AddEditMembershipPayloadModel,
  ItemModel,
  MembershipPermissionsModel,
  MembershipsResponseModel
} from '../../models/company-members.model';

export enum CompanyMembersActionTypes {
  LoadCompanyDetails = '[Company Memebrs] Load Company Details',
  LoadCompanyDetailsSuccess = '[Company Memebrs] Load Company Details Success',
  LoadCompanyDetailsFailed = '[Company Memebrs] Load Company Details Failed',

  LoadCompanyMembers = '[Company Memebrs] Load Company Members',
  LoadCompanyMembersSuccess = '[Company Memebrs] Load Company Members Success',
  LoadCompanyMembersFailed = '[Company Memebrs] Load Company Members Failed',

  ExportToXLSX = '[Company Memebrs] Export to XLSX',
  ExportToXLSXSuccess = '[Company Memebrs] Export to XLSX Success',
  ExportToXLSXFailed = '[Company Memebrs] Export to XLSX Failed',

  LoadEditMember = '[Company Memebrs] Load Edit Member',
  LoadEditMemberSuccess = '[Company Memebrs] Load Edit Member Success',
  LoadEditMemberFailed = '[Company Memebrs] Load Edit Member Failed',

  SaveEditMember = '[Company Memebrs] Save Edit Member',
  SaveEditMemberSuccess = '[Company Memebrs] Save Edit Member Success',
  SaveEditMemberFailed = '[Company Memebrs] Save Edit Member Failed',

  RemoveMember = '[Company Memebrs] Load Remove Member',

  SaveRemoveMember = '[Company Memebrs] Save Remove Member',
  SaveRemoveMemberSuccess = '[Company Memebrs] Save Remove Member Success',
  SaveRemoveMemberFailed = '[Company Memebrs] Save Remove Member Failed',

  LoadPossibleNewMembers = '[Company Memebrs] Load Possible New Members',
  LoadPossibleNewMembersSuccess = '[Company Memebrs] Load Possible New Members Success',
  LoadPossibleNewMembersFailed = '[Company Memebrs] Load Possible New Members Failed',

  AddMember = '[Company Memebrs] Add Member',

  SaveAddMember = '[Company Memebrs] Save Add Member',
  SaveAddMemberSuccess = '[Company Memebrs] Save Add Member Success',
  SaveAddMemberFailed = '[Company Memebrs] Save Add Member Failed',
  LoadAddCompanyMembersData = '[Company Memebrs] Load Add Company Member Data',
  LoadAddCompanyMembersDataSuccess = '[Company Memebrs] Load Add Company Member Data Success',
  LoadAddCompanyMembersDataFailure = '[Company Memebrs] Load Add Company Member Data Failure',

  CloseModals = '[Company Memebrs] Close Modals',
  CloseRemoveMemberModals = '[Company Memebrs] Close Remove Member Modals'
}

export class LoadCompanyDetailsAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyDetails;
  public constructor(public companyId: string) {}
}

export class LoadCompanyDetailsSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyDetailsSuccess;
  public constructor(public payload: CompanyDetailsModel) {}
}

export class LoadCompanyDetailsFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyDetailsFailed;
  public constructor() {}
}

export class LoadCompanyMembersAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyMembers;
  public constructor(
    public companyId: string,
    public payload: {
      params: IServerSideGetRowsRequest;
      filter: string;
    }
  ) {}
}

export class LoadCompanyMembersSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyMembersSuccess;
  public constructor(
    public payload: {
      rowData: ItemModel[];
      rowCount: number;
    }
  ) {}
}

export class LoadCompanyMembersFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadCompanyMembersFailed;
  public constructor() {}
}

export class ExportToXLSXAction implements Action {
  public readonly type = CompanyMembersActionTypes.ExportToXLSX;
  public constructor(
    public companyId: string,
    public filter: string
  ) {}
}

export class ExportToXLSXSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.ExportToXLSXSuccess;
  public constructor() {}
}

export class ExportToXLSXFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.ExportToXLSXFailed;
  public constructor() {}
}

export class LoadEditMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadEditMember;
  public constructor(
    public companyId: string,
    public userId: string
  ) {}
}

export class LoadEditMemberSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadEditMemberSuccess;
  public constructor(public payload: { userDetail: IndivisualUserModel; permissions: CompanyPermissionsModel }) {}
}

export class LoadEditMemberFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadEditMemberFailed;
  public constructor(public error: string) {}
}

export class SaveEditMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveEditMember;
  public constructor(public payload: AddEditMembershipPayloadModel) {}
}

export class SaveEditMemberSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveEditMemberSuccess;
  public constructor(public payload: MembershipPermissionsModel) {}
}

export class SaveEditMemberFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveEditMemberFailed;
  public constructor(public error: string) {}
}

export class RemoveMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.RemoveMember;
  public constructor() {}
}

export class SaveRemoveMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveRemoveMember;
  public constructor(
    public companyId: string,
    public userId: string
  ) {}
}

export class SaveRemoveMemberSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveRemoveMemberSuccess;
  public constructor(public payload: MembershipsResponseModel) {}
}

export class SaveRemoveMemberFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveRemoveMemberFailed;
  public constructor(public error: string) {}
}

export class LoadPossibleNewMembersAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadPossibleNewMembers;
  public constructor(public companyId: string) {}
}

export class LoadPossibleNewMembersSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadPossibleNewMembersSuccess;
  public constructor(public payload: MembershipsResponseModel[]) {}
}

export class LoadPossibleNewMembersFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadPossibleNewMembersFailed;
  public constructor(public error: string) {}
}

export class LoadAddMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.AddMember;
  public constructor() {}
}

export class SaveAddMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveAddMember;
  public constructor(
    public companyId: string,
    public payload: AddEditMembershipPayloadModel
  ) {}
}

export class SaveAddMemberSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveAddMemberSuccess;
  public constructor(public payload: MembershipsResponseModel) {}
}

export class SaveAddMemberFailedAction implements Action {
  public readonly type = CompanyMembersActionTypes.SaveAddMemberFailed;
  public constructor(public errorMessage: string) {}
}

export class CloseModalsAction implements Action {
  public readonly type = CompanyMembersActionTypes.CloseModals;
  public constructor() {}
}

export class CloseRemoveMemberAction implements Action {
  public readonly type = CompanyMembersActionTypes.CloseRemoveMemberModals;
  public constructor() {}
}

export class LoadAddCompanyMembersDataAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadAddCompanyMembersData;
  public constructor(public companyId: string) {}
}

export class LoadAddCompanyMembersDataSuccessAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadAddCompanyMembersDataSuccess;
  public constructor(
    public payload: { possibleNewMembers: MembershipsResponseModel[]; permissions: CompanyPermissionsModel }
  ) {}
}

export class LoadAddCompanyMembersDataFailureAction implements Action {
  public readonly type = CompanyMembersActionTypes.LoadAddCompanyMembersDataFailure;
  public constructor(public payload: any) {}
}

export type CompanyMembersActionsUnion =
  | LoadCompanyDetailsAction
  | LoadCompanyDetailsSuccessAction
  | LoadCompanyDetailsFailedAction
  | LoadCompanyMembersAction
  | LoadCompanyMembersSuccessAction
  | LoadCompanyMembersFailedAction
  | ExportToXLSXAction
  | ExportToXLSXSuccessAction
  | ExportToXLSXFailedAction
  | LoadEditMemberAction
  | LoadEditMemberSuccessAction
  | LoadEditMemberFailedAction
  | RemoveMemberAction
  | SaveRemoveMemberAction
  | SaveRemoveMemberSuccessAction
  | SaveRemoveMemberFailedAction
  | LoadPossibleNewMembersAction
  | LoadPossibleNewMembersSuccessAction
  | LoadPossibleNewMembersFailedAction
  | LoadAddMemberAction
  | SaveAddMemberAction
  | SaveAddMemberSuccessAction
  | SaveAddMemberFailedAction
  | CloseModalsAction
  | CloseRemoveMemberAction
  | LoadAddCompanyMembersDataAction
  | LoadAddCompanyMembersDataSuccessAction
  | LoadAddCompanyMembersDataFailureAction
  | SaveEditMemberAction
  | SaveEditMemberSuccessAction
  | SaveEditMemberFailedAction;
