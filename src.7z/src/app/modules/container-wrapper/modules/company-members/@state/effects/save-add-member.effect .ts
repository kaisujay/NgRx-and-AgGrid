import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { AddEditMembershipPayloadModel, MembershipsResponseModel } from '../../models/company-members.model';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  SaveAddMemberAction,
  SaveAddMemberFailedAction,
  SaveAddMemberSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class SaveAddMemberEffect {
  public constructor(
    private actions$: Actions,
    private PermissonsHttpService: CompanyMembersHttpService,
    private messageAlertSvc: MessageAlertService
  ) {}

  public saveAddMemberEffect1$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.SaveAddMember),
      switchMap((action: SaveAddMemberAction) => this.handleSaveAddMember(action))
    )
  );

  private handleSaveAddMember(action: SaveAddMemberAction) {
    let createAddMemberResponse = null;
    const createAddMember$ = this.PermissonsHttpService.postAddMembership(action.companyId, {
      CompanyId: action.payload.CompanyId,
      UserId: action.payload.UserId
    });

    return createAddMember$.pipe(
      tap(res => {
        createAddMemberResponse = res;
      }),
      switchMap(() => this.handleCreatePermission(action.payload)),
      map(_permRes => this.handleSuccess(createAddMemberResponse)),
      catchError(err => this.handleError(err))
    );
  }

  private handleCreatePermission(payload: AddEditMembershipPayloadModel) {
    const createPermission$ = this.PermissonsHttpService.createNewMemberPermission(payload);
    return createPermission$.pipe(
      tap(() => this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Member added successfully'))
    );
  }

  private handleSuccess(createAddMemberResponse: MembershipsResponseModel) {
    return new SaveAddMemberSuccessAction(createAddMemberResponse);
  }

  private handleError(_err: HttpErrorResponse) {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while adding user');
    return of(new SaveAddMemberFailedAction('Error while adding user'));
  }
}
