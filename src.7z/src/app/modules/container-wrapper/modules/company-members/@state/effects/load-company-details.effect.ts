import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  LoadCompanyDetailsAction,
  LoadCompanyDetailsFailedAction,
  LoadCompanyDetailsSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class LoadCompanyDetailsEffect {
  public constructor(
    private actions$: Actions,
    private companyDetailsHttpService: CompanyMembersHttpService
  ) {}

  public loadCompanyDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.LoadCompanyDetails),
      switchMap((action: LoadCompanyDetailsAction) => {
        return this.companyDetailsHttpService.getCompanies(action.companyId).pipe(
          map(data => new LoadCompanyDetailsSuccessAction(data)),
          catchError(_err => of(new LoadCompanyDetailsFailedAction()))
        );
      })
    )
  );
}
