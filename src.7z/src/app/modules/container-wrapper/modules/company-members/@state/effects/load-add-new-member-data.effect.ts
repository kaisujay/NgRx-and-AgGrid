import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { CompanyMembersHttpService } from '../../services/company-members.http.service';
import {
  CompanyMembersActionTypes,
  LoadAddCompanyMembersDataAction,
  LoadAddCompanyMembersDataSuccessAction,
  LoadPossibleNewMembersFailedAction
} from '../actions/company-members.action';

@Injectable()
export class LoadAddNewMemberDataEffect {
  public constructor(
    private actions$: Actions,
    private http: CompanyMembersHttpService
  ) {}

  public possibleNewMembersCompanyMembersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.LoadAddCompanyMembersData),
      switchMap((action: LoadAddCompanyMembersDataAction) => {
        const getAddMemberPermissions = this.http.getCompanyPermissions(action.companyId);
        const getPossibleNewMembers = this.http.getListOfPossibleNewMemberships(action.companyId);
        return forkJoin([getAddMemberPermissions, getPossibleNewMembers]).pipe(
          map(
            data =>
              new LoadAddCompanyMembersDataSuccessAction({
                possibleNewMembers: data[1],
                permissions: data[0].CompanyFeaturePermissions
              })
          ),
          catchError(err => of(new LoadPossibleNewMembersFailedAction(err)))
        );
      })
    )
  );
}
