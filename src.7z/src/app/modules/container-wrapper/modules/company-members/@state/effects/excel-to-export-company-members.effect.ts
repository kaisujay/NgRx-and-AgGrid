import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';

import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { CompanyMembersExportToExcelService } from '../../services/company-members.export-to-excel.service';
import {
  CompanyMembersActionTypes,
  ExportToXLSXAction,
  ExportToXLSXFailedAction,
  ExportToXLSXSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class ExportToXlsxCompanyMembersEffect {
  public constructor(
    private actions$: Actions,
    private exportToExcelService: CompanyMembersExportToExcelService,
    private messageAlertSvc: MessageAlertService
  ) {}
  public exportToXlsxEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.ExportToXLSX),
      switchMap((action: ExportToXLSXAction) =>
        this.exportToExcelService
          .export(buildApiString(API.companyMembership.get, { id: action.companyId }), action.filter)
          .pipe(
            map(_response => this.handleSuccess()),
            catchError(_err => this.handleError())
          )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Exported successfully');
    return new ExportToXLSXSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while Exporting');
    return of(new ExportToXLSXFailedAction());
  }
}
