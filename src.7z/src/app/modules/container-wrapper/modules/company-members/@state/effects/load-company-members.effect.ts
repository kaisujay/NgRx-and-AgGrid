import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { ItemModel } from '../../models/company-members.model';
import {
  CompanyMembersActionTypes,
  LoadCompanyMembersAction,
  LoadCompanyMembersFailedAction,
  LoadCompanyMembersSuccessAction
} from '../actions/company-members.action';

@Injectable()
export class LoadCompanyMembersEffect {
  public constructor(
    private actions$: Actions,
    private kendoAdapterService: KendoAdapterService
  ) {}
  public loadCompanyMembersEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CompanyMembersActionTypes.LoadCompanyMembers),
      switchMap((action: LoadCompanyMembersAction) => {
        return this.kendoAdapterService
          .get<ItemModel>(
            buildApiString(API.companyMembership.get, { id: action.companyId }),
            action.payload.params,
            action.payload.filter
          )
          .pipe(
            map(response => {
              return new LoadCompanyMembersSuccessAction(response);
            }),
            catchError(_ => of(new LoadCompanyMembersFailedAction()))
          );
      })
    )
  );
}
