import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyMembersComponent } from './components/company-members.component';

const routes: Routes = [
  {
    path: '',
    component: CompanyMembersComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyMembersRoutingModule {}
