import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { CupcakeFlavors, SelectOptions } from '@ipreo/ngx-sprinkles';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { Observable, filter, first, switchMap, tap } from 'rxjs';
import { deepClone } from '../../../../../../@core/constants/constants';
import { CompanyPermissionsModel } from '../../../company-permissions/models/permission-state.model';
import { IndivisualUserModel } from '../../../user-pool/models/create-new-user.model';
import {
  CloseModalsAction,
  CompanyMembersActionTypes,
  RemoveMemberAction,
  SaveAddMemberAction,
  SaveEditMemberAction
} from '../../@state/actions/company-members.action';
import {
  CompanyMembersState,
  companyMemberModalTypeState,
  getCompanyMembersState
} from '../../@state/reducers/company-members.reducer';
import {
  AddEditMembershipPayloadModel,
  CompanyMembersModalTypes,
  CreateMemberPermissionModel,
  MembershipsResponseModel,
  NewMemberPermissionModel,
  RemoveMemberPassValue
} from '../../models/company-members.model';
import { CompanyMembersService } from '../../services/company-members.service';

@Component({
  selector: 'app-add-edit-member',
  templateUrl: './add-edit-member.component.html',
  styleUrls: ['./add-edit-member.component.scss']
})
export class AddEditMemberComponent implements OnInit {
  @Input() public CompanyName: string;
  @Input() public mode: string;

  public companyMembersState$: Observable<CompanyMembersState>;
  public addMemberFormGroup: FormGroup;
  public showPermissionTab = false;
  public emailSelected = false;
  public possibleNewMemberships: MembershipsResponseModel[];
  public AddEditMembershipPayloadModel: AddEditMembershipPayloadModel;
  public companyId: string;
  public userId: string;
  public companyPermissions: CompanyPermissionsModel;
  public memberFeaturePermission = {} as CreateMemberPermissionModel;
  public initalMemberFeaturePermissions = {} as CreateMemberPermissionModel;

  public memberEmailOptions: SelectOptions[];

  public removeMemberPassValue: RemoveMemberPassValue;
  public userData: IndivisualUserModel;
  public CompanyMembersModalType = CompanyMembersModalTypes;
  @Output() public sendRemoveData: EventEmitter<RemoveMemberPassValue> = new EventEmitter();

  public constructor(
    private formBuilder: FormBuilder,
    private messageAlertSvc: MessageAlertService,
    private store$: Store,
    private actions$: Actions
  ) {}

  public ngOnInit(): void {
    this.companyMembersState$ = this.store$.pipe(select(getCompanyMembersState)).pipe(
      tap(companyMembersState => {
        if (companyMembersState.editMember.isSavingError || companyMembersState.editMember.isSaveSuccess) {
          this.messageAlertSvc.showMessageAlert(
            companyMembersState.editMember.isSaveSuccess ? CupcakeFlavors.Success : CupcakeFlavors.Danger,
            companyMembersState.editMember.isSaveSuccess
              ? 'Feature Permissions updated succesfully'
              : 'Error while updating permissions'
          );
        }
      })
    );
    this.store$.pipe(select(companyMemberModalTypeState)).subscribe(modalType => {
      if (modalType && modalType === CompanyMembersModalTypes.ADD) {
        this.initiateAddMemberFlow();
      }
      if (modalType && modalType === CompanyMembersModalTypes.EDIT) {
        this.initiateEditMemberFlow();
      }
    });
    this.initForm();
  }

  // Common Methods
  public initForm(): void {
    this.addMemberFormGroup = this.formBuilder.group({
      Email: new FormControl({ value: '', disabled: this.mode === CompanyMembersModalTypes.EDIT }),
      IpreoAccountId: new FormControl({ value: '', disabled: true }, []),
      FirstName: new FormControl({ value: '', disabled: true }, []),
      LastName: new FormControl({ value: '', disabled: true }, []),
      Title: new FormControl({ value: '', disabled: true }, []),
      PhoneNumber: new FormControl({ value: '', disabled: true }, []),
      City: new FormControl({ value: '', disabled: true }, []),
      Country: new FormControl({ value: '', disabled: true }, [])
    });
  }

  public onPermissionTabClick(): void {
    this.showPermissionTab = true;
  }

  public parseMemberFeaturePermission(
    mode: string,
    companyPermissions: CompanyPermissionsModel
  ): CompanyPermissionsModel | CreateMemberPermissionModel {
    if (mode === CompanyMembersModalTypes.ADD) {
      return companyPermissions.DealMonitorEnterprise.Enabled
        ? {
            ...NewMemberPermissionModel,
            InternalCommentsAndAlerting: {
              Enabled: true
            }
          }
        : { ...NewMemberPermissionModel };
    }
    return <CompanyPermissionsModel>this.userData.featurePermissions;
  }

  // Add members flow
  public initiateAddMemberFlow(): void {
    this.actions$
      .pipe(
        filter(action => action.type === CompanyMembersActionTypes.LoadAddCompanyMembersDataSuccess),
        switchMap(() => this.store$.select(getCompanyMembersState)),
        first()
      )
      .subscribe(state => {
        if (state.addMember.data.isDataLoaded && state.addMember.data.possibleNewMembers) {
          this.possibleNewMemberships = state.addMember.data.possibleNewMembers;
          this.companyPermissions = state.companyPermissions.permissions;
          this.companyId = state.companyDetailsModel.data.Id;
          if (this.possibleNewMemberships.length > 0) {
            this.memberEmailOptions = CompanyMembersService.getMemberEmailOptions(this.possibleNewMemberships);
          }
          this.memberFeaturePermission = this.parseMemberFeaturePermission(this.mode, this.companyPermissions);
          this.initalMemberFeaturePermissions = deepClone(this.memberFeaturePermission);
        }
      });
  }

  public updateForm(): void {
    if (this.addMemberFormGroup.get('Email').value !== null && this.addMemberFormGroup.get('Email').value !== '') {
      this.emailSelected = true;

      const selectedMember = this.possibleNewMemberships.filter(
        email => email.Email == this.addMemberFormGroup.get('Email').value
      )[0];

      if (selectedMember !== undefined) {
        this.userId = selectedMember.Id;
        this.addMemberFormGroup.controls['IpreoAccountId'].setValue(selectedMember.IpreoAccountId);
        this.addMemberFormGroup.controls['FirstName'].setValue(selectedMember.FirstName);
        this.addMemberFormGroup.controls['LastName'].setValue(selectedMember.LastName);
        this.addMemberFormGroup.controls['Title'].setValue(selectedMember.Title);
        this.addMemberFormGroup.controls['PhoneNumber'].setValue(selectedMember.PhoneNumber);
        this.addMemberFormGroup.controls['City'].setValue(selectedMember.City);
        this.addMemberFormGroup.controls['Country'].setValue(selectedMember.Country);
      }
    }
  }

  public saveUser(): void {
    if (this.mode === CompanyMembersModalTypes.ADD) {
      this.createUser();
    }
    if (this.mode === CompanyMembersModalTypes.EDIT) {
      this.saveEditedUser();
    }
  }

  public createUser(): void {
    const AddEditMembershipPayloadModel: AddEditMembershipPayloadModel = {
      CompanyId: this.companyId,
      UserId: this.userId,
      MemberPermissions: this.getMemberPermissionsForSave(deepClone(this.memberFeaturePermission))
    };
    this.store$.dispatch(new SaveAddMemberAction(this.companyId, AddEditMembershipPayloadModel));
  }

  public getMemberPermissionsForSave(
    memberFeaturePermission: CreateMemberPermissionModel
  ): Partial<CreateMemberPermissionModel> {
    Object.keys(memberFeaturePermission).forEach(key => {
      if (!memberFeaturePermission[key].Enabled) {
        delete memberFeaturePermission[key];
      }
    });
    return memberFeaturePermission;
  }

  // Edit members flow
  public initiateEditMemberFlow(): void {
    this.actions$
      .pipe(
        filter(
          action =>
            action.type === CompanyMembersActionTypes.LoadEditMemberSuccess ||
            action.type === CompanyMembersActionTypes.SaveEditMemberSuccess
        ),
        switchMap(() => this.store$.select(getCompanyMembersState).pipe(first()))
      )
      .subscribe(companyMembersState => {
        if (companyMembersState.editMember.userData !== null) {
          this.removeMemberPassValue = {
            CompanyId: companyMembersState.companyDetailsModel.data.Id,
            UserId: companyMembersState.editMember.userData.Id,
            FirstName: companyMembersState.editMember.userData.FirstName,
            LastName: companyMembersState.editMember.userData.LastName
          };
          this.userId = companyMembersState.editMember.userData.Id;
          this.companyId = companyMembersState.companyDetailsModel.data.Id;
          this.userData = deepClone(companyMembersState.editMember.userData);
          this.companyPermissions = companyMembersState.companyPermissions.permissions;
          this.updateDetailsFormValue();
          this.memberFeaturePermission = this.parseMemberFeaturePermission(this.mode, this.companyPermissions);
          this.initalMemberFeaturePermissions = deepClone(this.memberFeaturePermission);
        }
      });
  }

  public saveEditedUser(): void {
    const isPomValid = this.validatePomPermission(this.memberFeaturePermission);
    if (isPomValid) {
      const editMemberFeaturePermissions = {
        UserId: this.userId,
        CompanyId: this.companyId,
        MemberPermissions: this.memberFeaturePermission
      };
      this.store$.dispatch(new SaveEditMemberAction(editMemberFeaturePermissions));
    } else {
      this.messageAlertSvc.showMessageAlert(
        CupcakeFlavors.Danger,
        'The Internal Order Entry and/or Aggregate Order Management options are required'
      );
    }
  }
  public updateDetailsFormValue(): void {
    this.addMemberFormGroup.controls['Email'].setValue(this.userData.Email);
    this.addMemberFormGroup.controls['IpreoAccountId'].setValue(this.userData.IpreoAccountId);
    this.addMemberFormGroup.controls['FirstName'].setValue(this.userData.FirstName);
    this.addMemberFormGroup.controls['LastName'].setValue(this.userData.LastName);
    this.addMemberFormGroup.controls['Title'].setValue(this.userData.Title);
    this.addMemberFormGroup.controls['PhoneNumber'].setValue(this.userData.PhoneNumber);
    this.addMemberFormGroup.controls['City'].setValue(this.userData.City);
    this.addMemberFormGroup.controls['Country'].setValue(this.userData.Country);
  }

  public onRemoveUser() {
    this.sendRemoveData.emit(this.removeMemberPassValue);
    this.store$.dispatch(new RemoveMemberAction());
  }

  // Feature permission Methods
  public hasEditPermission(permissionType: string): boolean {
    if (!this.companyPermissions[permissionType]) return false;
    return this.companyPermissions[permissionType].Enabled;
  }

  public onFixedIncomeAllowDealMonitorChange(): void {
    if (this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled === false) {
      if (this.memberFeaturePermission['Orders']) {
        this.memberFeaturePermission['Orders'].Enabled = false;
        this.changeOrdersPermission();
      }
      if (this.memberFeaturePermission['PrimaryOrderManagement']) {
        this.memberFeaturePermission['PrimaryOrderManagement'].Enabled = false;
        this.changePrimaryOrderManagementPermission();
      }
      if (this.memberFeaturePermission['FixedIncomeAnalytics']) {
        this.memberFeaturePermission['FixedIncomeAnalytics'].Enabled = false;
      }
    }
  }

  public changeOrdersPermission(): void {
    if (this.memberFeaturePermission['Orders'].Enabled === false) {
      if (this.memberFeaturePermission['OrdersReadOnly']) {
        this.memberFeaturePermission['OrdersReadOnly'].Enabled = false;
      }

      if (this.memberFeaturePermission['OrdersMultiple']) {
        this.memberFeaturePermission['OrdersMultiple'].Enabled = false;
      }

      if (this.memberFeaturePermission['AggregatedOrderManagement']) {
        this.memberFeaturePermission['AggregatedOrderManagement'].Enabled = false;
      }

      if (this.memberFeaturePermission['ReleaseFixAllocations']) {
        this.memberFeaturePermission['ReleaseFixAllocations'].Enabled = false;
      }
    }
  }

  public changePrimaryOrderManagementPermission(): void {
    if (this.memberFeaturePermission['PrimaryOrderManagement'].Enabled === false) {
      if (this.memberFeaturePermission['InternalOrderEntry']) {
        this.memberFeaturePermission['InternalOrderEntry'].Enabled = false;
      }
      if (this.memberFeaturePermission['AggregatedOrderManagement']) {
        this.memberFeaturePermission['AggregatedOrderManagement'].Enabled = false;
      }
      if (this.memberFeaturePermission['ReleaseFixAllocations']) {
        this.memberFeaturePermission['ReleaseFixAllocations'].Enabled = false;
      }
    }
  }

  public onPrimaryOrderManagementPermissionChange(): void {
    if (this.memberFeaturePermission['PrimaryOrderManagement'].Enabled === false) {
      if (this.memberFeaturePermission['InternalOrderEntry']) {
        this.memberFeaturePermission['InternalOrderEntry'].Enabled = false;
      }
      if (this.memberFeaturePermission['AggregatedOrderManagement']) {
        this.memberFeaturePermission['AggregatedOrderManagement'].Enabled = false;
      }
      if (this.memberFeaturePermission['ReleaseFixAllocations']) {
        this.memberFeaturePermission['ReleaseFixAllocations'].Enabled = false;
      }
    }
  }

  public onAggregationOrderManagementPermissionChange(): void {
    if (this.memberFeaturePermission['AggregatedOrderManagement'].Enabled === false) {
      if (this.memberFeaturePermission['ReleaseFixAllocations']) {
        this.memberFeaturePermission['ReleaseFixAllocations'].Enabled = false;
      }
    }
  }

  public onEquityAllowDealMonitorChange(): void {
    if (this.memberFeaturePermission['EquityDealMonitorV2'].Enabled === false) {
      if (this.memberFeaturePermission['Orders']) {
        this.memberFeaturePermission['EquityOrders'].Enabled = false;
        this.changeOrdersPermission();
      }

      if (this.memberFeaturePermission['EquityOrdersReadOnly']) {
        this.memberFeaturePermission['EquityOrdersReadOnly'].Enabled = false;
        this.changeOrdersPermission();
      }

      if (this.memberFeaturePermission['EquityAnalytics']) {
        this.memberFeaturePermission['EquityAnalytics'].Enabled = false;
      }
    }
  }

  public onEquityOrdersPermissionChange(): void {
    if (this.memberFeaturePermission['EquityOrders'].Enabled === false) {
      if (this.memberFeaturePermission['EquityOrdersReadOnly']) {
        this.memberFeaturePermission['EquityOrdersReadOnly'].Enabled = false;
      }
    }
  }

  public onMuniStreetCalendarPermissionChange(): void {
    if (this.memberFeaturePermission['MunicipalStreetCalendar'].Enabled === false) {
      if (this.memberFeaturePermission['MunicipalDealMonitor']) {
        this.memberFeaturePermission['MunicipalDealMonitor'].Enabled = false;
      }
    }

    if (this.memberFeaturePermission['MunicipalInternalStatusInterested']) {
      this.memberFeaturePermission['MunicipalInternalStatusInterested'].Enabled =
        this.memberFeaturePermission['MunicipalStreetCalendar'].Enabled;
    }

    if (this.memberFeaturePermission['MunicipalInternalStatusInProgress']) {
      this.memberFeaturePermission['MunicipalInternalStatusInProgress'].Enabled =
        this.memberFeaturePermission['MunicipalStreetCalendar'].Enabled;
    }

    if (this.memberFeaturePermission['MunicipalInternalStatusApproved']) {
      this.memberFeaturePermission['MunicipalInternalStatusApproved'].Enabled =
        this.memberFeaturePermission['MunicipalStreetCalendar'].Enabled;
    }

    if (this.memberFeaturePermission['MunicipalInternalStatusNotApproved']) {
      this.memberFeaturePermission['MunicipalInternalStatusNotApproved'].Enabled =
        this.memberFeaturePermission['MunicipalStreetCalendar'].Enabled;
    }
  }

  public isFixedIncomeAnalyticsDisabled() {
    const isMembershipPermissionDisabled = !this.hasEditPermission('FixedIncomeAnalytics');
    const isFeaturePermissionsDesabled =
      this.memberFeaturePermission &&
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'] &&
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled === false;

    const isDealMonitorDisabled = !(
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'] &&
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled
    );

    return this.memberFeaturePermission
      ? isMembershipPermissionDisabled || isFeaturePermissionsDesabled
      : isDealMonitorDisabled;
  }

  public isOrderPermissionsDisabled(): boolean {
    const isMembershipPermissionDisabled =
      !this.hasEditPermission('Orders') || !this.hasEditPermission('FixedIncomeAllowDealMonitor');

    const isFeaturePermissionsDesabled =
      this.memberFeaturePermission && this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled === false;

    const isDealMonitorDisabled = !(
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'] &&
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled
    );

    return this.memberFeaturePermission
      ? isMembershipPermissionDisabled || isFeaturePermissionsDesabled
      : isDealMonitorDisabled;
  }

  public isPrimaryOrderManagementPermissionsDisabled(): boolean {
    const isMembershipPermissionDisabled =
      !this.hasEditPermission('PrimaryOrderManagement') || !this.hasEditPermission('FixedIncomeAllowDealMonitor');
    const isFeaturePermissionsDesabled =
      this.memberFeaturePermission && this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled === false;

    const isDealMonitorDisabled = !(
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'] &&
      this.memberFeaturePermission['FixedIncomeAllowDealMonitor'].Enabled
    );

    return this.memberFeaturePermission
      ? isMembershipPermissionDisabled || isFeaturePermissionsDesabled
      : isDealMonitorDisabled;
  }

  public isEquityAnalyticsDisabled(): boolean {
    const isMembershipPermissionDisabled = !this.hasEditPermission('EquityAnalytics');
    const isFeaturePermissionsDisabled =
      this.memberFeaturePermission && this.memberFeaturePermission['EquityDealMonitorV2'].Enabled === false;

    const isDealMonitorDisabled = !(
      this.memberFeaturePermission['EquityDealMonitorV2'] && this.memberFeaturePermission['EquityDealMonitorV2'].Enabled
    );

    return this.memberFeaturePermission
      ? isMembershipPermissionDisabled || isFeaturePermissionsDisabled
      : isMembershipPermissionDisabled || isDealMonitorDisabled;
  }

  public isEquityOrderPermissionsDisabled() {
    const isMembershipPermissionDisabled =
      !this.hasEditPermission('EquityOrders') || !this.hasEditPermission('EquityDealMonitorV2');
    const isFeaturePermissionsDesabled =
      this.memberFeaturePermission && this.memberFeaturePermission['EquityDealMonitorV2'].Enabled === false;

    const isDealMonitorDisabled = !(
      this.memberFeaturePermission['EquityDealMonitorV2'] && this.memberFeaturePermission['EquityDealMonitorV2'].Enabled
    );

    return this.memberFeaturePermission
      ? isMembershipPermissionDisabled || isFeaturePermissionsDesabled
      : isDealMonitorDisabled;
  }

  public validatePomPermission(memberFeaturePermission: CreateMemberPermissionModel): boolean {
    const hasPomSubPermissionEnabled =
      (memberFeaturePermission.InternalOrderEntry && memberFeaturePermission.InternalOrderEntry.Enabled) ||
      (memberFeaturePermission.AggregatedOrderManagement && memberFeaturePermission.AggregatedOrderManagement.Enabled);
    return !(
      memberFeaturePermission.PrimaryOrderManagement &&
      memberFeaturePermission.PrimaryOrderManagement.Enabled &&
      !hasPomSubPermissionEnabled
    );
  }

  public isSaveButtonDisabled(): boolean {
    if (this.mode === CompanyMembersModalTypes.ADD) {
      return !this.emailSelected;
    }
    return JSON.stringify(this.initalMemberFeaturePermissions) === JSON.stringify(this.memberFeaturePermission);
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }
}
