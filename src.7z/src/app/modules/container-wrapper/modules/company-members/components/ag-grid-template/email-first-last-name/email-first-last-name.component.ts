import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { LoadEditMemberAction } from '../../../@state/actions/company-members.action';
import { getCompanyMembersState } from '../../../@state/reducers/company-members.reducer';

@Component({
  template: '<span (click)="onEditUser()" class="c-text-primary c-cursor-pointer">{{params.value}}</span>'
})
export class EmailFirstLastNameComponent implements ICellRendererAngularComp {
  public params: ICellRendererParams;
  public companyId: string;

  public constructor(private store: Store) {}

  public refresh(_params: ICellRendererParams): boolean {
    return false;
  }

  public agInit(params: ICellRendererParams): void {
    this.params = params;
  }

  public onEditUser(): void {
    this.store.pipe(select(getCompanyMembersState)).subscribe(data => {
      this.companyId = data.companyDetailsModel.data.Id;
    });
    this.store.dispatch(new LoadEditMemberAction(this.companyId, this.params.data.Id));
  }
}
