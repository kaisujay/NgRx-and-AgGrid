import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { Observable, Subscription, debounceTime, filter, first, fromEvent, switchMap } from 'rxjs';
import { CompanyDetailsModalService } from '../../company-details/services/company-details.modal.service';
import {
  CompanyMembersActionTypes,
  ExportToXLSXAction,
  LoadAddCompanyMembersDataAction,
  LoadAddMemberAction,
  LoadCompanyDetailsAction,
  LoadCompanyMembersAction
} from '../@state/actions/company-members.action';
import { CompanyMembersState, getCompanyMembersState } from '../@state/reducers/company-members.reducer';
import { COMPANY_MEMBERS_GRID_OPTIONS } from '../models/company-members.grid.model';
import { CompanyMembersModalTypes, RemoveMemberPassValue } from '../models/company-members.model';

@Component({
  selector: 'app-company-members',
  templateUrl: './company-members.component.html',
  styleUrls: ['./company-members.component.scss']
})
export class CompanyMembersComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;

  public companyId: string;
  public companyName: string;
  public removeMemberPassValue: RemoveMemberPassValue;
  public CompanyMembersModalType = CompanyMembersModalTypes;

  public companyMembersState$: Observable<CompanyMembersState>;
  private subscriptions: Subscription[] = [];
  public defaultSortModel = {
    sort: 'asc',
    colId: 'Email'
  };

  public gridOptions = COMPANY_MEMBERS_GRID_OPTIONS;
  public gridApi: GridApi;

  public constructor(
    private route: ActivatedRoute,
    private actions$: Actions,
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService,
    private modalService: CompanyDetailsModalService,
    private store$: Store
  ) {}

  public ngOnInit() {
    this.companyId = this.route.snapshot.paramMap.get('companyId');
    this.bindDateFormatFunction();
    this.companyMembersState$ = this.store$.pipe(select(getCompanyMembersState));
    this.store$.dispatch(new LoadCompanyDetailsAction(this.companyId));
    this.store$.pipe(select(getCompanyMembersState)).subscribe(data => {
      if (data.companyDetailsModel.data !== null) {
        this.modalService.sendCompanyName(data.companyDetailsModel.data.Name);
      }
    });
    this.modalService.shareDataSendCompanyName.subscribe(name => {
      this.companyName = name;
    });
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        const getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'LastLoginDate'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['LastLoginDate'], format);
        };
      })
    );
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;

    params.api.setServerSideDatasource({
      getRows: params => {
        if (params.request.sortModel.length === 0) {
          params.request.sortModel.push(this.defaultSortModel);
        }
        this.store$.dispatch(
          new LoadCompanyMembersAction(this.companyId, {
            params: params.request,
            filter: this.filterTextBox.nativeElement.value
          })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(action => action.type === CompanyMembersActionTypes.LoadCompanyMembersSuccess),
              switchMap(() => this.store$.select(getCompanyMembersState)),
              first()
            )
            .subscribe(state => {
              params.success({
                rowData: state.data.loadCompanyMembers.rowData,
                rowCount: state.data.loadCompanyMembers.rowCount
              });
            })
        );
        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(
                action =>
                  action.type === CompanyMembersActionTypes.CloseModals ||
                  action.type === CompanyMembersActionTypes.SaveRemoveMemberSuccess ||
                  action.type === CompanyMembersActionTypes.SaveAddMemberSuccess
              ),
              first()
            )
            .subscribe(_ => {
              this.gridApi.refreshServerSideStore({
                route: null,
                purge: false
              });
            })
        );
      }
    });
  }

  public ngAfterViewInit(): void {
    this.subscriptions.push(
      fromEvent(this.filterTextBox.nativeElement, 'input')
        .pipe(debounceTime(500))
        .subscribe(() => {
          this.gridApi.refreshServerSideStore({ route: null, purge: false });
        })
    );
  }

  public getRemoveData(data: RemoveMemberPassValue) {
    this.removeMemberPassValue = data;
  }

  public export() {
    this.store$.dispatch(new ExportToXLSXAction(this.companyId, this.filterTextBox.nativeElement.value));
  }

  public onClickAddMember() {
    this.store$.dispatch(new LoadAddMemberAction());
    this.store$.dispatch(new LoadAddCompanyMembersDataAction(this.companyId));
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
}
