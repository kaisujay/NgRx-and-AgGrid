import { Component, Input, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CloseRemoveMemberAction, SaveRemoveMemberAction } from '../../@state/actions/company-members.action';
import { CompanyMembersState, getCompanyMembersState } from '../../@state/reducers/company-members.reducer';
import { RemoveMemberPassValue } from '../../models/company-members.model';

@Component({
  selector: 'app-remove-member',
  templateUrl: './remove-member.component.html',
  styleUrls: ['./remove-member.component.scss']
})
export class RemoveMemberComponent implements OnInit {
  @Input() public RemoveDataValues: RemoveMemberPassValue;

  public companyMembersState$: Observable<CompanyMembersState>;

  public constructor(private store$: Store) {}

  public ngOnInit(): void {
    this.companyMembersState$ = this.store$.pipe(select(getCompanyMembersState));
  }

  public onClose() {
    this.store$.dispatch(new CloseRemoveMemberAction());
  }

  public onSave() {
    this.store$.dispatch(new SaveRemoveMemberAction(this.RemoveDataValues.CompanyId, this.RemoveDataValues.UserId));
  }
}
