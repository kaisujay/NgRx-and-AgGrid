import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IconModule, LoaderModule, PopoverModule, SPRFormsModule, TabTemplatePanelModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { ExportToXlsxCompanyMembersEffect } from './@state/effects/excel-to-export-company-members.effect';
import { LoadAddNewMemberDataEffect } from './@state/effects/load-add-new-member-data.effect';
import { LoadCompanyDetailsEffect } from './@state/effects/load-company-details.effect';
import { LoadCompanyMembersEffect } from './@state/effects/load-company-members.effect';
import { LoadEditMemberEffect } from './@state/effects/load-edit-member.effect';
import { SaveAddMemberEffect } from './@state/effects/save-add-member.effect ';
import { SaveEditMemberEffect } from './@state/effects/save-edit-member.effect';
import { SaveRemoveMemberEffect } from './@state/effects/save-remove-member.effect';
import { CompanyMembersStateReducer } from './@state/reducers/company-members.reducer';
import { CompanyMembersRoutingModule } from './company-members-routing.module';
import { AddEditMemberComponent } from './components/add-edit-member/add-edit-member.component';
import { CompanyMembersComponent } from './components/company-members.component';
import { RemoveMemberComponent } from './components/remove-member/remove-member.component';
import { CompanyMembersExportToExcelService } from './services/company-members.export-to-excel.service';
import { CompanyMembersHttpService } from './services/company-members.http.service';

@NgModule({
  declarations: [CompanyMembersComponent, AddEditMemberComponent, RemoveMemberComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    LoaderModule,
    TabTemplatePanelModule,
    AgGridModule.withComponents([CheckboxRendererComponent]),
    StoreModule.forFeature('companyMembers', CompanyMembersStateReducer),
    EffectsModule.forFeature([
      LoadCompanyMembersEffect,
      LoadCompanyDetailsEffect,
      LoadEditMemberEffect,
      SaveRemoveMemberEffect,
      LoadAddNewMemberDataEffect,
      SaveAddMemberEffect,
      SaveEditMemberEffect,
      ExportToXlsxCompanyMembersEffect
    ]),
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    PopoverModule,
    SPRFormsModule,
    CompanyMembersRoutingModule,
    IconModule
  ],
  providers: [CompanyMembersExportToExcelService, CompanyMembersHttpService]
})
export class CompanyMembersModule {}
