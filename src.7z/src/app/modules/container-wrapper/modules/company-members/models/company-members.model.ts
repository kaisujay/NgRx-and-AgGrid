import { CompanyPermissionsModel } from '../../company-permissions/models/permission-state.model';

export interface CompanyMembersResponseModel {
  Count: number;
  Items: ItemModel[];
  PageCount: number;
  PageNumber: number;
  PageSize: number;
}

export type CompanyMembersModalType = 'ADD' | 'EDIT';

export enum CompanyMembersModalTypes {
  ADD = 'ADD',
  EDIT = 'EDIT'
}

export const NewMemberPermissionModel = {
  FixedIncomeAllowDealMonitor: {
    Enabled: false
  },
  Orders: {
    Enabled: false
  },
  FixedIncomeAnalytics: {
    Enabled: false
  },
  OrdersReadOnly: {
    Enabled: false
  },
  OrdersMultiple: {
    Enabled: false
  },
  DealQuery: {
    Enabled: false
  },
  ActivityStream: {
    Enabled: false
  },
  AggregatedOrderManagement: {
    Enabled: false
  },
  ReleaseFixAllocations: {
    Enabled: false
  },
  PrimaryOrderManagement: {
    Enabled: false
  },
  InternalOrderEntry: {
    Enabled: false
  },
  EquityDealMonitorV2: {
    Enabled: false
  },
  EquityOrders: {
    Enabled: false
  },
  EquityOrdersReadOnly: {
    Enabled: false
  },
  EquityAnalytics: {
    Enabled: false
  },
  MunicipalStreetCalendar: {
    Enabled: false
  },
  MunicipalDealMonitor: {
    Enabled: false
  },
  MunicipalInternalStatusInterested: {
    Enabled: false
  },
  MunicipalInternalStatusInProgress: {
    Enabled: false
  },
  MunicipalInternalStatusApproved: {
    Enabled: false
  },
  MunicipalInternalStatusNotApproved: {
    Enabled: false
  },
  EquityDealDatabase: {
    Enabled: false
  },
  EquityDealQuery: {
    Enabled: false
  },
  InternalCommentsAndAlerting: {
    Enabled: false
  },
  InternalDealCreate: {
    Enabled: false
  },
  MunicipalMmdData: {
    Enabled: false
  }
};

export interface CreateMemberPermissionModel {
  FixedIncomeAllowDealMonitor: Enabled;
  Orders: Enabled;
  FixedIncomeAnalytics: Enabled;
  OrdersReadOnly: Enabled;
  OrdersMultiple: Enabled;
  DealQuery: Enabled;
  ActivityStream: Enabled;
  AggregatedOrderManagement: Enabled;
  ReleaseFixAllocations: Enabled;
  PrimaryOrderManagement: Enabled;
  InternalOrderEntry: Enabled;
  EquityDealMonitorV2: Enabled;
  EquityOrders: Enabled;
  EquityOrdersReadOnly: Enabled;
  EquityAnalytics: Enabled;
  MunicipalStreetCalendar: Enabled;
  MunicipalDealMonitor: Enabled;
  MunicipalInternalStatusInterested: Enabled;
  MunicipalInternalStatusInProgress: Enabled;
  MunicipalInternalStatusApproved: Enabled;
  MunicipalInternalStatusNotApproved: Enabled;
  EquityDealDatabase: Enabled;
  EquityDealQuery: Enabled;
  InternalCommentsAndAlerting: Enabled;
  InternalDealCreate: Enabled;
  MunicipalMmdData: Enabled;
}

export interface Enabled {
  Enabled: boolean;
}

export interface ItemModel {
  Id: string;
  FirstName: string;
  LastName: string;
  Email: string;
  Status: string;
  LastLoginDate: string;
  Lockout: boolean;
  Country: string;
  Role: string;
  Title: string;
  City: string;
  IpreoAccountId: string;
  InvitationStatus?: InvitationStatusEnum;
  Permissions: string;
}

export enum InvitationStatusEnum {
  Completed = 1,
  Pending = 2,
  Expired = 3
}

export interface MembershipsResponseModel {
  Title: string;
  City: string;
  Country: string;
  HomePage: string;
  Email: string;
  PhoneNumber: string;
  Emails: Email[];
  Phones?: Phone[];
  SentToOrionQueue: boolean;
  ApiOnly: boolean;
  IsFixServiceAccount: boolean;
  ThinkFolioUserId: string;
  IpreoAccountId: string;
  Role: string;
  IpreoAccountIntegrationRequired: boolean;
  InvitationStatus?: string;
  AcceptTermsOfUseRequired: boolean;
  Companies?: Company[];
  Containers: Container[];
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  UserName: string;
  FirstName: string;
  LastName: string;
  Status: string;
  Lockout: boolean;
  LastLoginDate: string;
  PasswordChangeRequired: boolean;
  Language: string;
  NumberFormat: string;
  Currency: string;
  DateFormat: string;
  TimeFormat: string;
  Timezone: string;
}

export interface Email {
  UserId: string;
  Email: string;
  IsPrimary: boolean;
  IsConfirmed: boolean;
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
}

export interface Phone {
  UserId: string;
  PhoneNumber: string;
  IsPrimary: boolean;
  IsConfirmed: boolean;
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
}

export interface Company {
  Id: string;
  CompanyName: string;
  CompanyId: string;
  RowVersion: string;
}

export interface Container {
  Id: string;
  IsAdmin: boolean;
  IsExcludedFromMembershipAudit: boolean;
}

export interface RemoveMemberPassValue {
  CompanyId: string;
  UserId: string;
  FirstName: string;
  LastName: string;
}

export interface AddEditMembershipPayloadModel {
  CompanyId: string;
  UserId: string;
  MemberPermissions: Partial<CreateMemberPermissionModel>;
}

export interface MembershipPermissionsModel {
  MemberPermissions: CompanyPermissionsModel;
}
