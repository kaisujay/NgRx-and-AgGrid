import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Observable } from 'rxjs';
import { UserStatusResponseModel } from '../models/user-status-response.model';

@Injectable()
export class UserPoolHttpService {
  public constructor(private http: HttpClient) {}

  public getUserStatus(): Observable<UserStatusResponseModel[]> {
    const url = buildApiString(API.userPool.getUserStatus);

    return this.http.get<UserStatusResponseModel[]>(url);
  }
}
