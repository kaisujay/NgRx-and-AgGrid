import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API, buildApiString } from '@core/constants/API';
import { Country } from '@shared/models/countries.model';
import { Observable } from 'rxjs';
import { ContainerDetails } from '../../../models/container-details.model';
import {
  CreateNewUserInUserPoolPayloadModel,
  CreateNewUserInUserPoolResponseModel,
  IndivisualUserModel,
  UpdateUserInUserPoolPayloadModel,
  UserRoleModel
} from '../models/create-new-user.model';

@Injectable()
export class UserPoolUserHttpService {
  public constructor(private http: HttpClient) {}

  public getCountries(): Observable<Country[]> {
    return this.http.get<Country[]>(API.countries);
  }

  public getUserRoles(): Observable<UserRoleModel[]> {
    return this.http.get<UserRoleModel[]>(API.userPool.getUserRoles);
  }

  public createNewUser(
    id: string,
    userModel: CreateNewUserInUserPoolPayloadModel
  ): Observable<CreateNewUserInUserPoolResponseModel> {
    const url = buildApiString(API.userPool.postNewUser, { id });

    return this.http.post<CreateNewUserInUserPoolResponseModel>(url, userModel);
  }

  public getContainerById(id: string): Observable<ContainerDetails> {
    const url = buildApiString(API.containers.get, { id });
    return this.http.get<ContainerDetails>(url);
  }

  public getUserDetails(id: string): Observable<IndivisualUserModel> {
    const url = buildApiString(API.userPool.getUserDetails, {
      id
    });

    return this.http.get<IndivisualUserModel>(url);
  }

  public updateUser(
    containerId: string,
    userId: string,
    userModel: UpdateUserInUserPoolPayloadModel
  ): Observable<IndivisualUserModel> {
    const url = buildApiString(API.userPool.putUser, { containerId, userId });

    return this.http.put<IndivisualUserModel>(url, userModel);
  }

  public resetPassword(userId: string): Observable<string> {
    return this.http.put<string>(API.userPool.resetPassword, {
      UserId: userId
    });
  }

  public deleteUser(id: string): Observable<void> {
    const url = buildApiString(API.userPool.getUserDetails, {
      id
    });

    return this.http.delete<void>(url);
  }
}
