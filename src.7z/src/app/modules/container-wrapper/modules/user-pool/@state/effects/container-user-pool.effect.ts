import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  LoadContainerAction,
  LoadContainerFailedAction,
  LoadContainerSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class ContainerUsersPoolEffect {
  public constructor(
    private actions$: Actions,
    private userPoolHttpService: UserPoolUserHttpService
  ) {}
  public containerUsersPoolEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.LoadContainer),
      switchMap((action: LoadContainerAction) => {
        return this.userPoolHttpService.getContainerById(action.containerId).pipe(
          map(data => new LoadContainerSuccessAction(data)),
          catchError(_err => of(new LoadContainerFailedAction()))
        );
      })
    )
  );
}
