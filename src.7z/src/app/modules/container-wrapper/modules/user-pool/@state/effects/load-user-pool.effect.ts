import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolResponseItemModel } from '../../models/user-pool-response.model';
import { UserPoolHttpService } from '../../services/user-pool.http.service';
import {
  LoadUserPoolAction,
  LoadUserPoolFailedAction,
  LoadUserPoolSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class LoadUsersPoolEffect {
  public constructor(
    private actions$: Actions,
    private userPoolHttpService: UserPoolHttpService,
    private kendoAdapterService: KendoAdapterService
  ) {}
  public loadUsersPoolEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.LoadUserPool),
      switchMap((action: LoadUserPoolAction) => {
        return this.kendoAdapterService
          .getWithId<UserPoolResponseItemModel>(
            API.userPool.getUsersforUserPool + '?containerId=' + action.containerId + '&',
            action.payload.params,
            action.payload.filter
          )
          .pipe(
            map(response => {
              return new LoadUserPoolSuccessAction(response);
            }),
            catchError(_err => of(new LoadUserPoolFailedAction()))
          );
      })
    )
  );
}
