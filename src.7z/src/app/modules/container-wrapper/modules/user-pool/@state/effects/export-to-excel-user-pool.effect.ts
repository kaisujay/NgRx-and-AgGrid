import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';

import { CupcakeFlavors } from '@ipreo/ngx-sprinkles';
import { MessageAlertService } from '@shared/services/message-alert.service';
import { UserPoolExportToExcelService } from '../../services/user-pool.export-to-excel.service';
import {
  ExportToXLSXAction,
  ExportToXLSXFailedAction,
  ExportToXLSXSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class ExportToXlsxUserPoolEffect {
  public constructor(
    private actions$: Actions,
    private messageAlertSvc: MessageAlertService,
    private exportToExcelService: UserPoolExportToExcelService
  ) {}
  public exportToXlsxEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.ExportToXLSX),
      switchMap((action: ExportToXLSXAction) =>
        this.exportToExcelService
          .export(API.userPool.getUsersforUserPool + '?containerId=' + action.containerId + '&', action.filter)
          .pipe(
            map(_res => this.handleSuccess()),
            catchError(_err => this.handleError())
          )
      )
    )
  );

  private handleSuccess() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Success, 'Exported successfully');
    return new ExportToXLSXSuccessAction();
  }

  private handleError() {
    this.messageAlertSvc.showMessageAlert(CupcakeFlavors.Danger, 'Error while Exporting');
    return of(new ExportToXLSXFailedAction());
  }
}
