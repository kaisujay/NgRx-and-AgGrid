import { createFeatureSelector } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { ContainerDetails } from 'src/app/modules/container-wrapper/models/container-details.model';
import { IndivisualUserModel, UserRoleModel } from '../../models/create-new-user.model';
import { UserPoolResponseItemModel } from '../../models/user-pool-response.model';
import { UserPoolActionTypes, UserPoolActionsUnion } from '../actions/user-pool.action';

export interface UserPoolState {
  data: {
    userPool: {
      rowData: UserPoolResponseItemModel[];
      rowCount: number;
    };
    isLoadError: boolean;
  };
  loadCountryAndRoles: {
    countries: Country[];
    userRoles: UserRoleModel[];
    isLoading: boolean;
    isLoadError: boolean;
  };
  loadContainer: {
    container: ContainerDetails;
    isLoadError: boolean;
  };
  loadUserDetails: {
    user: IndivisualUserModel;
    isLoadError: boolean;
  };
  exportToXLSX: {
    isExporting: boolean;
  };
  editUser: {
    isEditMode: boolean;
    editedUser: UserPoolResponseItemModel;
    isResetPasswordModalVisible: boolean;
    isResettingPassword: boolean;
    isSaving: boolean;
    isUnlocking: boolean;
    isUnlockModalVisible: boolean;
    errorMsg: string;
  };
  createUser: {
    isCreateMode: boolean;
    isCreating: boolean;
    isPasswordModalVisible: boolean;
    errorMsg: string;
  };
  deleteUser: {
    isDeleteMode: boolean;
    isDeleting: boolean;
  };
}

export const initialState: UserPoolState = {
  data: {
    userPool: {
      rowData: [],
      rowCount: 0
    },
    isLoadError: false
  },
  loadCountryAndRoles: {
    countries: [],
    userRoles: [],
    isLoading: false,
    isLoadError: false
  },
  loadContainer: {
    container: null,
    isLoadError: false
  },
  loadUserDetails: {
    user: null,
    isLoadError: false
  },
  exportToXLSX: {
    isExporting: false
  },
  editUser: {
    isEditMode: false,
    isResettingPassword: false,
    editedUser: null,
    isResetPasswordModalVisible: false,
    isSaving: false,
    isUnlocking: false,
    isUnlockModalVisible: false,
    errorMsg: null
  },
  createUser: {
    isCreateMode: false,
    isCreating: false,
    isPasswordModalVisible: false,
    errorMsg: null
  },
  deleteUser: {
    isDeleteMode: false,
    isDeleting: false
  }
};

export function UserPoolStateReducer(state: UserPoolState = initialState, action: UserPoolActionsUnion): UserPoolState {
  switch (action.type) {
    case UserPoolActionTypes.LoadUserPoolSuccess:
      return {
        ...state,
        data: {
          ...state.data,
          userPool: {
            ...action.payload
          }
        }
      };
    case UserPoolActionTypes.LoadUserPoolFailed:
      return {
        ...state,
        data: {
          ...state.data,
          isLoadError: true
        }
      };
    case UserPoolActionTypes.ExportToXLSX:
      return {
        ...state,
        exportToXLSX: {
          isExporting: true
        }
      };

    case UserPoolActionTypes.LoadCountryAndUserRole:
      return {
        ...state,
        loadCountryAndRoles: {
          ...state.loadCountryAndRoles,
          isLoading: true
        }
      };

    case UserPoolActionTypes.LoadCountryAndUserRoleSuccess:
      return {
        ...state,
        loadCountryAndRoles: {
          ...action.payload,
          isLoading: false,
          isLoadError: false
        }
      };

    case UserPoolActionTypes.LoadCountryAndUserRoleFailed:
      return {
        ...state,
        loadCountryAndRoles: {
          ...state.loadCountryAndRoles,
          isLoading: false,
          isLoadError: true
        }
      };

    case UserPoolActionTypes.LoadContainer:
      return {
        ...state,
        loadContainer: {
          ...state.loadContainer
        }
      };

    case UserPoolActionTypes.LoadContainerSuccess:
      return {
        ...state,
        loadContainer: {
          ...action,
          isLoadError: false
        }
      };

    case UserPoolActionTypes.LoadContainerFailed:
      return {
        ...state,
        loadContainer: {
          ...state.loadContainer,
          isLoadError: true
        }
      };

    case UserPoolActionTypes.LoadUserDetails:
      return {
        ...state,
        loadUserDetails: {
          ...state.loadUserDetails
        }
      };

    case UserPoolActionTypes.LoadUserDetailsSuccess:
      return {
        ...state,
        loadUserDetails: {
          ...action,
          isLoadError: false
        }
      };

    case UserPoolActionTypes.LoadUserDetailsFailed:
      return {
        ...state,
        loadUserDetails: {
          ...state.loadUserDetails,
          isLoadError: true
        }
      };

    case UserPoolActionTypes.EditUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true
        }
      };

    case UserPoolActionTypes.SaveEditedUser:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false,
          isSaving: true
        }
      };

    case UserPoolActionTypes.SaveEditedUserSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: false,
          isSaving: false
        }
      };

    case UserPoolActionTypes.SaveEditedUserFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isEditMode: true,
          isSaving: false,
          errorMsg: action.errorMessage
        }
      };

    case UserPoolActionTypes.CreateUser:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreateMode: true
        }
      };

    case UserPoolActionTypes.SaveCreatedUser:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: true
        }
      };

    case UserPoolActionTypes.SaveCreatedUserSuccess:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          isPasswordModalVisible: true,
          isCreateMode: false
        }
      };

    case UserPoolActionTypes.SaveCreatedUserFailed:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          errorMsg: action.errorMessage
        }
      };

    case UserPoolActionTypes.ClearCreateUserHttpErrors:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreating: false,
          errorMsg: null
        }
      };

    case UserPoolActionTypes.ClearEditUserHttpErrors:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          errorMsg: null
        }
      };

    case UserPoolActionTypes.ResetPassword:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: true
        }
      };

    case UserPoolActionTypes.ResetPasswordSuccess:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false,
          isEditMode: false,
          editedUser: null,
          isResetPasswordModalVisible: true
        }
      };

    case UserPoolActionTypes.ResetPasswordFailed:
      return {
        ...state,
        editUser: {
          ...state.editUser,
          isResettingPassword: false
        }
      };

    case UserPoolActionTypes.DeleteUser:
      return {
        ...state,
        deleteUser: {
          ...state.deleteUser,
          isDeleteMode: true
        },
        editUser: {
          ...state.editUser,
          isEditMode: false
        }
      };

    case UserPoolActionTypes.SaveDeleteUser:
      return {
        ...state,
        deleteUser: {
          ...state.deleteUser,
          isDeleting: true
        }
      };

    case UserPoolActionTypes.SaveDeleteUserSuccess:
      return {
        ...state,
        deleteUser: {
          ...state.deleteUser,
          isDeleteMode: false,
          isDeleting: false
        },
        editUser: {
          ...state.editUser,
          isEditMode: false
        }
      };

    case UserPoolActionTypes.SaveDeleteUserFailed:
      return {
        ...state,
        deleteUser: {
          ...state.deleteUser,
          isDeleteMode: true,
          isDeleting: false
        }
      };

    case UserPoolActionTypes.ExportToXLSXSuccess:
    case UserPoolActionTypes.ExportToXLSXFailed:
      return {
        ...state,
        exportToXLSX: {
          isExporting: false
        }
      };

    case UserPoolActionTypes.CloseModals:
      return {
        ...state,
        createUser: {
          ...state.createUser,
          isCreateMode: false,
          isPasswordModalVisible: false
        },
        editUser: {
          ...state.editUser,
          isEditMode: false,
          editedUser: null,
          isResetPasswordModalVisible: false,
          isUnlockModalVisible: false
        },
        deleteUser: {
          ...state.deleteUser,
          isDeleteMode: false
        }
      };

    case UserPoolActionTypes.CloseDeleteUserModals:
      return {
        ...state,
        deleteUser: {
          ...state.deleteUser,
          isDeleteMode: false
        }
      };

    default:
      return state;
  }
}

export const getUserPoolState = createFeatureSelector<UserPoolState>('userPool');
