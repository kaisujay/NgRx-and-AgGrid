import { Injectable } from '@angular/core';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  ResetPasswordAction,
  ResetPasswordFailedAction,
  ResetPasswordSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class ResetPasswordEffect {
  public constructor(
    private actions$: Actions,
    private userPoolUserHttpService: UserPoolUserHttpService,
    private credentialsService: CredentialsService
  ) {}
  public resetPasswordEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.ResetPassword),
      switchMap((action: ResetPasswordAction) =>
        this.userPoolUserHttpService.resetPassword(action.userId).pipe(
          map(response => {
            this.credentialsService.set({
              password: response['Password'],
              email: action.email
            });

            return new ResetPasswordSuccessAction();
          }),
          catchError(_err => of(new ResetPasswordFailedAction()))
        )
      )
    )
  );
}
