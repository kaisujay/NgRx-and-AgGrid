import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  LoadUserDetailsAction,
  LoadUserDetailsFailedAction,
  LoadUserDetailsSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class LoadUserDetailsEffect {
  public constructor(
    private actions$: Actions,
    private userPoolService: UserPoolUserHttpService,
    private store$: Store
  ) {}
  public loadUserDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.EditUser),
      switchMap((action: LoadUserDetailsAction) => {
        return this.userPoolService.getUserDetails(action.userId).pipe(
          map(res => new LoadUserDetailsSuccessAction(res)),
          catchError(() => of(new LoadUserDetailsFailedAction()))
        );
      })
    )
  );
}
