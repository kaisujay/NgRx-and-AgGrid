import { Action } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { ContainerDetails } from 'src/app/modules/container-wrapper/models/container-details.model';
import {
  CreateNewUserInUserPoolPayloadModel,
  IndivisualUserModel,
  UpdateUserInUserPoolPayloadModel,
  UserRoleModel
} from '../../models/create-new-user.model';
import { UserPoolResponseItemModel } from '../../models/user-pool-response.model';

export enum UserPoolActionTypes {
  LoadUserPool = '[User Pool] Load User Pool',
  LoadUserPoolSuccess = '[User Pool] Load User Pool Success',
  LoadUserPoolFailed = '[User Pool] Load User Pool Failed',

  LoadCountryAndUserRole = '[User Pool] Load Country And User Role',
  LoadCountryAndUserRoleSuccess = '[User Pool] Load Country And User Role Success',
  LoadCountryAndUserRoleFailed = '[User Pool] Load Country And User Role Failed',

  LoadContainer = '[User Pool] Load Container',
  LoadContainerSuccess = '[User Pool] Load Container Success',
  LoadContainerFailed = '[User Pool] Load Container Failed',

  LoadUserDetails = '[User Pool] Load User Details',
  LoadUserDetailsSuccess = '[User Pool] Load User Details Success',
  LoadUserDetailsFailed = '[User Pool] Load User Details Failed',

  EditUser = '[User Pool] Edit User',

  SaveEditedUser = '[User Pool] Save Edited User',
  SaveEditedUserSuccess = '[User Pool] Save Edited User Success',
  SaveEditedUserFailed = '[User Pool] Save Edited User Failed',

  CreateUser = '[User Pool] Create User',

  SaveCreatedUser = '[User Pool] Save Created User',
  SaveCreatedUserSuccess = '[User Pool] Save Created User Success',
  SaveCreatedUserFailed = '[User Pool] Save Created User Failed',

  ClearCreateUserHttpErrors = '[User Pool] Clear Create User Http Errors',
  ClearEditUserHttpErrors = '[User Pool] Clear Edit User Http Errors',

  ResetPassword = '[Admin Users] Reset Password',
  ResetPasswordSuccess = '[Admin Users] Reset Password Success',
  ResetPasswordFailed = '[Admin Users] Reset Password Failed',

  DeleteUser = '[User Pool] Delete User',

  SaveDeleteUser = '[User Pool] Save Delete User',
  SaveDeleteUserSuccess = '[User Pool] Save Delete User Success',
  SaveDeleteUserFailed = '[User Pool] Save Delete User Failed',

  ExportToXLSX = '[User Pool] Export to XLSX',
  ExportToXLSXSuccess = '[User Pool] Export to XLSX Success',
  ExportToXLSXFailed = '[User Pool] Export to XLSX Failed',

  CloseModals = '[User Pool] Close Modals',
  CloseDeleteUserModals = '[User Pool] Close Delete User Modals'
}

export class LoadUserPoolAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserPool;
  public constructor(
    public containerId: string,
    public payload: {
      params: IServerSideGetRowsRequest;
      filter: string;
    }
  ) {}
}

export class LoadUserPoolSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserPoolSuccess;
  public constructor(
    public payload: {
      rowData: UserPoolResponseItemModel[];
      rowCount: number;
    }
  ) {}
}

export class LoadUserPoolFailedAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserPoolFailed;
  public constructor() {}
}

export class LoadCountryAndUserRoleAction implements Action {
  public readonly type = UserPoolActionTypes.LoadCountryAndUserRole;
  public constructor() {}
}

export class LoadCountryAndUserRoleSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.LoadCountryAndUserRoleSuccess;
  public constructor(public payload: { countries: Country[]; userRoles: UserRoleModel[] }) {}
}

export class LoadCountryAndUserRoleFailedAction implements Action {
  public readonly type = UserPoolActionTypes.LoadCountryAndUserRoleFailed;
  public constructor() {}
}

export class LoadContainerAction implements Action {
  public readonly type = UserPoolActionTypes.LoadContainer;
  public constructor(public containerId: string) {}
}

export class LoadContainerSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.LoadContainerSuccess;
  public constructor(public container: ContainerDetails) {}
}

export class LoadContainerFailedAction implements Action {
  public readonly type = UserPoolActionTypes.LoadContainerFailed;
  public constructor() {}
}

export class LoadUserDetailsAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserDetails;
  public constructor(public userId: string) {}
}

export class LoadUserDetailsSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserDetailsSuccess;
  public constructor(public user: IndivisualUserModel) {}
}

export class LoadUserDetailsFailedAction implements Action {
  public readonly type = UserPoolActionTypes.LoadUserDetailsFailed;
  public constructor() {}
}

export class EditUserAction implements Action {
  public readonly type = UserPoolActionTypes.EditUser;
  public constructor(public userId: string) {}
}

export class SaveEditedUserAction implements Action {
  public readonly type = UserPoolActionTypes.SaveEditedUser;
  public constructor(
    public containerId: string,
    public userId: string,
    public user: UpdateUserInUserPoolPayloadModel
  ) {}
}

export class SaveEditedUserSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.SaveEditedUserSuccess;
  public constructor() {}
}

export class SaveEditedUserFailedAction implements Action {
  public readonly type = UserPoolActionTypes.SaveEditedUserFailed;
  public constructor(public errorMessage: string) {}
}

export class CreateUserAction implements Action {
  public readonly type = UserPoolActionTypes.CreateUser;
  public constructor() {}
}

export class SaveCreatedUserAction implements Action {
  public readonly type = UserPoolActionTypes.SaveCreatedUser;
  public constructor(
    public containerId: string,
    public payload: CreateNewUserInUserPoolPayloadModel
  ) {}
}

export class SaveCreatedUserSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.SaveCreatedUserSuccess;
  public constructor() {}
}

export class SaveCreatedUserFailedAction implements Action {
  public readonly type = UserPoolActionTypes.SaveCreatedUserFailed;
  public constructor(public errorMessage: string) {}
}

export class ClearCreateUserHttpErrorsAction implements Action {
  public readonly type = UserPoolActionTypes.ClearCreateUserHttpErrors;
  public constructor() {}
}

export class ClearEditUserHttpErrorsAction implements Action {
  public readonly type = UserPoolActionTypes.ClearEditUserHttpErrors;
  public constructor() {}
}

export class ResetPasswordAction implements Action {
  public readonly type = UserPoolActionTypes.ResetPassword;
  public constructor(
    public userId: string,
    public email: string
  ) {}
}

export class ResetPasswordSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.ResetPasswordSuccess;
  public constructor() {}
}

export class ResetPasswordFailedAction implements Action {
  public readonly type = UserPoolActionTypes.ResetPasswordFailed;
  public constructor() {}
}

export class DeleteUserAction implements Action {
  public readonly type = UserPoolActionTypes.DeleteUser;
  public constructor() {}
}

export class SaveDeleteUserAction implements Action {
  public readonly type = UserPoolActionTypes.SaveDeleteUser;
  public constructor(public userId: string) {}
}

export class SaveDeleteUserSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.SaveDeleteUserSuccess;
  public constructor() {}
}

export class SaveDeleteUserFailedAction implements Action {
  public readonly type = UserPoolActionTypes.SaveDeleteUserFailed;
  public constructor() {}
}

export class ExportToXLSXAction implements Action {
  public readonly type = UserPoolActionTypes.ExportToXLSX;
  public constructor(
    public containerId: string,
    public filter: string
  ) {}
}

export class ExportToXLSXSuccessAction implements Action {
  public readonly type = UserPoolActionTypes.ExportToXLSXSuccess;
  public constructor() {}
}

export class ExportToXLSXFailedAction implements Action {
  public readonly type = UserPoolActionTypes.ExportToXLSXFailed;
  public constructor() {}
}

export class CloseModalsAction implements Action {
  public readonly type = UserPoolActionTypes.CloseModals;
  public constructor() {}
}

export class CloseDeleteUserAction implements Action {
  public readonly type = UserPoolActionTypes.CloseDeleteUserModals;
  public constructor() {}
}

export type UserPoolActionsUnion =
  | LoadUserPoolAction
  | LoadUserPoolSuccessAction
  | LoadUserPoolFailedAction
  | LoadCountryAndUserRoleAction
  | LoadCountryAndUserRoleSuccessAction
  | LoadCountryAndUserRoleFailedAction
  | LoadContainerAction
  | LoadContainerSuccessAction
  | LoadContainerFailedAction
  | LoadUserDetailsAction
  | LoadUserDetailsSuccessAction
  | LoadUserDetailsFailedAction
  | EditUserAction
  | SaveEditedUserAction
  | SaveEditedUserSuccessAction
  | SaveEditedUserFailedAction
  | CreateUserAction
  | SaveCreatedUserAction
  | SaveCreatedUserSuccessAction
  | SaveCreatedUserFailedAction
  | ClearCreateUserHttpErrorsAction
  | ClearEditUserHttpErrorsAction
  | ResetPasswordAction
  | ResetPasswordSuccessAction
  | ResetPasswordFailedAction
  | DeleteUserAction
  | SaveDeleteUserAction
  | SaveDeleteUserSuccessAction
  | SaveDeleteUserFailedAction
  | ExportToXLSXAction
  | ExportToXLSXSuccessAction
  | ExportToXLSXFailedAction
  | CloseModalsAction
  | CloseDeleteUserAction;
