import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { AdminSharedModule } from '@shared/shared.module';
import { AgGridModule } from 'ag-grid-angular';
import { ContainerUsersPoolEffect } from './@state/effects/container-user-pool.effect';
import { CreateUserEffect } from './@state/effects/create-user-user-pool.effect';
import { DeleteUserEffect } from './@state/effects/delete-user-user-pool.effect';
import { ExportToXlsxUserPoolEffect } from './@state/effects/export-to-excel-user-pool.effect';
import { LoadCountryRoleUserPoolEffect } from './@state/effects/load-country-role-user-pool.effect';
import { LoadUserDetailsEffect } from './@state/effects/load-user-details-user-pool.effect';
import { LoadUsersPoolEffect } from './@state/effects/load-user-pool.effect';
import { ResetPasswordEffect } from './@state/effects/reset-password-user-pool.effect';
import { UpdateUserEffect } from './@state/effects/update-user-user-pool.effect';
import { UserPoolStateReducer } from './@state/reducers/user-pool.reducer';
import { CreateNewUserComponent } from './components/create-new-user/create-new-user.component';
import { DeleteUserComponent } from './components/delete-user/delete-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { UserCreatedModalContentComponent } from './components/user-created-modal-content/user-created-modal-content.component';
import { UserPoolComponent } from './components/user-pool.component';
import { UserPoolExportToExcelService } from './services/user-pool.export-to-excel.service';
import { UserPoolHttpService } from './services/user-pool.http.service';
import { UserPoolUserHttpService } from './services/user-pool.user.http.service';
import { UserPoolRoutingModule } from './user-pool-routing.module';

@NgModule({
  declarations: [
    UserPoolComponent,
    CreateNewUserComponent,
    UserCreatedModalContentComponent,
    EditUserComponent,
    DeleteUserComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    AgGridModule.withComponents([CheckboxRendererComponent]),
    StoreModule.forFeature('userPool', UserPoolStateReducer),
    EffectsModule.forFeature([
      LoadUsersPoolEffect,
      ExportToXlsxUserPoolEffect,
      CreateUserEffect,
      LoadCountryRoleUserPoolEffect,
      ContainerUsersPoolEffect,
      LoadUserDetailsEffect,
      UpdateUserEffect,
      ResetPasswordEffect,
      DeleteUserEffect
    ]),
    UserPoolRoutingModule,
    AdminSharedModule,
    FormsModule,
    ReactiveFormsModule,
    SPRFormsModule,
    CheckboxModule
  ],
  providers: [UserPoolHttpService, UserPoolExportToExcelService, UserPoolUserHttpService]
})
export class UserPoolModule {}
