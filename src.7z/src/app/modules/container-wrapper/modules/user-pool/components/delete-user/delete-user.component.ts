import { Component, Input, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { CloseDeleteUserAction, EditUserAction, SaveDeleteUserAction } from '../../@state/actions/user-pool.action';
import { UserPoolState, getUserPoolState } from '../../@state/reducers/user-pool.reducer';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.scss']
})
export class DeleteUserComponent implements OnInit {
  @Input() public UserId: string;

  public userPoolState$: Observable<UserPoolState>;

  public constructor(private store$: Store) {}

  public ngOnInit(): void {
    this.userPoolState$ = this.store$.pipe(select(getUserPoolState));
  }

  public onClose() {
    this.store$.dispatch(new CloseDeleteUserAction());
    this.store$.dispatch(new EditUserAction(this.UserId));
  }

  public onSave() {
    this.store$.dispatch(new SaveDeleteUserAction(this.UserId));
  }
}
