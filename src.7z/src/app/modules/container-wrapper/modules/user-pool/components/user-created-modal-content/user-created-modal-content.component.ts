import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { CredentialsService } from '@core/services/credentials/credentials.service';
import { Store } from '@ngrx/store';
import { CloseModalsAction } from '../../@state/actions/user-pool.action';

@Component({
  selector: 'app-user-created-modal-content',
  templateUrl: './user-created-modal-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserCreatedModalContentComponent implements OnInit, OnDestroy {
  @Input() public isResetPassword: boolean;

  public credentials: { email: string; password: string };

  public constructor(
    private store: Store,
    private credentialsService: CredentialsService
  ) {}

  public ngOnInit(): void {
    this.credentials = this.credentialsService.get();
  }

  public onModalClose(): void {
    this.store.dispatch(new CloseModalsAction());
  }

  public ngOnDestroy(): void {
    this.credentials = null;
  }
}
