import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Actions } from '@ngrx/effects';
import { Store, select } from '@ngrx/store';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { Observable, Subscription, debounceTime, filter, first, fromEvent, map, switchMap } from 'rxjs';
import {
  CreateUserAction,
  ExportToXLSXAction,
  LoadContainerAction,
  LoadCountryAndUserRoleAction,
  LoadUserPoolAction,
  UserPoolActionTypes
} from '../@state/actions/user-pool.action';
import { UserPoolState, getUserPoolState } from '../@state/reducers/user-pool.reducer';
import { UserPoolPayloadModel } from '../models/user-pool-paylod.model';

import { DateTimeFormatDefined } from '@core/models/date-time-format';
import { DateFormatService } from '@core/services/date-format/date-format.service';
import { UserContextService } from '@core/services/user-context/user-context.service';
import { ContainerDetails } from '../../../models/container-details.model';
import { USER_POOL_GRID_OPTIONS } from '../models/user-pool-grid.model';
import { UserPoolResponseItemModel } from '../models/user-pool-response.model';

@Component({
  selector: 'app-user-pool',
  templateUrl: './user-pool.component.html',
  styleUrls: ['./user-pool.component.scss']
})
export class UserPoolComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('filterTextBox') public filterTextBox: ElementRef;

  public userPoolPayloadModel: UserPoolPayloadModel;
  public gridOptions = USER_POOL_GRID_OPTIONS;
  private gridApi: GridApi;
  private rowData: UserPoolResponseItemModel[];
  public containerId: string;
  public receivedUserId: string;

  public userPoolState$: Observable<UserPoolState>;
  public container$: Observable<ContainerDetails>;
  private subscriptions: Subscription[] = [];
  public dataLoaded = false;
  public defaultSortModel = {
    sort: 'asc',
    colId: 'Email'
  };

  public constructor(
    private route: ActivatedRoute,
    private store$: Store,
    private actions$: Actions,
    private userContextSvc: UserContextService,
    private dateFormatSvc: DateFormatService
  ) {}

  public ngOnInit(): void {
    this.containerId = this.route.snapshot.parent.parent.paramMap.get('containerId');
    this.bindDateFormatFunction();
    this.userPoolState$ = this.store$.pipe(select(getUserPoolState));
    this.container$ = this.userPoolState$.pipe(
      map(res => {
        return res.loadContainer.container;
      })
    );
  }

  public bindDateFormatFunction(): void {
    this.subscriptions.push(
      this.userContextSvc.getUserDateTimeFormat().subscribe((format: DateTimeFormatDefined) => {
        const getDateIndex = this.gridOptions.columnDefs.findIndex(
          colDef => (<ColDef>colDef).field === 'LastLoginDate'
        );
        (<ColDef>this.gridOptions.columnDefs[getDateIndex]).valueGetter = params => {
          return this.dateFormatSvc.format(<Date>params.data['LastLoginDate'], format);
        };
      })
    );
  }

  public onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;

    params.api.setServerSideDatasource({
      getRows: params => {
        if (params.request.sortModel.length === 0) {
          params.request.sortModel.push(this.defaultSortModel);
        }
        this.store$.dispatch(
          new LoadUserPoolAction(this.containerId, {
            params: params.request,
            filter: this.filterTextBox.nativeElement.value
          })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(action => action.type === UserPoolActionTypes.LoadUserPoolSuccess),
              switchMap(() => this.store$.select(getUserPoolState)),
              first()
            )
            .subscribe(state => {
              params.success({
                rowData: state.data.userPool.rowData,
                rowCount: state.data.userPool.rowCount
              });
            })
        );

        this.subscriptions.push(
          this.actions$
            .pipe(
              filter(
                action =>
                  action.type === UserPoolActionTypes.SaveCreatedUserSuccess ||
                  action.type === UserPoolActionTypes.SaveEditedUserSuccess ||
                  action.type === UserPoolActionTypes.ResetPasswordSuccess ||
                  action.type === UserPoolActionTypes.SaveDeleteUserSuccess ||
                  action.type === UserPoolActionTypes.CloseModals ||
                  action.type === UserPoolActionTypes.CloseDeleteUserModals
              ),
              first()
            )
            .subscribe(_state => {
              this.gridApi.refreshServerSideStore({
                route: null,
                purge: false
              });
            })
        );
      }
    });

    this.store$.dispatch(new LoadCountryAndUserRoleAction());
    this.store$.dispatch(new LoadContainerAction(this.containerId));
  }

  public ngAfterViewInit(): void {
    this.store$.pipe(select(getUserPoolState)).subscribe(state => {
      if (!state.data.isLoadError && !state.loadContainer.isLoadError && !state.loadCountryAndRoles.isLoadError) {
        this.subscriptions.push(
          fromEvent(this.filterTextBox.nativeElement, 'input')
            .pipe(debounceTime(500))
            .subscribe(() => {
              this.gridApi.refreshServerSideStore({ route: null, purge: false });
            })
        );
      }
    });
  }

  public onCreateNewUser() {
    this.store$.dispatch(new CreateUserAction());
  }

  public export(): void {
    this.store$.dispatch(new ExportToXLSXAction(this.containerId, this.filterTextBox.nativeElement.value));
  }

  public ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  public getUserId(userId) {
    this.receivedUserId = userId;
  }
}
