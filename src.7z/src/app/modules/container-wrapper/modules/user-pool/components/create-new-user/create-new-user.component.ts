import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { Observable } from 'rxjs';
import {
  ClearCreateUserHttpErrorsAction,
  CloseModalsAction,
  SaveCreatedUserAction
} from '../../@state/actions/user-pool.action';
import { UserPoolState, getUserPoolState } from '../../@state/reducers/user-pool.reducer';
import { UserRoleModel } from '../../models/create-new-user.model';
import { UserPoolService } from '../../services/user-pool.service';

@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.scss']
})
export class CreateNewUserComponent implements OnInit {
  @Input() public ContainerId: string;
  @Input() public ContainerName: string;
  @Input() public Countries: Country[];
  @Input() public UserRoles: UserRoleModel[];

  public userPoolState$: Observable<UserPoolState>;

  public countryOptions: SelectOptions[];
  public userRolesOptions: SelectOptions[];

  public createUserFormGroup: FormGroup;

  public constructor(
    private formBuilder: FormBuilder,
    private store$: Store
  ) {}

  public ngOnInit(): void {
    this.initForm();

    this.userPoolState$ = this.store$.pipe(select(getUserPoolState));
  }

  public initForm() {
    this.createUserFormGroup = this.formBuilder.group({
      Email: new FormControl('', [
        Validators.required,
        Validators.pattern(
          new RegExp(
            // eslint-disable-next-line no-useless-escape
            /^(([^<>()\\.,;:\s@\"]+(\.[^<>()\\.,;:\s@\"]+)*)|\".+\")@[a-zA-Z\-0-9]{2,}\.[a-zA-Z]{2,}(\.[a-zA-Z]{1,3})?$/
          )
        )
      ]),
      IpreoAccountId: new FormControl({ value: '', disabled: true }, []),
      FirstName: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      LastName: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      Title: new FormControl(''),
      Role: new FormControl(''),
      PhoneNumber: new FormControl('', [Validators.pattern('^[0-9]*$')]),
      City: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      Country: new FormControl('', [Validators.required]),
      IsContainerAdmin: new FormControl(false),
      IsExcludedFromMembershipAudit: new FormControl(false),
      ApiOnly: new FormControl(false),
      IsFixServiceAccount: new FormControl(false),
      IpreoAccountIntegrationRequired: new FormControl(false),
      ThinkFolioUserId: new FormControl('')
    });

    this.countryOptions = UserPoolService.getCountryOptions(this.Countries['countries']);

    this.userRolesOptions = UserPoolService.getUserRoleOptions(this.UserRoles);
    this.userRolesOptions.unshift({ label: '', value: '' });
  }

  public onClose(): void {
    this.store$.dispatch(new CloseModalsAction());
  }

  public onErrorModalClose(): void {
    this.store$.dispatch(new ClearCreateUserHttpErrorsAction());
  }

  public saveUser(): void {
    this.createUserFormGroup.removeControl('IsExcludedFromMembershipAudit');

    this.createUserFormGroup.get('FirstName').setValue(this.createUserFormGroup.get('FirstName').value.trim());
    this.createUserFormGroup.get('LastName').setValue(this.createUserFormGroup.get('LastName').value.trim());
    this.createUserFormGroup.get('City').setValue(this.createUserFormGroup.get('City').value.trim());

    this.store$.dispatch(new SaveCreatedUserAction(this.ContainerId, this.createUserFormGroup.value));
  }

  public isChecked(event, value: string) {
    const isChecked = event.target.checked;

    if (value === 'ApiOnly') {
      if (isChecked) {
        this.createUserFormGroup.get('IsFixServiceAccount').disable();
      } else {
        this.createUserFormGroup.get('IsFixServiceAccount').enable();
      }
    } else if (value === 'IsFixServiceAccount') {
      if (isChecked) {
        this.createUserFormGroup.get('ApiOnly').disable();
      } else {
        this.createUserFormGroup.get('ApiOnly').enable();
      }
    }
  }
}
