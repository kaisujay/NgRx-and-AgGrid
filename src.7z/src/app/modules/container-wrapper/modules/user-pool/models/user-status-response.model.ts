export interface UserStatusResponseModel {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}
