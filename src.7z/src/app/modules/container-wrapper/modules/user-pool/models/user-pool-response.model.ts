export interface UserPoolResponseModel {
  Count: number;
  Items: UserPoolResponseItemModel[];
  PageCount: number;
  PageNumber: number;
  PageSize: number;
}

export interface UserPoolResponseItemModel {
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  FirstName: string;
  LastName: string;
  Email: string;
  Emails: UserEmail[];
  Status: string;
  Lockout: boolean;
  LastLoginDate: string;
  ContainersNamesList: string;
  CompaniesNamesList: string;
  CompanyIdsList: string;
  Title: string;
  City: string;
  Country: string;
  Role: string;
  PhoneNumber: string;
  Companies: CompanyMembership[];
  Containers: ContainerMembership[];
  IsContainerAdmin: boolean;
  OrderInd: boolean;
  IpreoAccountId: string;
  InvitationStatus: IpreoAccountInvitationStatus;
}

export interface BaseEntity {
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
}

export interface UserEmail extends BaseEntity {
  UserId: string;
  Email: string;
  IsPrimary: boolean;
  IsConfirmed: boolean;
}

export interface CompanyMembership {
  Id: string;
  CompanyId: string;
  OrionId: number;
  UserId: string;
  CompanyName: string;
  Role: MembershipRole;
  RowVersion: number;
}

export enum MembershipRole {
  PortfolioManager = 0,
  Analyst = 1,
  Trader = 2,
  TradingOperations = 3,
  Compliance = 4,
  Technology = 5,
  Other = 6
}

export interface ContainerMembership {
  ContainerId: string;
  IsAdmin: boolean;
  IsExcludedFromMembershipAudit: boolean;
}

export enum IpreoAccountInvitationStatus {
  Completed = 1,
  Pending = 2,
  Expired = 3
}
