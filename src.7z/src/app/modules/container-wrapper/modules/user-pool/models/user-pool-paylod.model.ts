export interface UserPoolPayloadModel {
  containerId: string;
  page: number;
  pageSize: number;
  sortDirection: string;
  sortField: string;
}
