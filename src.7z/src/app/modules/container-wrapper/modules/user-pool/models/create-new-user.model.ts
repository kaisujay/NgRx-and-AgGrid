import { CreateMemberPermissionModel } from '../../company-members/models/company-members.model';

export interface CreateNewUserInUserPoolPayloadModel {
  Email: string;
  FirstName: string;
  LastName: string;
  Title?: string;
  PhoneNumber?: string;
  City: string;
  Country: string;
  ContainerId: string;
  IsContainerAdmin?: boolean;
  ApiOnly?: boolean;
  IsFixServiceAccount?: boolean;
  IpreoAccountIntegrationRequired?: boolean;
  ThinkFolioUserId?: string;
  Role: string;
  UserName: string;
}

export interface CreateNewUserInUserPoolResponseModel {
  Password: string;
}

export interface UserRoleModel {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}

export interface IndivisualUserModel {
  Title: string;
  City: string;
  Country: string;
  HomePage: string;
  Email: string;
  PhoneNumber: number;
  Emails: Email[];
  Phones: [];
  SentToOrionQueue: boolean;
  ApiOnly: boolean;
  IsFixServiceAccount: boolean;
  ThinkFolioUserId: string;
  IpreoAccountId: string;
  Role: string;
  IpreoAccountIntegrationRequired: boolean;
  InvitationStatus: string;
  AcceptTermsOfUseRequired: boolean;
  Companies: [];
  Containers: Container[];
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  UserName: string;
  FirstName: string;
  LastName: string;
  Status: string;
  Lockout: boolean;
  LastLoginDate: string;
  PasswordChangeRequired: boolean;
  Language: string;
  NumberFormat: string;
  Currency: string;
  DateFormat: string;
  TimeFormat: string;
  Timezone: string;
  featurePermissions: Partial<CreateMemberPermissionModel>;
}

export interface Email {
  UserId: string;
  Email: string;
  IsPrimary: boolean;
  IsConfirmed: boolean;
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
}

export interface Container {
  Id: string;
  IsAdmin: boolean;
  IsExcludedFromMembershipAudit: boolean;
}

export interface UpdateUserInUserPoolPayloadModel {
  UserId: string;
  Email: string;
  FirstName: string;
  LastName: string;
  Title: string;
  PhoneNumber: number;
  City: string;
  Country: string;
  RowVersion: number;
  ContainerId: string;
  Status: string;
  IsContainerAdmin: boolean;
  IsExcludedFromMembershipAudit: boolean;
  ApiOnly: boolean;
  IsFixServiceAccount: boolean;
  IpreoAccountIntegrationRequired: boolean;
  ThinkFolioUserId: string;
  Role: string;
  UserName: string;
}
