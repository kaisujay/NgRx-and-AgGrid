export interface ContainerDetails {
  CreatedBy: string;
  CreationDate: string;
  Id: string;
  IsTestContainer: boolean;
  LastModifiedBy: string;
  LastModifiedDate: Date;
  Name: string;
  RowVersion: number;
  Status: string;
}
