import { Action } from '@ngrx/store';
import { ContainerDetails } from '../../models/container-details.model';

export enum ContainerWrapperActionTypes {
  Load = '[Container Wrapper] Load',
  LoadSuccess = '[Container Wrapper] Load Success',
  LoadFailed = '[Container Wrapper] Load Failed',
  LoadCompanySettings = '[Container Wrapper] Load Company Settings',
  LoadCompanySettingsSuccess = '[Container Wrapper] Load Company Settings Success',
  LoadCompanySettingsFailed = '[Container Wrapper] Load Company Settings Failed'
}

export class LoadAction implements Action {
  public readonly type = ContainerWrapperActionTypes.Load;
  public constructor(public payload: { id: string }) {}
}

export class LoadSuccessAction implements Action {
  public readonly type = ContainerWrapperActionTypes.LoadSuccess;
  public constructor(public payload: { containerDetails: ContainerDetails }) {}
}

export class LoadFailedAction implements Action {
  public readonly type = ContainerWrapperActionTypes.LoadFailed;
  public constructor() {}
}

export class LoadCompanySettingsAction implements Action {
  public readonly type = ContainerWrapperActionTypes.LoadCompanySettings;
  public constructor(public id: string) {}
}

export class LoadCompanySettingsSuccessAction implements Action {
  public readonly type = ContainerWrapperActionTypes.LoadCompanySettingsSuccess;
  public constructor(public payload: { containerDetails: ContainerDetails }) {}
}

export class LoadCompanySettingsFailedAction implements Action {
  public readonly type = ContainerWrapperActionTypes.LoadCompanySettingsFailed;
  public constructor() {}
}

export type ContainerWrapperActionsUnion =
  | LoadAction
  | LoadSuccessAction
  | LoadFailedAction
  | LoadCompanySettingsAction
  | LoadCompanySettingsFailedAction
  | LoadCompanySettingsSuccessAction;
