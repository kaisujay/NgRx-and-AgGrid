import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ContainerWrapperActionTypes, ContainerWrapperActionsUnion } from '@state/actions/container-wrapper.actions';
import { ContainerDetails } from '../../models/container-details.model';
import { CompanyDetailsModel } from '../../modules/company-details/models/company-details.model';

export interface ContainerWrapperState {
  containerDetails: ContainerDetails;
  companyDetails: CompanyDetailsModel;
  companySettings: any;
}

export const initialState: ContainerWrapperState = {
  containerDetails: null,
  companyDetails: null,
  companySettings: null
};

export function containerWrapperReducer(
  state: ContainerWrapperState = initialState,
  action: ContainerWrapperActionsUnion
): ContainerWrapperState {
  switch (action.type) {
    case ContainerWrapperActionTypes.LoadSuccess:
      return {
        ...state,
        containerDetails: action.payload.containerDetails
      };
    case ContainerWrapperActionTypes.LoadCompanySettingsSuccess:
      return {
        ...state,
        companySettings: action.payload
      };
    default:
      return state;
  }
}

export const getContainerWrapperState = createFeatureSelector<ContainerWrapperState>('containerWrapper');

export const getContainerWrapperName = createSelector(getContainerWrapperState, state => state.containerDetails.Name);
