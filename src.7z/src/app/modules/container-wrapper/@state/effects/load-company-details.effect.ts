import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import {
  ContainerWrapperActionTypes,
  LoadAction,
  LoadFailedAction,
  LoadSuccessAction
} from '@state/actions/container-wrapper.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainerWrapperHttpService } from '../../services/container-wrapper-http.service';

@Injectable()
export class LoadCompanyDetailsEffect {
  public constructor(
    private actions$: Actions,
    private containerWrapperHttpService: ContainerWrapperHttpService
  ) {}
  public loadContainerDetailsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainerWrapperActionTypes.Load),
      switchMap((action: LoadAction) => {
        return this.containerWrapperHttpService.get(action.payload.id).pipe(
          map(response => new LoadSuccessAction({ containerDetails: response })),
          catchError(() => of(new LoadFailedAction()))
        );
      })
    )
  );
}
