import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import {
  ContainerWrapperActionTypes,
  LoadCompanySettingsAction,
  LoadCompanySettingsFailedAction,
  LoadCompanySettingsSuccessAction
} from '@state/actions/container-wrapper.actions';
import { catchError, map, of, switchMap } from 'rxjs';
import { ContainerWrapperHttpService } from '../../services/container-wrapper-http.service';

@Injectable()
export class LoadCompanySettingsEffect {
  public constructor(
    private actions$: Actions,
    private containerWrapperHttpService: ContainerWrapperHttpService
  ) {}
  public loadCompanySettingsEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ContainerWrapperActionTypes.LoadCompanySettings),
      switchMap((action: LoadCompanySettingsAction) => {
        return this.containerWrapperHttpService.getCompanySettings(action.id).pipe(
          map(response => new LoadCompanySettingsSuccessAction(response)),
          catchError(() => of(new LoadCompanySettingsFailedAction()))
        );
      })
    )
  );
}
