import { Component, Input, OnInit } from '@angular/core';
import { AlertType } from '@core/components/alert/alert-type.model';
import { WarningType } from '@core/constants/constants';

@Component({
  selector: 'app-login-warning',
  templateUrl: './login-warning.component.html',
  styleUrls: ['./login-warning.component.scss']
})
export class LoginWarningComponent implements OnInit {
  @Input() public warning: WarningType | null;
  @Input() public username: string;
  @Input() public initialUserName: string;
  @Input() public supportGroupEmail: string;
  @Input() public correlationId: string;

  public WarningType = WarningType;
  public AlertType = AlertType;
  public mailHrefLink: string;

  public constructor() {}

  public ngOnInit(): void {
    this.mailHrefLink = 'mailto:' + this.supportGroupEmail;
  }
}
