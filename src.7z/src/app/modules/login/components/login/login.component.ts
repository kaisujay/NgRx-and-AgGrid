import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BspAdminConfiguration } from '@core/components/models/configuration.model';
import { WarningType } from '@core/constants/constants';
import { Store, select } from '@ngrx/store';
import { LoginAction } from '@state/actions/auth-api.actions';
import { Observable, Subscription } from 'rxjs';
import { AuthState } from 'src/app/@state/reducers/auth.reducer';
import { environment } from 'src/environments/environment';
import * as fromRoot from './../../../../@state/reducers';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  public loginFormGroup: FormGroup = new FormGroup({});
  public assetsURL = environment.assetsURL;
  public isLoading = false;
  public config$: Observable<BspAdminConfiguration>;
  public PASSWORD_PATTERN = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+~`\-={}[\]:;"'<>,.?/\\]).{8,}$/;
  public authStateSubscription: Subscription;
  public warningType: WarningType | null = null;

  public constructor(
    private store: Store,
    private _fb: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.prepareLoginForm();
    this.authStateSubscription = this.store.pipe(select(fromRoot.getAuthState)).subscribe((data: AuthState) => {
      this.isLoading = data.isLoading;
      this.warningType = data.warning || null;
    });
  }

  public prepareLoginForm() {
    this.loginFormGroup = this._fb.group({
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required])
    });
  }

  public get username() {
    return this.loginFormGroup.get('username');
  }

  public get password() {
    return this.loginFormGroup.get('password');
  }

  /* Login Function */
  public onSubmit(): void {
    if (this.loginFormGroup.valid) {
      this.store.dispatch(new LoginAction(this.loginFormGroup.value));
    } else {
      this.loginFormGroup.markAllAsTouched();
    }
  }

  /* Reset funcitionality */
  public resetPassword(): void {
    console.log('Reset pwd');
  }

  public ngOnDestroy(): void {
    this.authStateSubscription.unsubscribe();
  }
}
