export interface LoginSuccessResponse {
  CredentialUsed: string;
  PasswordChangeRequired: boolean;
  username: string;
  success?: boolean;
}

export interface LoginFailResponse {
  success?: boolean;
  message?: string;
}

export interface UserSessionContext {
  IsSysAdmin: boolean;
  Email: string;
  JobFunction: string;
  Id: string;
  CreatedBy: string;
  CreationDate: string;
  LastModifiedBy: string;
  LastModifiedDate: string;
  RowVersion: number;
  UserName: string;
  FirstName: string;
  LastName: string;
  Status: string;
  Lockout: false;
  LastLoginDate: string;
  PasswordChangeRequired: boolean;
  Language: string;
  NumberFormat: string;
  Currency: string;
  DateFormat: string;
  TimeFormat: string;
  Timezone: string;
}

export interface UserSessionContextResponse {
  context: UserSessionContext;
  xsrf_token?: string;
}
