export interface UserCredentials {
  username: string;
  password: string;
  grant_type?: string;
}
