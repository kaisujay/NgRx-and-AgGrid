import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { LoginWarningComponent } from './components/login-warning/login-warning.component';
import { LoginComponent } from './components/login/login.component';
import { LoginRoutingModule } from './login-routing.module';

@NgModule({
  declarations: [LoginComponent, LoginWarningComponent],
  imports: [CommonModule, FormsModule, CoreModule, ReactiveFormsModule, LoginRoutingModule],
  exports: [LoginComponent]
})
export class LoginModule {}
