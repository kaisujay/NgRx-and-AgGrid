import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ClickOutsideModule, DropdownsModule, HeaderModule, IconModule, SPRFormsModule } from '@ipreo/ngx-sprinkles';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { AdminSharedModule } from '@shared/shared.module';
import { AdminProfileDropdownComponent } from './components/admin-profile-dropdown/admin-profile-dropdown.component';
import { AlertComponent } from './components/alert/alert.component';
import { ConfirmPasswordComponent } from './components/confirm-password/confirm-password.component';
import { HeaderTitleComponent } from './components/header-title/header-title.component';
import { LoggingErrorHandleEffect } from './components/logging-error-handle/@states/effects/logging-error-handle.effect';
import { logsReducer } from './components/logging-error-handle/@states/reducers/logging-error-handle.reducer';
import { NavHeaderMenuComponent } from './components/nav-header-menu/nav-header-menu.component';
import { NavHeaderComponent } from './components/nav-header/nav-header.component';
import { DateFormatService } from './services/date-format/date-format.service';
import { PasswordValidationService } from './services/password-validation.service';

@NgModule({
  declarations: [
    NavHeaderComponent,
    AdminProfileDropdownComponent,
    AlertComponent,
    ConfirmPasswordComponent,
    NavHeaderMenuComponent,
    HeaderTitleComponent
  ],
  imports: [
    CommonModule,
    HeaderModule,
    DropdownsModule,
    IconModule,
    ClickOutsideModule,
    ReactiveFormsModule,
    SPRFormsModule,
    FormsModule,
    RouterLink,
    HttpClientModule,
    StoreModule.forFeature('logs', logsReducer),
    EffectsModule.forFeature([LoggingErrorHandleEffect]),
    AdminSharedModule
  ],
  providers: [KendoAdapterService, PasswordValidationService, DateFormatService],
  exports: [NavHeaderComponent, AdminProfileDropdownComponent, AlertComponent, ConfirmPasswordComponent]
})
export class CoreModule {}
