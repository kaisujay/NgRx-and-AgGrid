import { Component } from '@angular/core';
import { IHeaderItemComponent, Themes } from '@ipreo/ngx-sprinkles';

@Component({
  selector: 'app-header-title',
  templateUrl: './header-title.component.html',
  styleUrls: ['./header-title.component.scss']
})
export class HeaderTitleComponent implements IHeaderItemComponent {
  public data: any;
  public theme: Themes;
}
