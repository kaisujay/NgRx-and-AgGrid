export enum AlertType {
  Error = 'Error',
  Info = 'Info',
  Warning = 'Warning'
}
