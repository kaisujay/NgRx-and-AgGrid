import { Component, ElementRef, HostListener } from '@angular/core';

@Component({
  selector: 'app-nav-header-menu',
  templateUrl: './nav-header-menu.component.html',
  styleUrls: ['./nav-header-menu.component.scss']
})
export class NavHeaderMenuComponent {
  public isUserDropdownOpen = false;
  public isAttestationManagerDropdownOpen = false;

  public constructor(private elementRef: ElementRef) {}

  public handleUserAvatarClick() {
    this.isUserDropdownOpen = !this.isUserDropdownOpen;
    this.isAttestationManagerDropdownOpen = false;
  }

  public handleAttestationManagerAvatarClick() {
    this.isUserDropdownOpen = false;
    this.isAttestationManagerDropdownOpen = !this.isAttestationManagerDropdownOpen;
  }

  public usersDropdown() {
    this.isUserDropdownOpen = false;
  }

  public attestationManagerDropdown() {
    this.isAttestationManagerDropdownOpen = false;
  }

  @HostListener('document:click', ['$event'])
  public onGlobalClick(event): void {
    const nextUrl = event.target.toString();
    if (
      !this.elementRef.nativeElement.contains(event.target) ||
      nextUrl.includes('containers') ||
      nextUrl.includes('settings') ||
      nextUrl.includes('termsOfUse') ||
      nextUrl.includes('reporting')
    ) {
      this.isUserDropdownOpen = false;
      this.isAttestationManagerDropdownOpen = false;
    }
  }
}
