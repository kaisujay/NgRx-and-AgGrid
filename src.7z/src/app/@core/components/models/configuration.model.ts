export interface BspAdminConfiguration {
  application: string;
  applicationVersionNumber: string;
  forgotPasswordEnabled: boolean;
  httpTimeout: number;
  ipreoAccountEnabled: boolean;
  localStoragePrefix: string;
  loginRequiresEmail: boolean;
  openedTabsStorageKey: string;
  reMapClientStackTrace: boolean;
  requestAccessEnabled: boolean;
  sessionLogoutTimeout: number;
  sessionNotifyTimeout: number;
  sessionTimedOutPropertyName: string;
  signalrReconnectInterval: number;
  supportGroupEmail: string;
}
