export interface ChangePassword {
  NewPassword: string;
  OldPassword: string;
}

export interface ChangePasswordError {
  ErrorCode: number;
  Message: string;
  Details: {
    Code: string;
    Description: string;
  }[];
}
