export const environment = {
  production: false,
  assetsURL: ''
};
